package aliview.sequencelist;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;

import javax.swing.AbstractListModel;

import aliview.sequences.Sequence;

public class SequenceListModel extends AbstractListModel implements Iterable<Sequence>{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8081215660929212156L;
	ArrayList<Sequence> sequences;
	
	public SequenceListModel(ArrayList<Sequence> seq) {
		this.sequences = seq;
	}

	public int compare(Sequence o1, Sequence o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void setSequences(ArrayList<Sequence> sequences){
		this.sequences = sequences;
	}

	public Object getElementAt(int index) {
		return sequences.get(index);
	}

	public int getSize() {
		return sequences.size();
	}

	public boolean removeElement(Object obj) {
		int index = sequences.indexOf(obj);
		boolean rv = sequences.remove(obj);
		if (index >= 0) {
		    fireIntervalRemoved(this, index, index);
		}
		return rv;
	}

	public void add(int index, Object seq) {
		// todo very ugly conversion change so add is taking only sequences 
		sequences.add(index, (Sequence) seq);
		fireIntervalRemoved(this, index, index);
		
	}

	public ListIterator<Sequence> elements() {
		return sequences.listIterator();
	}

	public Sequence get(int index) {
		return sequences.get(index);
	}

	public void removeAt(int index) {
		sequences.remove(index);
		fireIntervalRemoved(this, index, index);
		
	}

	public void insertAt(Sequence seq, int index) {
		sequences.add(index, seq);
		fireIntervalRemoved(this, index, index);
	}

	public Iterator<Sequence> iterator() {
		return sequences.listIterator();
	}
	
	/**
	   * Inserts a collection of items before the specified index
	   */
	  public void insertItems( int index, Collection objects )
	  {
	    // Handle the case where the items are being added to the end of the list
	    if( index == -1 )
	    {
	      // Add the items
	      for( Iterator i = objects.iterator(); i.hasNext(); )
	      {
	        String item = ( String )i.next();
	        addItem( item );
	      }
	    }
	    else
	    {
	      // Insert the items
	      for( Iterator i = objects.iterator(); i.hasNext(); )
	      {
	        String item = ( String )i.next();
	        insertItem( index++, item );
	      }
	    }

	 // Tell the list to update itself
	 this.fireContentsChanged( this, 0, this.sequences.size() - 1 );
	  }

 private void insertItem(int i, String item) {
		//sequences.add(i, item);
		
	}

	private void addItem(String item) {
		// TODO Auto-generated method stub
		
	}

	public void itemsMoved( int newIndex, int[] indicies )
	  {
	    // Copy the objects to a temporary ArrayList
	    ArrayList objects = new ArrayList();
	    for( int i=0; i<indicies.length; i++ )
	    {
	      objects.add( this.sequences.get( indicies[ i ] ) );
	    }

	    // Delete the objects from the list
	    for( int i=indicies.length-1; i>=0; i-- )
	    {
	      this.sequences.remove( indicies[ i ] );
	    }

	    // Insert the items at the new location
	    insertItems( newIndex, objects );
	  }


}
