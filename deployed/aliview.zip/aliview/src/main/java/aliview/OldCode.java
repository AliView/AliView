package aliview;

public class OldCode {

	/*/*
	public void zoomInAt(Point mousePos){
		try{
		
			// try to move alignment so center of pane is at mouse pointer

			Point viewPoint = alignmentScrollPane.getViewport().getViewPosition();
			Point mousePosInScrollPaneCoord = new Point(mousePos.x - viewPoint.x, mousePos.y - viewPoint.y);
			
			//logger.info("mousePosInScrollPaneCoord" + mousePosInScrollPaneCoord);
			
			// Panel will change so get actual base at mouse pointer
			Base centerBase = alignmentPane.getBaseAt(mousePos);
			logger.info("old pos" + alignmentPane.getBasePosition(centerBase));
			
			incCharSize();
			
			// Now when alignmentPanel coordinates have changed due to resize focus on the base where mouse pointer were earlier
			Point baseNewPos = alignmentPane.getBasePosition(centerBase);
			logger.info("new pos" + alignmentPane.getBasePosition(centerBase));
			
			
			// move viewport so base moves to mouse pointer (absolute position on)					
			int newX = baseNewPos.x - mousePosInScrollPaneCoord.x;
			int newY = baseNewPos.y - mousePosInScrollPaneCoord.y;
			Point newViewPoint = new Point(newX, newY);
			alignmentScrollPane.getViewport().setViewPosition(newViewPoint);
			viewPoint = alignmentScrollPane.getViewport().getViewPosition();
		} catch (InvalidAlignmentPositionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void zoomOutAt(Point mousePos){

		try {
			Point viewPoint = alignmentScrollPane.getViewport().getViewPosition();
			Point mousePosInScrollPaneCoord = new Point(mousePos.x - viewPoint.x, mousePos.y - viewPoint.y);

			//logger.info("mousePosInScrollPaneCoord" + mousePosInScrollPaneCoord);

			// Panel will change so get actual base at mouse pointer
			Base centerBase = alignmentPane.getBaseAt(mousePos);
			logger.info("old pos" + alignmentPane.getBasePosition(centerBase));
			decCharSize();

			// Now when alignmentPanel coordinates have changed due to resize focus on the base where mouse pointer were earlier
			Point baseNewPos = alignmentPane.getBasePosition(centerBase);
			logger.info("new pos" + alignmentPane.getBasePosition(centerBase));


			// move viewport so base moves to mouse pointer (absolute position on)					
			int newX = baseNewPos.x - mousePosInScrollPaneCoord.x;
			int newY = baseNewPos.y - mousePosInScrollPaneCoord.y;
			Point newViewPoint = new Point(newX, newY);
			alignmentScrollPane.getViewport().setViewPosition(newViewPoint);
			viewPoint = alignmentScrollPane.getViewport().getViewPosition();

		} catch (InvalidAlignmentPositionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	*/
	
}
