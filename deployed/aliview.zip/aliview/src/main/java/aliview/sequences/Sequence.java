package aliview.sequences;


import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jebl.evolution.sequences.SequenceType;
import jebl.evolution.sequences.Utils;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import utils.Utilities;

import com.sun.corba.se.impl.javax.rmi.CORBA.Util;

import aliview.Base;
import aliview.NucleotideUtilities;

// todo can save memory by changing data implementation into byte instead of char
public abstract class Sequence implements Comparable<Sequence> {
	private static final String TEXT_FILE_BYTE_ENCODING = "ASCII";
	static final byte GAP_SYMBOL = (byte) '-';
	private static final Logger logger = Logger.getLogger(Sequence.class);
	protected boolean[] baseSelection;
	private boolean simpleName = false;
	public abstract byte[] getBases();
	public static int TYPE_AMINO_ACID = 0;
	public static int TYPE_NUCLEIC_ACID = 1;
	public static int TYPE_UNKNOWN = 2;
	public int selectionOffset = 0;
	
	public Sequence(){	
	}

	public int getLength() {
		return getBases().length;
	}

	public int getSequenceType() {
		
		// TODO could figure out if not a sequence
		int gapCount = 0;
		int nucleotideCount = 0;
		for(byte base: getBases()){
			if(NucleotideUtilities.isGap(base)){
				gapCount ++;
			}
			if(NucleotideUtilities.isNucleoticeOrIUPAC(base)){
				nucleotideCount ++;
			}
		}
		
		// allow 1 wrong base
		if(nucleotideCount + gapCount + 1 >= getBases().length){
			return TYPE_NUCLEIC_ACID;
		}
		else{
			return TYPE_AMINO_ACID;
		}
	}

	/*
	 * This should be handled differently with an editable mode or not (depending on array backend)
	 */
	public abstract void setBases(byte[] bases, boolean[] baseSelection);	

	public byte getBaseAtPos(int n){	
		return getBases()[n];	
	}

	public boolean isBaseSelected(int n){
		return baseSelection[n];	
	}

	public void setBaseSelection(int n, boolean selected){
		baseSelection[n] = selected;
	}

	public void clearAllBaseSelection(){
		Arrays.fill(baseSelection, false);
	}

	public void selectAllBases(){
		Arrays.fill(baseSelection, true);
	}

	public void invertSelection(int n){
		baseSelection[n] = ! baseSelection[n];
	}

	public String getSelectedBasesAsString(){
		StringBuilder selection = new StringBuilder();
		for(int n = 0;n < baseSelection.length;n++){
			if(baseSelection[n] == true){
				selection.append( (char) getBases()[n] );
			}
		}
		return selection.toString();
	}
	
	public String getBasesAsString(){
		String baseString = "";
		try {
			baseString = new String(getBases(), TEXT_FILE_BYTE_ENCODING);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return baseString;
	}

	public boolean[] getBasesSelection() {
		return baseSelection;
	}

	public abstract String getName();


	public abstract String getSimpleName();
	
	public void toggleSimpleName(){
		this.simpleName = !simpleName;
	}
	
	public String toString(){
		if(simpleName == true){
			return getSimpleName();
		}else{
			return getName();
		}
	}

	
	/*
	 * 
	 * TODO this must be changed in future depending on if it is a nucleotide sequence or protein sequence
	 * 
	 * 
	 */
	public Base[] findAndSelect(Pattern pattern, int startPos) {
		Base[] foundBases = null;
		
		
		// Step 2: Allocate a Matcher object from the compiled regexe pattern,
		//         and provide the input to the Matcher
		String basesAsString = new String(getBases());
		Matcher matcher = pattern.matcher(basesAsString);
		

		boolean wasFound = matcher.find(startPos);

		if(wasFound){
			int foundStart = matcher.start();
			int foundEnd = matcher.end();
			int matchLen = foundEnd - foundStart;

			foundBases = new Base[matchLen];
			int n = 0;
			for(int index = foundStart; index < foundEnd; index ++){
				setBaseSelection(index,true);
				foundBases[n] = new Base(this,index);
			}
		}

		else{
			logger.info("not found");
		}

		return foundBases;
	}

	public int getFirstSelectedPosition() {
		int firstSelectedPos = 0;
		for(int n = 0;n < baseSelection.length;n++){
			if(baseSelection[n] == true){
				firstSelectedPos = n;
				break;
			}
		}
		return firstSelectedPos;
	}

	public void replaceSelectedBasesWithGap() {
		for(int n = 0;n < baseSelection.length;n++){
			if(baseSelection[n] == true){
				getBases()[n] = '-';
			}
		}

	}

	public int[] getBaseVals() {
		int[] baseVals = new int[getBases().length];
		for(int n = 0;n < getBases().length ;n++){
			baseVals[n] = NucleotideUtilities.baseValFromBase((char) getBases()[n]);
		}
		/*
		for(int val: baseVals){
			logger.info(val);
		}
		*/
		return baseVals;
		
	}

	private int getLeftSelectedBasePosition(){	
		int position = -1;
		if(baseSelection.length > 0){
			for(int n = 0;n < baseSelection.length;n++){
				if(baseSelection[n] == true){
					position = n;
					break;
				}
			}
		}
		return position;
	}
	
	private int getRightSelectedBasePosition(){		
		int position = -1;		
		if(baseSelection.length > 0){
			for(int n = baseSelection.length - 1;n >= 0; n--){
				if(baseSelection[n] == true){
					position = n;
					break;
				}
			}
		}	
		return position;
	}
	
	
	public void insertGapLeftOfSelectedBaseMoveRight(){
		
		// get first selected position
		int position = getLeftSelectedBasePosition();
		if(position != -1){
			insertGapAtMoveRight(position);
		}		
	}
	
	public void insertGapRightOfSelectedBaseMoveLeft(){
		
		// get first selected position
		int position = getRightSelectedBasePosition();
		if(position != -1){
			insertGapAtMoveLeft(position);
		}	
	}
	
	
	
	public void moveSelectionIfGapIsPresent(int diff) {
		//logger.info("diff" + diff);
		int unmovedDiff = diff - selectionOffset;
		//logger.info("selectionOffset" + selectionOffset);
		//logger.info("unmovedDiff" + unmovedDiff);
		
		if(unmovedDiff < 0){
			moveSelectionLeftIfGapIsPresent(Math.abs(unmovedDiff));
		}
		if(unmovedDiff > 0){
			moveSelectionRightIfGapIsPresent(Math.abs(unmovedDiff));
		}
		
		selectionOffset = diff;
	}

	public void moveSelectionRightIfGapIsPresent(int steps) {

		for(int m = 0; m < steps; m++){
			// get first selected position
			int leftPosition = getLeftSelectedBasePosition();
			int rightPosition = getRightSelectedBasePosition();

			if(leftPosition >= 0  && rightPosition < this.getLength() - 1){

				// only if gap is right of selection
				if(getBaseAtPos(rightPosition + 1) == '-'){

					for(int n = rightPosition; n >= leftPosition; n--){
						getBases()[n + 1] = getBases()[n];
						getBasesSelection()[n + 1] = getBasesSelection()[n];
					}
					getBases()[leftPosition] = '-';
					getBasesSelection()[leftPosition] = false;
				}
			}

		}
	}

	public void moveSelectionLeftIfGapIsPresent(int steps) {

		for(int m = 0; m < steps; m++){
			// get first selected position
			int leftPosition = getLeftSelectedBasePosition();
			int rightPosition = getRightSelectedBasePosition();	

			if(leftPosition > 0  && rightPosition > 0){

				// only if gap is right of selection
				if(getBaseAtPos(leftPosition - 1) == '-'){

					for(int n = leftPosition; n <= rightPosition; n++){
						getBases()[n - 1] = getBases()[n];
						getBasesSelection()[n - 1] = getBasesSelection()[n];
					}
					getBases()[rightPosition] = '-';
					getBasesSelection()[rightPosition] = false;
				}				
			}
		}
	}
	
	public void moveSelectionRightIfGapIsPresent(){
		
		// get first selected position
		int leftPosition = getLeftSelectedBasePosition();
		int rightPosition = getRightSelectedBasePosition();
		
		if(leftPosition >= 0  && rightPosition < this.getLength() - 1){
			
			// only if gap is right of selection
			if(getBaseAtPos(rightPosition + 1) == '-'){
				
				for(int n = rightPosition; n >= leftPosition; n--){
					getBases()[n + 1] = getBases()[n];
					getBasesSelection()[n + 1] = getBasesSelection()[n];
				}
				getBases()[leftPosition] = '-';
				getBasesSelection()[leftPosition] = false;
			}
			
		}
	}
	
	public void moveSelectionLeftIfGapIsPresent(){
		
		// get first selected position
		int leftPosition = getLeftSelectedBasePosition();
		int rightPosition = getRightSelectedBasePosition();
		
		if(leftPosition > 0  && rightPosition > 0){
			
			// only if gap is right of selection
			if(getBaseAtPos(leftPosition - 1) == '-'){
				
				for(int n = leftPosition; n <= rightPosition; n++){
					getBases()[n - 1] = getBases()[n];
					getBasesSelection()[n - 1] = getBasesSelection()[n];
				}
				getBases()[rightPosition] = '-';
				getBasesSelection()[rightPosition] = false;
			}
			
		}
	}
	/*
	public void insertGapAtLastSelectedBaseMoveLeft(){
		
		// get first selected position
		int position = getRightSelectedBasePosition();
		if(position != -1){
			insertGapAtMoveLeft(position);
		}	
	}
	*/

	private void insertGapAtMoveRight(int n) {
		// 
		byte[] newBases = new byte[getBases().length + 1];
		System.arraycopy(getBases(), 0, newBases, 0, n);
		newBases[n] = '-';
		System.arraycopy(getBases(), n, newBases, n + 1, newBases.length - n - 1);

		// make same with selection
		boolean[] newSelection = new boolean[getBasesSelection().length + 1];
		System.arraycopy(getBasesSelection(), 0, newSelection, 0, n);
		newSelection[n] = false;
		System.arraycopy(getBasesSelection(), n, newSelection, n + 1, newSelection.length - n - 1);
		
		setBases(newBases, newSelection);
	}
	
	private void insertGapAtMoveLeft(int n) {
		
		byte[] newBases = new byte[getBases().length + 1];
		// kopiera från position 0 hos source till dest så flyttas allt vänster
		System.arraycopy(getBases(), 0, newBases, 0, n);
		newBases[n] = '-';
		System.arraycopy(getBases(), n, newBases, n + 1, newBases.length - n - 2);

		// make same with selection
		boolean[] newSelection = new boolean[getBasesSelection().length + 1];
		System.arraycopy(getBasesSelection(), 0, newSelection, 1, n);
		newSelection[n] = false;
		System.arraycopy(getBasesSelection(), n, newSelection, n + 1, newSelection.length - n - 2);
		
		setBases(newBases, newSelection);
	}
	/*
	private void removeBaseAt(int n) {
		// 
		byte[] newBases = new byte[getBases().length + 1];
		System.arraycopy(getBases(), 0, newBases, 0, n);
		newBases[n] = '-';
		System.arraycopy(getBases(), n, newBases, n + 1, newBases.length - n - 1);

		// make same with selection
		boolean[] newSelection = new boolean[getBasesSelection().length + 1];
		System.arraycopy(getBasesSelection(), 0, newSelection, 0, n);
		newSelection[n] = false;
		System.arraycopy(getBasesSelection(), n, newSelection, n + 1, newSelection.length - n - 1);
		
		setBases(newBases, newSelection);
	}

	private void setBasesSelection(boolean[] newSelection) {
		baseSelection = newSelection;	
	}
	*/
	public int[] getSelectedBasesPositions() {
		
		int[] selectedPos = new int[countSelectedBases()];
		int arrayPos = 0;
		for(int n = 0;n < baseSelection.length;n++){
			if(baseSelection[n] == true){
				selectedPos[arrayPos] = n;
				arrayPos ++;
			}
		}
		return selectedPos;
	}
	
	private int countSelectedBases() {
		int selectionCount = 0;
		for(int n = 0;n < baseSelection.length;n++){
			if(baseSelection[n] == true){
				selectionCount ++;
			}
		}
		return selectionCount;
	}

	public void replaceBases(int startReplaceIndex, int stopReplaceIndex, byte[] insertBases) {
		
		int newLength = this.getBases().length - (stopReplaceIndex + 1 - startReplaceIndex) + insertBases.length;
		
		// TODO could check if length is less - then just clear and insert
		byte[] newBases = new byte[newLength];
		
		// copy first untouched part of sequence
		System.arraycopy(getBases(), 0, newBases, 0, startReplaceIndex);
		
		// copy insertbases
		System.arraycopy(insertBases, 0, newBases, startReplaceIndex, insertBases.length);
		
		// copy last untouched part of sequence - if there is one
		if(stopReplaceIndex < getBases().length - 1){
			System.arraycopy(getBases(), stopReplaceIndex + 1, newBases, startReplaceIndex + insertBases.length, getBases().length - (stopReplaceIndex + 1));
		}
		
		setBases(newBases, null);

	
	}

	
	/**
	 * 
	 * only for speed test
	 *
	 * @param startIndex
	 * @param endIndex
	 */

	public void selectBases(int startIndex, int endIndex) {
		// first clear
		clearAllBaseSelection();
		
		// make sure within range
		startIndex = Math.max(0, startIndex); 
		endIndex = Math.min(getBasesSelection().length - 1, endIndex); 
		
		for(int n = startIndex; n <= endIndex; n++){
			getBasesSelection()[n] = true;
		}
		
	}

	public static byte[] createGapSequence(int length) {
		byte[] byteSeq = new byte[length];
		Arrays.fill(byteSeq, GAP_SYMBOL);
		return byteSeq;
	}

	public void deleteSelectedBases(){
		
		// create new array size removed selected bases
		byte[] newBases = new byte[getBases().length - countSelectedBases()];
		
		int newIndex = 0;
		for(int n = 0;n < baseSelection.length;n++){
			// copy only unselected bases to new array
			if(baseSelection[n] == false){
				newBases[newIndex] = getBases()[n];
				newIndex ++;
			}
		}
		
		setBases(newBases, null);
		
	}

	public int getUngapedPos(int position) {
		int gapcount = 0;
		for(int n = 0; n < position; n++){
			if(NucleotideUtilities.isGap(getBases()[n])){
				gapcount ++;
			}
		}
		
		return position - gapcount;

	}

	public void reverseComplement() {
		reverse();
		complement();
	}
	
	public void complement() {
		// TODO this conversion might be problematic due to text file byte encoding
		NucleotideUtilities.complement(getBases());	
	}
	
	public void reverse(){
		// TODO this conversion might be problematic due to text file byte encoding
		ArrayUtils.reverse(getBases());	
	}
	

	public void rightPadSequencesWithGaps(int amount) {
		if(amount > 0){
			
			byte[] newBases = new byte[getBases().length + amount];
			System.arraycopy(getBases(), 0, newBases, 0, getBases().length);
			
			// fill last pos with gaps
			for(int n = 1; n <= amount; n++){
				newBases[newBases.length - n] = GAP_SYMBOL;
			}	
			setBases(newBases, null);
		}	
	}
	
	public void leftPadSequencesWithGaps(int amount) {
		
		if(amount > 0){
			
			byte[] newBases = new byte[getBases().length + amount];
			System.arraycopy(getBases(), 0, newBases, amount, getBases().length);
		
			// fill first pos with gaps
			for(int n = 0; n < amount; n++){
				newBases[n] = GAP_SYMBOL;
			}
				
			setBases(newBases, null);
		}	
		
	}

	public String getCitatedName() {
		String name = getName();
		name = StringUtils.remove(name, '\'');
		logger.info(name);
		name = StringUtils.remove(name, '\"');
		name = StringUtils.remove(name, '>');
		name = "'" + name + "'";
		return name;
	}

	public String getPositionsAsString(ArrayList<Integer> allWantedPos) {
		StringBuilder allPos = new StringBuilder();
		for(Integer aPos: allWantedPos){
			allPos.append((char)getBaseAtPos(aPos.intValue()));
		}
		return allPos.toString();
	}
	
	

	public boolean contains(char testChar) {
		boolean contains = false;
		for(byte base: getBases()){
			if((char)base == testChar){
				contains = true;
				break;
			}
		}
		return contains;
	}

	public void append(String moreInterleavedsequence) {
		
		byte[] append = moreInterleavedsequence.getBytes();
		
		byte[] newBases = new byte[getBases().length + append.length];
		System.arraycopy(getBases(), 0, newBases, 0, getBases().length);
		System.arraycopy(append, 0, newBases, getBases().length, append.length);	
		setBases(newBases, null);
	}

	public int getSelectionOffset() {
		return selectionOffset;
	}

	public void setSelectionOffset(int selectionOffset) {
		this.selectionOffset = selectionOffset;
	}

	public boolean hasSelection() {
		for(boolean selected: baseSelection){
			if(selected = true){
				return true;
			}
		}
		return false;
	}

	public void replaceBase(int pos, char newBase) {
		getBases()[pos] = (byte) newBase;
	}

	
	
	
}
