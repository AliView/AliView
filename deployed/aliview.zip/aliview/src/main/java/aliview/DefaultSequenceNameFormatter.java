package aliview;

public class DefaultSequenceNameFormatter implements SequenceNameFormatter {

	public String format(String name) {
		return name;
	}

}
