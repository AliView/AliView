package aliview;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import aliview.sequences.FastFastaSequence;
import aliview.sequences.PhylipSequence;
import aliview.sequences.Sequence;

public class PhylipImporter {
	private static final Logger logger = Logger.getLogger(FastFastaImporter.class);
	private Reader reader;
	private int longestSequenceLength;

	public PhylipImporter(Reader reader) {
		this.reader = reader;
	}

	public ArrayList<Sequence> importSequences() {

		long startTime = System.currentTimeMillis();
		ArrayList<Sequence> sequences = new ArrayList<Sequence>();
		try {
			String sequence = "";
			BufferedReader r = new BufferedReader(this.reader);
			String line;
			String name = null;
			int nLine = 0;
			
			String firstLine = line = r.readLine();
			firstLine = firstLine.trim();
			// if not phylip file then it will throw error...
			int seqCount = Integer.parseInt( firstLine.split(" ")[0] );
			int longestSequenceLength = Integer.parseInt( firstLine.split(" ")[1] );
			
			int lineCount = 0;
			boolean isFirstSeqLine = true;
			int seqStartPos = 10; // default seq start
			while ((line = r.readLine()) != null) {
				
				line = line.trim();
				
				if(line.length() > 0){
					
					// only count non-zero-lines
					lineCount ++;
					
					// figure out if name is max 10 or name is longer..
					if(isFirstSeqLine){
	
						// if there is more than 2 whitespace next to each after pos 10 then long names otherwise 10char long
						seqStartPos = 2 + StringUtils.lastIndexOf(line,"  ");
						if(seqStartPos < 10){
							seqStartPos = 10;
						}
						isFirstSeqLine = false;
					}
					
					// first lines have name
					if(lineCount <= seqCount){
						
						name = line.substring(0, seqStartPos).trim();
						sequence = line.substring(seqStartPos);
						
						// remove spaces from sequence
						sequence = StringUtils.remove(sequence, ' ');					
						sequences.add(new PhylipSequence(name, sequence));

					}
					// if there are more lines append sequences in order
					else{	
						sequence = line;
						String moreInterleavedsequence = StringUtils.remove(sequence, ' ');
						// TODO this might be a bit shaky to get right index
						int seqIndex = (lineCount - 1) % seqCount;
						sequences.get(seqIndex).append(moreInterleavedsequence);
					}

				}
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		System.out.println("reading sequences took " + (endTime - startTime) + " milliseconds");

		return sequences;
	}

	public int getLongestSequenceLength() {
		return longestSequenceLength;
	}
}
