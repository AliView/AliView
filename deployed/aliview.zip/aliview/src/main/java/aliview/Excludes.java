package aliview;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

public class Excludes implements Cloneable {
	private static final Logger logger = Logger.getLogger(Excludes.class);

	private boolean[] positions;
	
	public Excludes(int length) {
		positions = new boolean[length];
	}
	
	private Excludes(boolean[] positions) {
		this.positions = positions;
	}
	
	public boolean[] getPositions(){
		return positions;
	}
	
	public void setPositions(boolean[] positions){
		this.positions = positions;
	}
	
	public boolean isExcluded(int position){
		if(positions != null && positions.length > 0 && position >= 0 && position < positions.length){
			return positions[position];
		}
		else{
			return false;
		}
	}

	@Override
	protected Excludes clone() throws CloneNotSupportedException {
		
		boolean[] arrayClone = positions.clone(); 
		Excludes aClone = new Excludes(arrayClone);
		
		return aClone;
		
	}

	public void reverse() {
		ArrayUtils.reverse(positions);
		
	}

	public boolean isAnythingExcluded() {
		if(positions != null){
			for(boolean position: positions){
				if(position == true)
					return true;
			}
		}
		
		return false;
	}

	public void removeExcludedPositions(ArrayList<Integer> allPos0) {
		Iterator<Integer> iter = allPos0.iterator();
		while(iter.hasNext()){
			Integer pos = iter.next();
			if(isExcluded(pos.intValue())){
				iter.remove();
			}
		}	
	}
}
