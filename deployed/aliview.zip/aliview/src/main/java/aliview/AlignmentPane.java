package aliview;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;


import org.apache.log4j.Logger;


import aliview.color.AlignColorScheme;
import aliview.color.ColorScheme;
import aliview.sequences.Sequence;


// HAS to be JPanel - JComponent is not enough for only partial cliprect when in jscrollpane when painting
// When JComponent only then I had to paint it all (maybe because of layoutmanager?)
public class AlignmentPane extends JPanel{
	private static final long serialVersionUID = 601195400946835871L;
	private static final Logger logger = Logger.getLogger(AlignmentPane.class);
	private static final double MIN_CHAR_SIZE = 1;
	private static final int MAX_CHAR_SIZE = 100;
	private static final double RULER_HEIGHT_IN_CHAR_HEIGHT = 0;
	public static final int INTERACTION_MODE_VIEW = 0;
	public static final int INTERACTION_MODE_SELECT = 1;
	double charWidth = 10;
	double charHeight = 12;
	private Font baseFont = new Font(Font.MONOSPACED, Font.PLAIN, (int)charWidth);
	private Alignment alignment;
	private ColorScheme colorScheme = new AlignColorScheme();//DefaultColorScheme();
	private boolean onlyDrawDiff = false;
	private Rectangle tempSelectionRect;
	private JLabel statisticsLabel;
	private int interactionMode;
	// TODO This should instead be tracing a sequence instead of a position?
	private int differenceTraceSequencePosition = 0;
	private boolean showTranslation = false;
	private int readingFrame = 1;
	private AlignmentRuler alignmentRuler;
	private boolean drawAminoAcidCode;
	private boolean drawCodonPosRuler;

	public AlignmentPane(JLabel statLabel) {
		//this.setDoubleBuffered(true);
		//this.setBackground(Color.white);
		this.statisticsLabel = statLabel;
		alignmentRuler = new AlignmentRuler(this);
	}

	public boolean isOnlyDrawDiff() {
		return onlyDrawDiff;
	}

	public void setOnlyDrawDiff(boolean onlyDrawDiff) {
		this.onlyDrawDiff = onlyDrawDiff;
		repaint();
	}
	
	public void setDrawCodonPosRuler(boolean drawCodonPosRuler) {
		this.drawCodonPosRuler = drawCodonPosRuler;
		repaint();
	}
	
	public boolean getDrawCodonPosRuler() {
		return this.drawCodonPosRuler;
	}

	/**
	 * This method should be undoable
	 * 
	 */
	public void removeSelectedAlignment() {
		repaint();
	}

	public void decCharSize(){
		if(charWidth > 1){
			charWidth = charWidth - 1;
			charHeight = charHeight - 1;
		}
		else{
			charWidth = 0.5 * charWidth;
			charHeight = 0.5 * charHeight;
		}
		if(charWidth < MIN_CHAR_SIZE){
			charWidth = MIN_CHAR_SIZE;
			charHeight = MIN_CHAR_SIZE;
		}
		baseFont = new Font(baseFont.getName(), baseFont.getStyle(), (int)charWidth);
		this.updateSize();
		this.repaint();

	}

	public void incCharSize(){
		charWidth = charWidth + 1;
		charHeight = charHeight + 1;
		if(charWidth > MAX_CHAR_SIZE){
			charWidth = MAX_CHAR_SIZE;
			charHeight = MAX_CHAR_SIZE;
		}
		baseFont = new Font(baseFont.getName(), baseFont.getStyle(), (int)charWidth);
		this.updateSize();
		this.repaint();

	}



	// should throw no valid base error
	public Point getBasePosition(Base base){
		if(base == null){
			return null;
		}
		int x = (int) (base.getPosition() * charWidth);
		int y = (int) (alignment.getSequencePosition(base.getSequence()) * charHeight + getMatrixTopOffset());

		Point pos = new Point(x,y);

		return pos;
	}

	public void selectBaseAt(Point pos){

		try {
			Base base = getBaseAt(pos);
			if(base != null){
				base.setSelection(true);
			}
		} catch (InvalidAlignmentPositionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// update visibility of selection
		repaint();
	}

	public int getUngapedSequenceXPositionAt(Point pos){
		int ungapedPos = 0;

		try {
			Base base = getBaseAt(pos);
			if(base != null){

				ungapedPos = base.getSequence().getUngapedPos(base.getPosition());

			}
		} catch (InvalidAlignmentPositionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ungapedPos;
	}

	public int getAlignmentXat(Point pos){

		int xPos = 0;

		try {
			Base base = getBaseAt(pos);
			if(base != null){

				xPos = base.getPosition();

			}
		} catch (InvalidAlignmentPositionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return xPos;
	}



	public void selectColumnAt(Point pos) {

		int columnIndex = getColumnAt(pos);

		for(Sequence seq: getAlignmnent().sequences){
			seq.selectBases(columnIndex, columnIndex);
		}

		repaint();

	}

	// should throw no valid position
	public Base getBaseAt(Point pos) throws InvalidAlignmentPositionException{

		Point matrixPoint = paneCoordToMatrixCoord(pos);

		Base base = null;
		if(isPositionWithinAlignmentMatrix(matrixPoint.x,matrixPoint.y)){
			Sequence seq = (Sequence) alignment.getSequences().get(matrixPoint.y);
			base = new Base(seq, matrixPoint.x);
		}
		else{
			base = null;
			//throw new InvalidAlignmentPositionException("Position is out of range" + pos);
		}

		return base;
	}

	// should throw no valid position
	public Base getClosestBaseAt(Point pos){

		Point matrixPoint = paneCoordToMatrixCoord(pos);

		Base base = null;
		if(isPositionWithinAlignmentMatrix(matrixPoint.x,matrixPoint.y)){
			Sequence seq = (Sequence) alignment.getSequences().get(matrixPoint.y);
			base = new Base(seq, matrixPoint.x);
		}
		else{
			// get last sequence
			Sequence seq = (Sequence) alignment.getSequences().get(alignment.getSequences().size()-1);
			base = new Base(seq, matrixPoint.x);
		}

		return base;
	}

	// should throw no valid position
	public int getColumnAt(Point pos){

		Point matrixPoint = paneCoordToMatrixCoord(pos);

		return matrixPoint.x;

	}

	private boolean isPositionWithinAlignmentMatrix(int x, int y) {
		boolean isWithin = false;
		if(x >= 0 && x < alignment.getMaximumSequenceLength() &&
				y >= 0 && y < alignment.getSize()){
			isWithin = true;
		}
		return isWithin;
	}

	//
	// TODO this top offset can be removed now when ruler is drawn on separate panel
	//
	private int getMatrixTopOffset() {
		int rulerHeight = (int) (charHeight * RULER_HEIGHT_IN_CHAR_HEIGHT);

		int topOffset = rulerHeight;

		return topOffset;

	}

	public void setAlignment(Alignment alignment){		
		this.alignment = alignment;
		this.updateSize();
	}



	public void clearSelection() {
		alignment.clearSelection();
		repaint();
	}

	public void repaintSelection() {		
	}
	/*
	public void paintNow(){
		Graphics g = this.getGraphics();
		g.setClip(new Rectangle(100,100,100,100));
		paintComponent(g);
	}
	 */



	public void paintComponent(Graphics g) {

		logger.info(this.getVisibleRect());
		long startTime = System.currentTimeMillis();


		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;

		Rectangle clip = g2d.getClipBounds();
		// grow it so that ugly painting mistakes are avoided when only part of image is drawn 
		//logger.info("clip" + clip);
		//clip.grow(0, 300);
		//logger.info("clip" + clip);
		//logger.info("this.getVisibleRect()" + this.getVisibleRect());

		//clip = this.getVisibleRect();

		/*	
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  
                RenderingHints.VALUE_ANTIALIAS_OFF);  
		 */


		g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		/*
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		g2d.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
				RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
		g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
				RenderingHints.VALUE_COLOR_RENDER_SPEED);
		g2d.setRenderingHint(RenderingHints.KEY_DITHERING,
				RenderingHints.VALUE_DITHER_DISABLE);
		 */



		// relocate y-axis to bottom 
		/*
		//AffineTransform transform = new AffineTransform();


        transform.translate(0, getPanelHeight());
        g2d.setTransform(transform);    

        transform.scale(0.2, 0.2);
        g2d.setTransform(transform);
        clip = g2d.getClipBounds();
		 */

		g2d.setFont(baseFont);

		// What part of alignment matrix is in view (what part of matrix is in graphical view)
		Rectangle matrixClip = paneCoordToMatrixCoord(clip);

		int rulerHeight = (int) (charHeight * RULER_HEIGHT_IN_CHAR_HEIGHT);
		int topOffset = rulerHeight;

		// todo calculate from font metrics
		int charCenterXOffset = (int) (0.1 * charWidth);
		int charCenterYOffset = (int) (0.1 * charHeight);


		// First draw a white background
		//g2d.setColor(Color.white);
		//g2d.fillRect((int)(matrixClip.x * charWidth), (int)(matrixClip.y * charHeight), (int)(matrixClip.width * charWidth), (int)(matrixClip.height * charHeight));


		// Get alignment as a matrix
		// byte[][] basesMatrix = alignment.getBasesMatrix();

		//boolean[][] basesSelectionMatrix = alignment.getBasesSelectionMatrix();
		// loop through the part of alignment matrix that is in view


		// First draw a white background (add one to values to draw it a little wider
		int xMin = matrixClip.x - 1;
		int yMin = matrixClip.y - 1;
		int xMax = (int) matrixClip.getMaxX() + 1;
		int yMax = (int) matrixClip.getMaxY() + 1;

		// adjust for part of matrix that exists
		xMin = Math.max(0, xMin);
		yMin = Math.max(0, yMin);
		xMax = Math.min(alignment.getMatrixMaxX(), xMax);
		yMax = Math.min(alignment.getMatrixMaxY(), yMax);
		int width = xMax - xMin;
		int height = yMax - yMin;

		g2d.setColor(Color.white);
		g2d.fillRect((int)(xMin*charWidth),(int)(yMin*charHeight),(int)(width*charWidth),(int)(height*charHeight));



		//
		//
		//  Draw codon
		//
		//

		/*		 

		if(showTranslation){
			int rest = (matrixClip.x % 3) - this.readingFrameOffset;
			int offsetBecauseAlwaysDrawFullCodon = 3; // always draw full codon because of jscrollpane (otherwise not always drawn out to edge)
			int codonStart = matrixClip.x - rest - offsetBecauseAlwaysDrawFullCodon;

			// get 


			for(int x = codonStart; x < matrixClip.getMaxX() + offsetBecauseAlwaysDrawFullCodon; x = x+3){ // Every third is a codon
				for(int y = matrixClip.y; y < matrixClip.getMaxY(); y = y + 1){

					// Only draw part of matrix that exists
					if(y >= 0 && x >= 0 && y < alignment.getBasesMatrix().length && x < alignment.getBasesMatrix()[y].length){  //if(y >= 0 && x >= 0 && y < alignment.getMatrixMaxY() && x < alignment.getMatrixMaxX())

						// Set default
						byte[] codon = alignment.getCodonAt(x, y);

						AminoAcid acid = AminoAcid.getAminoAcidFromCodon(codon);

						Color aminoAcidBackgroundColor = colorScheme.getAminoAcidBackgroundColor(acid);

						// draw background
						g2d.setColor(aminoAcidBackgroundColor);
						g2d.fillRect((int)(x * charWidth), (int)(y * charHeight + getMatrixTopOffset()), (int)charWidth * codon.length, (int)charHeight);

					}

				}
			}

		 */

		if(showTranslation && alignment instanceof NucleotideAlignment){	
			alignment.getCodonPositions().setReadingFrame(this.readingFrame);
			int ONE_EXTRA_CODON = 3;
			for(int x = (int)matrixClip.getMinX() - ONE_EXTRA_CODON; x <= matrixClip.getMaxX() + ONE_EXTRA_CODON; x++){ // Every third is a codon

				for(int y = matrixClip.y; y <= matrixClip.getMaxY(); y = y + 1){

					// Only draw part of matrix that exists
					if(y >= 0 && x >= 0 && y < alignment.getBasesMatrix().length && x < alignment.getBasesMatrix()[y].length){  //if(y >= 0 && x >= 0 && y < alignment.getMatrixMaxY() && x < alignment.getMatrixMaxX())

						if(alignment.getCodonPositions().isFullCodonStartingAt(x)){

							// Set default
							byte[] codon = alignment.getCodonAt(x, y);



							AminoAcid acid = AminoAcid.getAminoAcidFromCodon(codon);

							Color aminoAcidBackgroundColor = colorScheme.getAminoAcidBackgroundColor(acid);

							// draw background
							g2d.setColor(aminoAcidBackgroundColor);
							g2d.fillRect((int)(x * charWidth), (int)(y * charHeight + getMatrixTopOffset()), (int)charWidth * codon.length, (int)charHeight);


							if(drawAminoAcidCode){
								g2d.setColor(Color.WHITE);
								byte[] byteCodeVal = acid.getCodeByteVal();
								if(charHeight > 3){
									g2d.drawBytes(byteCodeVal, 0, byteCodeVal.length, (int)(x * charWidth + charCenterXOffset + charWidth), (int)(y * charHeight + getMatrixTopOffset() + charHeight - charCenterYOffset));
								}
							}
						}
					}
				}
			}
		}

		if(alignment instanceof NucleotideAlignment){
			for(int x = matrixClip.x; x <= matrixClip.getMaxX(); x = x+1){
				for(int y = matrixClip.y; y <= matrixClip.getMaxY(); y = y + 1){

					// Only draw part of matrix that exists
					if(y >= 0 && x >= 0 && y < alignment.getBasesMatrix().length && x < alignment.getBasesMatrix()[y].length){  //if(y >= 0 && x >= 0 && y < alignment.getMatrixMaxY() && x < alignment.getMatrixMaxX())

						// Set default
						byte base = alignment.getBaseAt(x,y);

						int baseVal = NucleotideUtilities.baseValFromBase(base);

						Color baseForegroundColor = colorScheme.getBaseForegroundColor(baseVal);
						Color baseBackgroundColor = colorScheme.getBaseBackgroundColor(baseVal);

						// get char to draw
						byte[] byteToDraw = new byte[1];
						byteToDraw[0]=alignment.getBaseAt(x,y);

						// adjustment if only diff to be shown
						if(onlyDrawDiff){ // TODO CHANGE THIS SO IT IS WORKING EVEN IF TRACING SEQUENCE IS SHORTER THAN OTHER
							if(y != differenceTraceSequencePosition && NucleotideUtilities.baseValFromBase(base) == NucleotideUtilities.baseValFromBase(alignment.getBaseAt(x,differenceTraceSequencePosition))){
								byteToDraw[0] = '.';
								baseBackgroundColor = Color.white;
							}
						}

						/*
							// add temporary selection (if there is one)
							if(tempSelectionRect != null){
								if(tempSelectionRect.contains(x, y)){
									baseBackgroundColor = colorScheme.getBaseSelectionBackgroundColor(baseVal);
									baseForegroundColor = colorScheme.getBaseSelectionForegroundColor(baseVal);
								}
							}

							// differebt color if selected							
							if(alignment.isBaseSelected(x,y)){
								baseBackgroundColor = colorScheme.getBaseSelectionBackgroundColor(baseVal);
								baseForegroundColor = colorScheme.getBaseSelectionForegroundColor(baseVal);
							}
						 */

						// draw background (not if translated background is drawn already), but if it is in excludes
						if(showTranslation == false || alignment.getExcludes().isExcluded(x)){
							//g2d.setColor( new Color(baseBackgroundColor.getRed(),baseBackgroundColor.getGreen(), baseBackgroundColor.getBlue(),150));
							g2d.setColor(baseBackgroundColor);
							g2d.fillRect((int)(x * charWidth), (int)(y * charHeight + getMatrixTopOffset()), (int)charWidth, (int)charHeight);
						}

						//tempSelectionRect = null;

						/*	
							if(tempSelectionRect != null){
								logger.info("x"+ x + "y" + y);
								logger.info("tempSelectionRect" + tempSelectionRect);
								logger.info("tempSelectionRect.contains(x, y)" + tempSelectionRect.contains(x, y));
							}

						 */


						// We have to calculate within this way - because rect.contains(Point) is always returning false on a 0-width or 0 height Rectangle
						boolean isPointWithinSelectionRect = false;
						if(tempSelectionRect != null){
							if(x <= tempSelectionRect.getMaxX() && x >= tempSelectionRect.getMinX() &&
									y <= tempSelectionRect.getMaxY() && y >= tempSelectionRect.getMinY()){
								isPointWithinSelectionRect = true;
							}
						}


						// draw selection and temp selection
						if(alignment.isBaseSelected(x,y) || (tempSelectionRect != null && isPointWithinSelectionRect)){
							//logger.info("draw select");
							//g2d.setColor( new Color(baseBackgroundColor.getRed(),baseBackgroundColor.getGreen(), baseBackgroundColor.getBlue(),150));

							// This is nice to get just a brighter version of color
							// g2d.setColor( new Color(255,255,255,180));
							// this is nice to see nucleotides when selecting
							baseBackgroundColor = colorScheme.getBaseSelectionBackgroundColor(baseVal);
							baseForegroundColor = colorScheme.getBaseSelectionForegroundColor(baseVal);
							g2d.setColor(baseBackgroundColor);
							g2d.fillRect((int)(x * charWidth), (int)(y * charHeight + getMatrixTopOffset()), (int)charWidth, (int)charHeight);
						}

						// Draw char letter

						g2d.setColor(baseForegroundColor);


						if(charHeight > 7){
							if(! drawAminoAcidCode || !showTranslation){
								g2d.drawBytes(byteToDraw, 0, byteToDraw.length, (int)(x * charWidth + charCenterXOffset), (int)(y * charHeight + getMatrixTopOffset() + charHeight - charCenterYOffset));
							}
						}
					}
				}

			}
		}
		//
		//  End Draw nucleotides
		//


		//
		//  Draw proteins
		//
		else{

			for(int x = matrixClip.x; x <= matrixClip.getMaxX(); x = x+1){
				for(int y = matrixClip.y; y <= matrixClip.getMaxY(); y = y + 1){

					// Only draw part of matrix that exists
					if(y >= 0 && x >= 0 && y < alignment.getBasesMatrix().length && x < alignment.getBasesMatrix()[y].length){  //if(y >= 0 && x >= 0 && y < alignment.getMatrixMaxY() && x < alignment.getMatrixMaxX())

						// Set default
						byte base = alignment.getBaseAt(x,y);
						int baseVal = 0;	// baseVal is needed for coloring

						AminoAcid acid = AminoAcid.getAnminoAcidFromByte(base);

						Color baseForegroundColor = colorScheme.getAminoAcidForgroundColor(acid);
						Color baseBackgroundColor = colorScheme.getAminoAcidBackgroundColor(acid);

						// get char to draw
						byte[] byteToDraw = new byte[1];
						byteToDraw[0]=alignment.getBaseAt(x,y);

						// adjustment if only diff to be shown
						if(onlyDrawDiff){ // TODO CHANGE THIS SO IT IS WORKING EVEN IF TRACING SEQUENCE IS SHORTER THAN OTHER
							if(y != differenceTraceSequencePosition && acid == AminoAcid.getAnminoAcidFromByte(alignment.getBaseAt(x,differenceTraceSequencePosition))){
								byteToDraw[0] = '.';
								baseBackgroundColor = Color.white;
							}
						}

						// TODO Make excludes show up in protein alignments
						g2d.setColor(baseBackgroundColor);
						g2d.fillRect((int)(x * charWidth), (int)(y * charHeight + getMatrixTopOffset()), (int)charWidth, (int)charHeight);


						// We have to calculate within this way - because rect.contains(Point) is always returning false on a 0-width or 0 height Rectangle
						boolean isPointWithinSelectionRect = false;
						if(tempSelectionRect != null){
							if(x <= tempSelectionRect.getMaxX() && x >= tempSelectionRect.getMinX() &&
									y <= tempSelectionRect.getMaxY() && y >= tempSelectionRect.getMinY()){
								isPointWithinSelectionRect = true;
							}
						}


						// draw selection and temp selection
						if(alignment.isBaseSelected(x,y) || (tempSelectionRect != null && isPointWithinSelectionRect)){
							//logger.info("draw select");
							//g2d.setColor( new Color(baseBackgroundColor.getRed(),baseBackgroundColor.getGreen(), baseBackgroundColor.getBlue(),150));

							// This is nice to get just a brighter version of color
							// g2d.setColor( new Color(255,255,255,180));
							// this is nice to see nucleotides when selecting
							baseBackgroundColor = colorScheme.getAminoAcidSelectionBackgroundColor(acid);
							baseForegroundColor = colorScheme.getAminoAcidSelectionForegroundColor(acid);
							g2d.setColor(baseBackgroundColor);
							g2d.fillRect((int)(x * charWidth), (int)(y * charHeight + getMatrixTopOffset()), (int)charWidth, (int)charHeight);
						}

						// Draw char letter

						g2d.setColor(baseForegroundColor);


						if(charHeight > 7){
							if(! drawAminoAcidCode || !showTranslation){
								g2d.drawBytes(byteToDraw, 0, byteToDraw.length, (int)(x * charWidth + charCenterXOffset), (int)(y * charHeight + getMatrixTopOffset() + charHeight - charCenterYOffset));
							}
						}
					}
				}

			}
		}
		//
		//  End Draw aminoacid
		//



		// Draw excludes
		// calculaate height for excludes (this is to avoid drawing below alignment if alignment is not filling panel)
		int drawHeight = (int) Math.min(this.getVisibleRect().getHeight(), alignment.getSize()  * charHeight);
		for(int x = matrixClip.x - 2; x < matrixClip.getMaxX() + 2; x++){

			if(alignment.getExcludes().isExcluded(x) == true){
				g2d.setColor(ColorScheme.GREY_TRANSPARENT);
				g2d.fillRect((int)(x * charWidth), this.getVisibleRect().y, (int)charWidth, drawHeight);				
			}

		}


		long endTime = System.currentTimeMillis();
		logger.info("Alignment pane PaintComponent took " + (endTime - startTime) + " milliseconds");

		// repaint ruler also
		alignmentRuler.repaint();

	}

	public Alignment getAlignmnent() {
		return alignment;
	}

	public void validateSequenceOrder(){
		alignment.updateSequenceOrder();

		// verify that tracing sequence not is out of index
		if(differenceTraceSequencePosition >= alignment.getSize()){
			differenceTraceSequencePosition = 0;
		}

		repaint();
	}

	public void selectSequences(List<aliview.sequences.Sequence> selection){

		// clear current selection
		clearSelection();

		for(aliview.sequences.Sequence seq: selection){
			seq.selectAllBases();
		}
	}

	public int selectWithin(Rectangle rect){

		// First clear	
		alignment.clearSelection();
		int selectionSize = addSelectionWithin(rect);
		repaint();
		return selectionSize;

	}

	public int selectColumnsWithin(Rectangle rect) {
		// First clear	
		alignment.clearSelection();
		int selectionSize = addColumnSelectionWithin(rect);
		repaint();
		return selectionSize;

	}

	public int addColumnSelectionWithin(Rectangle rect){
		int nSelection = 0;
		// calculate what part of alignment matrix is in view (what part of matrix is in graphical view)
		Rectangle bounds = paneCoordToMatrixCoord(rect);

		//logger.info(bounds);

		int columnIndexStart = bounds.x;
		int columnIndexEnd = bounds.x + bounds.width;

		// loop through all alignments and select all bases per columns
		for(Sequence seq: getAlignmnent().sequences){
			seq.selectBases(columnIndexStart, columnIndexEnd);
			nSelection += columnIndexEnd - columnIndexStart + 1; // add 1 extra because we are dealing with indexes
		}

		repaint();
		return nSelection;
	}

	public int addSelectionWithin(Rectangle rect){
		int nSelection = 0;
		// calculate what part of alignment matrix is in view (what part of matrix is in graphical view)
		Rectangle bounds = paneCoordToMatrixCoord(rect);
		//logger.info("selectBounds" + bounds);
		// boolean[][] basesSelectionMatrix = alignment.getBasesSelectionMatrix();
		// loop through the part of alignment matrix that is within selection
		for(int y = (int) bounds.getMinY(); y <= bounds.getMaxY(); y++){
			for(int x = (int)bounds.getMinX(); x <= bounds.getMaxX(); x++){
				// and make sure not outside matrix
				if(y >= 0 && x >= 0 && y < alignment.getBasesMatrix().length && x < alignment.getBasesMatrix()[y].length){
					alignment.setBaseSelection(x,y,true);
					nSelection ++;
				}
			}
		}
		repaint();
		return nSelection;
	}

	public void setTempSelection(Rectangle selectRect) {
		// change rect to matrixCoordSys
		this.tempSelectionRect = paneCoordToMatrixCoord(selectRect);
		repaint();	
	}

	public void clearTempSelection() {
		this.tempSelectionRect = null;
		repaint();
	}

	public Rectangle paneCoordToMatrixCoord(Rectangle rect){

		// TODO problem when calculating a 0-width rect - then it will give eg. xmin=34 xmax=35

		//		logger.info("rect.getMinX()" + rect.getMinX());
		//		logger.info("rect.getMaxX()" + rect.getMaxX());
		//		logger.info("rect.getMinX()/charWidth" + rect.getMinX()/charWidth);
		//		
		int matrixMinX = (int) Math.floor(rect.getMinX()/charWidth); // always round down
		int matrixMaxX = (int) Math.floor(rect.getMaxX()/charWidth); // always round up
		int matrixMinY = (int) Math.floor((rect.getMinY() - getMatrixTopOffset()) /charHeight); // always round down
		int matrixMaxY = (int) Math.floor((rect.getMaxY() - getMatrixTopOffset()) /charHeight); // always round down
		//		logger.info("matrixMinX" + matrixMinX);
		//		logger.info("matrixMaxX" + matrixMaxX);
		////	logger.info(getMatrixTopOffset());
		//		

		Rectangle converted = new Rectangle(matrixMinX, matrixMinY, matrixMaxX - matrixMinX, matrixMaxY - matrixMinY); 
		return converted;
	}

	// todo this should be listening to changes in alignmnet instead
	void updateStatisticsLabel(){

		int height = alignment.getSize();
		int width = alignment.getMaximumSequenceLength();
		logger.info("alignment.getMaximumSequenceLength()" + alignment.getMaximumSequenceLength());

		statisticsLabel.setText("" + height + " sequences, " + width + " bases, reading frame " + readingFrame);



	}

	public void updateSize() {
		// Set component preferred size
		Dimension prefSize = getCalculatedPreferredSize();
		this.setPreferredSize(prefSize);
		this.updateStatisticsLabel();
		this.revalidate();

	}

	@Override
	public Dimension getPreferredSize() {
		return getCalculatedPreferredSize();
	}

	private Dimension getCalculatedPreferredSize(){
		return new Dimension((int) (charWidth * alignment.getMaximumSequenceLength()), (int)(charHeight * alignment.getSize() + getMatrixTopOffset()));
	}

	public Point paneCoordToMatrixCoord(Point pos){

		int matrixX = (int) Math.floor(pos.getX() / charWidth);
		int matrixY = (int) Math.floor((pos.getY() - getMatrixTopOffset()) /  charHeight);
		Point converted = new Point(matrixX, matrixY);	
		return converted;
	}

	public Point matrixCoordToPaneCoord(Point pos){
		int paneX = (int) (pos.getX() * charWidth);
		int paneY = (int) (pos.getY() * charHeight + getMatrixTopOffset());
		Point converted = new Point(paneX, paneY);	
		return converted;
	}


	class InvalidAlignmentPositionException extends Exception{
		/**
		 * 
		 */
		private static final long serialVersionUID = -3246089512355077679L;
		//constructor without parameters
		public InvalidAlignmentPositionException() {}
		//constructor for exception description
		public InvalidAlignmentPositionException(String description)
		{
			super(description);
		}
	}


	public boolean isPointWithinMatrix(Point pos) {
		Point matrixPoint = paneCoordToMatrixCoord(pos);
		return isPositionWithinAlignmentMatrix(matrixPoint.x, matrixPoint.y);
	}

	public void setInteractionMode(int interactionMode) {
		this.interactionMode = interactionMode;
	}

	public int getInteractionMode() {
		return this.interactionMode;
	}

	public double getCharHeight() {
		return this.charHeight;
	}

	public void setDifferenceTraceSequence(Point pos) throws InvalidAlignmentPositionException {

		Point matrixPoint = paneCoordToMatrixCoord(pos);

		Sequence seq = null;
		if(isPositionWithinAlignmentMatrix(matrixPoint.x,matrixPoint.y)){
			// todo this should be changed because problem when removed or moved
			this.differenceTraceSequencePosition = matrixPoint.y;
		}
		else{
			throw new InvalidAlignmentPositionException("Position is out of range" + pos);
		}
		repaint();
	}

	public void setDifferenceTraceSequence(int nIndex){
		this.differenceTraceSequencePosition = nIndex;
	}



	public Sequence getSequenceAt(Point pos) throws InvalidAlignmentPositionException {

		Point matrixPoint = paneCoordToMatrixCoord(pos);

		Sequence seq = null;
		if(isPositionWithinAlignmentMatrix(matrixPoint.x,matrixPoint.y)){
			seq = (Sequence) alignment.getSequences().get(matrixPoint.y);
		}
		else{
			throw new InvalidAlignmentPositionException("Position is out of range" + pos);
		}

		return seq;

	}

	public boolean isWithinExistingSelection(Point point) {
		boolean isSelected = false;

		try {
			Base base = getBaseAt(point);
			if(base != null){
				isSelected = base.isSelected();
			}
		} catch (InvalidAlignmentPositionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return isSelected;


	}

	public void toggleTranslation() {
		this.showTranslation = ! this.showTranslation;
	}

	public void incReadingFrame() {
		this.readingFrame ++;
		if(this.readingFrame > 3){
			this.readingFrame = 1;
		}
		this.updateStatisticsLabel();
	}

	public void decReadingFrame() {
		this.readingFrame --;
		if(this.readingFrame < 1){
			this.readingFrame = 3;
		}
		this.updateStatisticsLabel();

	}

	public AlignmentRuler getRulerComponent(){
		return this.alignmentRuler;
	}

	/*
	public boolean isBaseInView(Base base) {

		Point matrixPos = new Point(base.getPosition(), base.getSequence().getPosition());
		Point panePos = matrixCoordToPaneCoord();

	}this.alignmentRuler.updateSize();
	 */


	class AlignmentRuler extends JPanel{

		private AlignmentPane alignmentPane;

		public AlignmentRuler(AlignmentPane alignmentPane) {
			this.alignmentPane = alignmentPane;
		}

		

		public void repaintRuler(Rectangle matrixClip){
			Graphics g = this.getGraphics();
		}
/*
		public void paintComponent(Graphics g){

			long startTime = System.currentTimeMillis();

			Graphics2D g2d = (Graphics2D) g;

			Rectangle clip = g2d.getClipBounds();
			// grow it so that ugly painting mistakes are avoided when only part of image is drawn

			clip = alignmentPane.getVisibleRect();


			g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
					RenderingHints.VALUE_RENDER_QUALITY);
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			//		
			//			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
			//					RenderingHints.VALUE_ANTIALIAS_OFF);
			//			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
			//					RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
			//			g2d.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
			//					RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
			//			g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
			//					RenderingHints.VALUE_COLOR_RENDER_SPEED);
			//			g2d.setRenderingHint(RenderingHints.KEY_DITHERING,
			//					RenderingHints.VALUE_DITHER_DISABLE);
			//	



			//			// relocate y-axis to bottom 
			//			
			//			//AffineTransform transform = new AffineTransform();
			//
			//
			//	        transform.translate(0, getPanelHeight());
			//	        g2d.setTransform(transform);    
			//
			//	        transform.scale(0.2, 0.2);
			//	        g2d.setTransform(transform);
			//	        clip = g2d.getClipBounds();
			//			 

			g2d.setFont(baseFont);

			// What part of alignment matrix is in view (what part of matrix is in graphical view)
			Rectangle matrixClip = paneCoordToMatrixCoord(clip);


			int rulerHeight = (int) (charHeight * RULER_HEIGHT_IN_CHAR_HEIGHT);

			// todo calculate from font metrics
			double charCenterXOffset = 0.9957;
			double charCenterYOffset = 0.9957;

			// Draw codonpos-ruler
			//
			Rectangle rulerRect = new Rectangle(this.getVisibleRect());
			g2d.setColor(Color.WHITE);
			g2d.fill(rulerRect);


//			// Tickmarks
//			g2d.setColor(Color.DARK_GRAY);
//			int posTick = 0;
//			for(int x = matrixClip.x ; x < matrixClip.getMaxX(); x ++){
//
//				// TODO Ruler tickmark and numbers is off....
//
//				// make every 5 a bit bigger
//				if(x % 5 == 4){ // it has to be 4 and not 0 due to the fact that 1:st base har position 0 in matrix
//					g2d.drawLine((int)(posTick * charCenterXOffset * charWidth + charWidth/2), (int) (rulerRect.getMaxY() - 2), (int)(posTick * charCenterXOffset * charWidth +  charWidth/2), (int)rulerRect.getMaxY() - 5);
//				}
//				// dont draw smallest tick if to small
//				else if(charHeight > 1){
//					g2d.drawLine((int)(posTick * charCenterXOffset * charWidth + charWidth/2), (int) (rulerRect.getMaxY() - 2), (int)(posTick * charCenterXOffset * charWidth +  charWidth/2), (int)rulerRect.getMaxY() - 3);
//				}
//				posTick ++;
//			}
//

			g2d.setColor(Color.DARK_GRAY);
			
			for(int x = matrixClip.x ; x < matrixClip.getMaxX(); x ++){




					String number = Integer.toString(x);
					//int stringSizeOffset = (int)((number.length() * rulerCharWidth) / 2);
					int xPos = (int)(x * charWidth * 0.9);
					g2d.drawString(number, xPos, 10);


			}	
			
			
//
//			for(int x = matrixClip.x ; x < matrixClip.getMaxX(); x ++){
//
//				//char[] codonPos = new char[1];
//				//codonPos[0] = '1';
//				String codonPos = "1";
//				
//				//int xPos = (int)(pos * charWidth - stringSizeOffset);
//				
//				if(charHeight > 7){
//					g2d.drawString(codonPos, (int)(x * charWidth), 10);
//				}
//
//			}	
//			


			long endTime = System.currentTimeMillis();
			logger.info("Ruler PaintComponent took " + (endTime - startTime) + " milliseconds");
		}
	}
	*/
	
	
	public void paintComponent(Graphics g){

		
		long startTime = System.currentTimeMillis();
		
		//super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;

		//Rectangle clip = g2d.getClipBounds();
		// grow it so that ugly painting mistakes are avoided when only part of image is drawn

		Rectangle alignmentPaneClip = alignmentPane.getVisibleRect();


		g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		//		
		//			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		//					RenderingHints.VALUE_ANTIALIAS_OFF);
		//			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
		//					RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		//			g2d.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
		//					RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
		//			g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
		//					RenderingHints.VALUE_COLOR_RENDER_SPEED);
		//			g2d.setRenderingHint(RenderingHints.KEY_DITHERING,
		//					RenderingHints.VALUE_DITHER_DISABLE);
		//	



		//			// relocate y-axis to bottom 
		//			
		//			//AffineTransform transform = new AffineTransform();
		//
		//
		//	        transform.translate(0, getPanelHeight());
		//	        g2d.setTransform(transform);    
		//
		//	        transform.scale(0.2, 0.2);
		//	        g2d.setTransform(transform);
		//	        clip = g2d.getClipBounds();
		//			 

		g2d.setFont(baseFont);

		// What part of alignment matrix is in view (what part of matrix is in graphical view)
		Rectangle matrixClip = paneCoordToMatrixCoord(alignmentPaneClip);


		int rulerHeight = (int) (charHeight * RULER_HEIGHT_IN_CHAR_HEIGHT);
		int topOffset = rulerHeight;

		// todo calculate from font metrics
		double charCenterXOffset = 0.9997;


		
		// Get alignment as a matrix
		// byte[][] basesMatrix = alignment.getBasesMatrix();

		//boolean[][] basesSelectionMatrix = alignment.getBasesSelectionMatrix();
		// loop through the part of alignment matrix that is in view




		//
		// Draw ruler
		//
		Rectangle rulerRect = new Rectangle(this.getVisibleRect());
		g2d.setColor(Color.WHITE);
		g2d.fill(rulerRect);

		int offsetDueToScrollPanePosition = alignmentPaneClip.x % (int)charWidth;
		offsetDueToScrollPanePosition = offsetDueToScrollPanePosition -1;
		
		// Tickmarks
		
		int posTick = 0;
		for(int x = matrixClip.x ; x < matrixClip.getMaxX() + 1; x ++){

			// TODO Ruler tickmark and numbers is off....

			// draw background depending on codonpos
			
			// Only draw part of matrix that exists
			if(x >= 0 && x < alignment.getBasesMatrix()[0].length){  //if(y >= 0 && x >= 0 && y < alignment.getMatrixMaxY() && x < alignment.getMatrixMaxX())

				if(drawCodonPosRuler){
					int codonPos = alignment.getCodonPositions().getPosAt(x);
					Color codonPosColor = Color.GREEN;
					if(codonPos == 0){
						codonPosColor = Color.LIGHT_GRAY;
					}else if(codonPos == 1){
						codonPosColor = Color.yellow;
					}else if(codonPos == 2){
						codonPosColor = Color.orange;
					}else if(codonPos == 3){
						codonPosColor = Color.red;
					}
					
					g2d.setColor(codonPosColor);
					
				    int boxHeight = 4;
					g2d.fillRect((int)(posTick * charCenterXOffset * charWidth - offsetDueToScrollPanePosition), (int) (rulerRect.getMaxY() - 4), (int)charWidth, boxHeight);
					//g2d.fillRect((int)(x * charWidth), (int) (rulerRect.getMaxY() - 4), (int)charWidth, boxHeight);
	
				}
				
			
				g2d.setColor(Color.DARK_GRAY);
				// make every 5 a bit bigger
				if(x % 5 == 4){ // it has to be 4 and not 0 due to the fact that 1:st base har position 0 in matrix
					g2d.drawLine((int)(posTick * charCenterXOffset * charWidth + charWidth/2 - offsetDueToScrollPanePosition), (int) (rulerRect.getMaxY() - 2), (int)(posTick * charCenterXOffset * charWidth +  charWidth/2 - offsetDueToScrollPanePosition), (int)rulerRect.getMaxY() - 5);
				}
				// dont draw smallest tick if to small
				else if(charHeight > 1){
					g2d.drawLine((int)(posTick * charCenterXOffset * charWidth + charWidth/2 - offsetDueToScrollPanePosition), (int) (rulerRect.getMaxY() - 2), (int)(posTick * charCenterXOffset * charWidth +  charWidth/2 - offsetDueToScrollPanePosition), (int)rulerRect.getMaxY() - 3);
				}
				posTick ++;
			}
		}



		// NUMBERS
		int rulerCharWidth = 11;
		int rulerCharHeight = 11;
		Font rulerFont = new Font(baseFont.getName(), baseFont.getStyle(), (int)rulerCharWidth);
		g2d.setFont(rulerFont);

		// Only draw every 100 pos
		int drawEveryNpos = 10;
		if(charHeight < 1){
			drawEveryNpos = 100;
		}else if(charHeight < 4){
			drawEveryNpos = 50;
		}else if(charHeight < 5){
			drawEveryNpos = 20;
		}


		// position numbers
		int pos = 0;
		for(int x = matrixClip.x ; x < matrixClip.getMaxX() + 1; x ++){


			if(x % drawEveryNpos == 0){
				String number = Integer.toString(x);
				int stringSizeOffset = (int)((number.length() * rulerCharWidth) / 2);
				int xPos = (int)(pos * charWidth - stringSizeOffset - offsetDueToScrollPanePosition);
				g2d.drawString(number, xPos, 10);
			}
			pos ++;
		}	




		long endTime = System.currentTimeMillis();
		logger.info("Ruler PaintComponent took " + (endTime - startTime) + " milliseconds");
	}
}

	

	public void setDrawAminoAcidCode(boolean drawCode){
		this.drawAminoAcidCode = drawCode;
	}

	public boolean getDrawAminoAcidCode(){
		return this.drawAminoAcidCode;
	}




}
