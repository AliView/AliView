package aliview;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.IntRange;
import org.apache.log4j.Logger;

import aliview.sequences.Sequence;
import aliview.utils.Utilities;

public class NexusUtilities {
	private static final Logger logger = Logger.getLogger(NexusUtilities.class);


	public static final Excludes updateExcludesFromFile(File alignmentFile, Excludes excludes) {

		logger.info("look for nexus EXSET block in file " + alignmentFile.toString());
		
		
		
		try {
			String alignmentString = FileUtils.readFileToString(alignmentFile).toUpperCase();
			String assumptionsBlock = StringUtils.substringBetween(alignmentString, "BEGIN ASSUMPTIONS;", "END;");
			if(assumptionsBlock == null){
				return null;
			}

			String exsetBlock = StringUtils.substringBetween(assumptionsBlock, "EXSET", ";");
			if(exsetBlock == null){
				return null;
			}

			logger.info("Found block");

			String excludeString = StringUtils.substringAfter(exsetBlock, "=");
			if(excludeString == null){
				return null;
			}
			
			ArrayList<IntRange> allRanges = parseNexusRanges(excludeString);
			
			for(IntRange range: allRanges){
				for(int n = range.getMinimumInteger(); n <= range.getMaximumInteger(); n++){
					excludes.getPositions()[n - 1] = true; // always minus one because alignment start with pos 1 in exset (but 0 internally in program)
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return excludes;
	}
	
	public static final CodonPositions updateCodonPositionsFromNexusFile(File alignmentFile, CodonPositions codonPositions) {

		logger.info("look for nexus BEGIN CODONS; block in file " + alignmentFile.toString());

		
		try {
			String alignmentString = FileUtils.readFileToString(alignmentFile).toUpperCase();
			String codonsBlock = StringUtils.substringBetween(alignmentString, "BEGIN CODONS;", "END;");
			if(codonsBlock == null){
				return null;
			}

			// TODO there could be different codonposset - I just use first one
			String codonPositionsBlock = StringUtils.substringBetween(codonsBlock, "CODONPOSSET", ";");
			if(codonPositionsBlock == null){
				return null;
			}

			logger.info("Found block");
			
			// Always set position n - 1 because program internally is working with first pos in alignment as 0 (and in codonpos block from 1)
			
			
			// TODO with n range does not ends with \3
			
			String nPos = StringUtils.substringBetween(codonPositionsBlock, "N:",",");
			if(nPos != null){	
				ArrayList<IntRange> allRanges = parseNexusRanges(nPos);
				for(IntRange range: allRanges){
					for(int n = range.getMinimumInteger(); n <= range.getMaximumInteger(); n++){
						codonPositions.setPosition(n - 1,0);
					}
				}	
			}
			
			// TODO check that range ends with \3
			
			String pos1 = StringUtils.substringBetween(codonPositionsBlock, "1:",",");
			if(pos1 != null){	
				ArrayList<IntRange> allRanges = parseNexusRanges(pos1);
				for(IntRange range: allRanges){
					for(int n = range.getMinimumInteger(); n <= range.getMaximumInteger(); n=n+3){
						codonPositions.setPosition(n - 1,1);
					}
				}	
			}
			
			String pos2 = StringUtils.substringBetween(codonPositionsBlock, "2:",",");
			if(pos2 != null){	
				ArrayList<IntRange> allRanges = parseNexusRanges(pos2);
				for(IntRange range: allRanges){
					for(int n = range.getMinimumInteger(); n <= range.getMaximumInteger(); n=n+3){
						codonPositions.setPosition(n-1,2);
					}
				}	
			}
			
			String pos3 = StringUtils.substringAfter(codonPositionsBlock, "3:");
			if(pos3 != null){	
				ArrayList<IntRange> allRanges = parseNexusRanges(pos3);
				for(IntRange range: allRanges){
					for(int n = range.getMinimumInteger(); n <= range.getMaximumInteger(); n=n+3){
						codonPositions.setPosition(n - 1,3);
					}
				}	
			}		

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		codonPositions.debug();
		
		return codonPositions;
	}
	
	public static ArrayList<IntRange> parseNexusRanges(String input){
		
		// clean string
		input = input.trim();

		// pad '-' with space to ' - ' to make parsing simpler
		input = input.replaceAll("-", " - ");
		
		// TODO this is very dirty
		input = input.replaceAll("\\\\3", "");
		
		// parse excludestring
		StringTokenizer tokens = new StringTokenizer(input, " ");	
		
		int lastPosIntVal = 0;
		ArrayList<IntRange> allRanges = new ArrayList<IntRange>();
		while(tokens.hasMoreTokens()){			
			String thisToken = tokens.nextToken();
			if(thisToken.equalsIgnoreCase("-")){			
					
				int firstRange = lastPosIntVal;
				String nextToken = tokens.nextToken();
				int lastRange = Integer.parseInt(nextToken);

				allRanges.add(new IntRange(firstRange,lastRange));
			}
			else{
				lastPosIntVal = new Integer(thisToken);
				allRanges.add(new IntRange(lastPosIntVal,lastPosIntVal));
				
			}			
		}
		return allRanges;
	}
	
	
	
	
	
//	BEGIN ASSUMPTIONS;
//	OPTIONS  DEFTYPE=unord PolyTcount=MINSTEPS ;
//	EXSET * UNTITLED  =  1-613 701-833 946-1045 1124-1256 1313-1628 1651-1654 1756-1880 1952-2038 2133-2358 2498-2750 2913-2921 2940-2944 3007-3123 3164-3169 3239-3321 3343-3348 3396-3503 3556-3561 3580-3659 3735-3848 3894-3897 3928-3933 3951-4037 4108-4555;
//	END;
//	
//	
//	BEGIN CODONS;
//		CODONPOSSET * CodonPositions = 
//			N: 1-76 717-720 946-1045 1124-1256 1313-1628 1651-1654 1756-1880 1952-2038 2133-2358 2498-2506 2659-2740 2940-2944 3007-3123 3239-3321 3396-3503 3580-3659 3735-3848 3894-3897 3951-4037 4108-4112 4152-4555, 
//			1: 77-716\3 721-943\3 1046-1121\3 1257-1311\3 1630-1648\3 1655-1754\3 1882-1951\3 2041-2131\3 2360-2495\3 2507-2657\3 2742-2937\3 2945-3005\3 3125-3236\3 3322-3394\3 3505-3577\3 3660-3732\3 3849-3891\3 3898-3949\3 4039-4105\3 4113-4149\3, 
//			2: 78-714\3 722-944\3 1047-1122\3 1258-1312\3 1631-1649\3 1656-1755\3 1883-1949\3 2039-2132\3 2361-2496\3 2508-2658\3 2743-2938\3 2946-3006\3 3126-3237\3 3323-3395\3 3506-3578\3 3661-3733\3 3850-3892\3 3899-3950\3 4040-4106\3 4114-4150\3, 
//			3: 79-715\3 723-945\3 1048-1123\3 1259-1310\3 1629-1650\3 1657-1753\3 1881-1950\3 2040-2130\3 2359-2497\3 2509-2656\3 2741-2939\3 2947-3004\3 3124-3238\3 3324-3393\3 3504-3579\3 3662-3734\3 3851-3893\3 3900-3948\3 4038-4107\3 4115-4151\3;
//		CODESET  * UNTITLED = Universal: all ;
//	END;
	
	
	public static final String getExcludesAsNexusBlock(Excludes excludes) {
		
		ArrayList<IntRange> allRanges = Utilities.boolArrayToListOfTrueIntRanges(excludes.getPositions());
		String exsetBlock =  "BEGIN ASSUMPTIONS;" + "\n";
		exsetBlock += "EXSET * UNTITLED  = "; 
		
		
		for(IntRange range: allRanges){
			if(range.getMinimumInteger() == range.getMaximumInteger()){
				exsetBlock += " " + (range.getMinimumInteger() + 1); // Add one because internally we work with array posiiton 0, but in exset spec first pos is 1 
			}
			else{
				exsetBlock += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1); // Add one because internally we work with array posiiton 0, but in exset spec first pos is 1 
			}
		}
		// end line with a semicolon
		exsetBlock += ";";
		exsetBlock += "\n";
		exsetBlock += "END;";
		
		return exsetBlock;
		
		
		
	}
	
	 public static final String getCodonPosAsNexusBlock(CodonPositions codonPositions) {
			
			String nexusBlock =  "BEGIN CODONS;" + "\n";
			nexusBlock += "CODONPOSSET * CodonPositions =" + "\n";
			
			String posN = " N:"; // should not really be necessary to include this
			String pos1 = " 1:";
			String pos2 = " 2:";
			String pos3 = " 3:";
			
			// add one to all since program internally is working with first pos in alignment as 0
			ArrayList<IntRange> allPos = codonPositions.getAllPositionsAsRanges(0);
			for(IntRange range: allPos){
				posN += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "";
			}
			
			allPos = codonPositions.getAllPositionsAsRanges(1);
			for(IntRange range: allPos){
				pos1 += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "\\3";
			}
			
			allPos = codonPositions.getAllPositionsAsRanges(2);
			for(IntRange range: allPos){
				pos2 += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "\\3";
			}
			
			allPos = codonPositions.getAllPositionsAsRanges(3);
			for(IntRange range: allPos){
				pos3 += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "\\3";
			}
			
			// nexusBlock += posN + "," + "\n";
			
			nexusBlock += posN + "," + "\n";
			nexusBlock += pos1 + "," + "\n";
			nexusBlock += pos2 + "," + "\n";
			nexusBlock += pos3 + ";" + "\n";
			
			nexusBlock += "CODESET  * UNTITLED = Universal: all ;" + "\n";
			nexusBlock += "END;";
			
			return nexusBlock;
		}
	 
	 public static final String getCodonPosAsCharsetNexusBlock(CodonPositions codonPositions) {
			
			String nexusBlock =  "BEGIN SETS;" + "\n";
			
			//String posN = " CHARSET NTH"; 
			String pos1 = " CHARSET 1ST = ";
			String pos2 = " CHARSET 2ND = ";
			String pos3 = " CHARSET 3RD =";
			
//			// add one to all since program internally is working with first pos in alignment as 0
//			ArrayList<IntRange> allPos = codonPositions.getAllPositionsAsRanges(0);
//			for(IntRange range: allPos){
//				posN += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "";
//			}
			
			ArrayList<IntRange> allPos = codonPositions.getAllPositionsAsRanges(1);
			for(IntRange range: allPos){
				pos1 += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "\\3";
			}
			
			allPos = codonPositions.getAllPositionsAsRanges(2);
			for(IntRange range: allPos){
				pos2 += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "\\3";
			}
			
			allPos = codonPositions.getAllPositionsAsRanges(3);
			for(IntRange range: allPos){
				pos3 += " " + (range.getMinimumInteger() + 1) + "-" + (range.getMaximumInteger() + 1) + "\\3";
			}
			
			// nexusBlock += posN + "," + "\n";
			
	//		nexusBlock += posN + ";" + "\n";
			nexusBlock += pos1 + ";" + "\n";
			nexusBlock += pos2 + ";" + "\n";
			nexusBlock += pos3 + ";" + "\n";
			
			nexusBlock += "CHARPARTITION BYPOS = 1STPOS:1ST, 2NDPOS:2ND, 3RDPOS:3RD;" + "\n";
			nexusBlock += "END;";
			
			return nexusBlock;
		}
	
        
     public static final void exportAlignmentAsNexus(Writer out, Alignment alignment, boolean simplified) throws IOException{
    	//String nexus = "";
		
    	out.write("#NEXUS" + "\n");
    	out.write("\n");
    	out.write("BEGIN DATA;" + "\n");
    	out.write("DIMENSIONS  NTAX=" + alignment.getSize() + " NCHAR=" + alignment.getMaximumSequenceLength() + ";" + "\n");
    	out.write("FORMAT DATATYPE=DNA INTERLEAVE=YES GAP=- MISSING=?;" + "\n");
    	out.write("MATRIX" + "\n");
    	out.write("\n");
    	
    	int longestSequenceNameLen = alignment.getLongestSequenceName();
    	int PAD_SIZE = 3;
    	int MAX_LEN = 99;
    	
		for(Sequence seq: alignment.getSequences()){
			if(simplified){
				String name = replaceProblematicChars(seq.getName());
				if(longestSequenceNameLen + PAD_SIZE > MAX_LEN){
					name = StringUtils.substring(name, 0, MAX_LEN - PAD_SIZE);
				}
				out.write("" + StringUtils.rightPad(name,PAD_SIZE) + "" +  new String(seq.getBases()));
				out.write("\n");
			}else{
				out.write("" + StringUtils.rightPad(seq.getCitatedName(),longestSequenceNameLen + PAD_SIZE) + "" +  new String(seq.getBases()));
				out.write("\n");
			}
		}
		
		out.write(";" + "\n");
		out.write("\n");
		out.write("END;" + "\n");
		out.write("\n");
		
		out.write(getExcludesAsNexusBlock(alignment.getExcludes()));
		out.write("\n");
		out.write("\n");
		
		out.write(getCodonPosAsNexusBlock(alignment.getCodonPositions()));
		out.write("\n");
		out.write("\n");
		
		out.write(getCodonPosAsCharsetNexusBlock(alignment.getCodonPositions()));
		out.write("\n");
		out.write("\n");
		
		out.write(getPersonalNexusBlock(alignment.getMaximumSequenceLength()));
		out.write("\n");
		
		out.flush();
		out.close();
     }
     
     private static String replaceProblematicChars(String text){
    	 text = text.replace(' ', '_');
    	 text = text.replace('-', '_');
    	 text = text.replace('\'', '_');
    	 text = text.replace( '?', '_');
    	 text = text.replace( '.', '_');
    	 text = text.replace( '/', '_');
    	 text = text.replace( '|', '_');
    	 text = text.replace( '\"', '_');
    	 text = text.replace( ',', '_');
    	 text = text.replace( '&', '_');
    	 text = text.replace( '\\', '_');
    	 
    	 return text;
     }
     
     public static final void exportAlignmentAsNexusCodonpos(Writer out, Alignment alignment) throws IOException{
     	//String nexus = "";
 	
    	// dump pos
    	
    	 
    	ArrayList<Integer> allPos0 = alignment.getCodonPositions().getAllPositions(0);
    	ArrayList<Integer> allPos1 = alignment.getCodonPositions().getAllPositions(1);
      	ArrayList<Integer> allPos2 = alignment.getCodonPositions().getAllPositions(2);
      	ArrayList<Integer> allPos3 = alignment.getCodonPositions().getAllPositions(3);
    	
//      	for(Integer pos: allPos0){
//      		logger.info(pos.intValue());
//      	}
      	
      	// remove excluded positions
      	alignment.getExcludes().removeExcludedPositions(allPos0);
      	alignment.getExcludes().removeExcludedPositions(allPos1);
      	alignment.getExcludes().removeExcludedPositions(allPos2);
      	alignment.getExcludes().removeExcludedPositions(allPos3);
      	
      	int nChar = allPos0.size() + allPos1.size() + allPos2.size() + allPos3.size();
    	 
     	out.write("#NEXUS" + "\n");
     	out.write("\n");
     	out.write("BEGIN DATA;" + "\n");
     	out.write("DIMENSIONS  NTAX=" + alignment.getSize() + " NCHAR=" + nChar + ";" + "\n");
     	out.write("FORMAT DATATYPE=DNA INTERLEAVE=YES GAP=- MISSING=?;" + "\n");
     	out.write("MATRIX" + "\n");
     	out.write("\n");
 		
     	
     	
 		for(Sequence seq: alignment.getSequences()){
 			
 			// also replace some characters not always understood
 			String seqName = seq.getCitatedName();
 			seqName = seqName.replace(' ','_');
 			
 			out.write("" + StringUtils.rightPad(seqName,100));
 			out.write(seq.getPositionsAsString(allPos0));
 			out.write(seq.getPositionsAsString(allPos1));
 			out.write(seq.getPositionsAsString(allPos2));
 			out.write(seq.getPositionsAsString(allPos3));
 			out.write("\n");
 			
 		}
 		out.write(";" + "\n");
 		out.write("END;" + "\n");
 		out.write("\n");
 		
 		
 		// TODO this is not safe if one pos should be 0-size
 		// Write charset (pos 1, 2 & 3)
 		out.write("BEGIN SETS;" + "\n");
 		
 		int start = 1;
 		int end = 0;
 		if(allPos0.size() > 0){
 	 		end = start + allPos0.size() - 1;
 	 		out.write("charset npos = " + start + "-" + end + ";" + "\n");
 	 		start = end + 1;
 	 	}
 		
 		if(allPos1.size() > 0){
 			end = start + allPos1.size() - 1;
 			out.write("charset 1st = " + start + "-" + end + ";" + "\n");
 			start = end + 1;
 		}
 		
 		if(allPos2.size() > 0){
 			end = start + allPos2.size() - 1;
 			out.write("charset 2nd = " + start + "-" + end + ";" + "\n");
 			start = end + 1;
 		}
 		
 		if(allPos3.size() > 0){
 			end = start + allPos3.size() - 1;
 			out.write("charset 3nd = " + start + "-" + end + ";" + "\n");
 			start = end + 1;
 		}

 		
 		out.write("END;" + "\n");
 		out.write("\n");
 		
 		// end write charsets
 		
// 		out.write(getExcludesAsNexusBlock(alignment.getExcludes()));
// 		out.write("\n");
// 		
// 		out.write(getCodonPosAsNexusBlock(alignment.getCodonPositions()));
// 		out.write("\n");
 		
 		
 		out.flush();
 		out.close();
 		
      }
     
     private static String getPersonalNexusBlock(int seqLen){
    	 StringBuilder block = new StringBuilder();
    	 
    	 block.append("BEGIN MRBAYES;" + "\n");
    	 block.append("charset aligned-WoodsiapgiC-mafft.fasta.nexus = 1-" + seqLen + ";" + "\n");
    	 block.append("Partition ALLDNA = 1:aligned-WoodsiapgiC-mafft.fasta.nexus;" + "\n");
    	 block.append("Set partition = ALLDNA;" + "\n");
    	 block.append("[GTRG]" + "\n");
    	 block.append("["+ "\n");
    	 block.append("Lset applyto=(1) nst=6 rates=gamma;"+ "\n");
    	 block.append("Prset applyto=(1) revmatpr=Dirichlet(1.0,1.0,1.0,1.0,1.0,1.0) statefreqpr=Dirichlet(1.0,1.0,1.0,1.0) shapepr=Uniform(0.1,50.0);"+ "\n");
    	 block.append("]"+ "\n");
    	 block.append("[GTRIG]Lset applyto=(1) nst=6 rates=invgamma;"+ "\n");
    	 block.append("Prset applyto=(1) revmatpr=Dirichlet(1.0,1.0,1.0,1.0,1.0,1.0) statefreqpr=Dirichlet(1.0,1.0,1.0,1.0) shapepr=Uniform(0.1,50.0) pinvarpr=Uniform(0.0,1.0);"+ "\n");

    	 block.append("[SYMG]"+ "\n");
    	 block.append("["+ "\n");
    	 block.append("Lset applyto=(1) nst=6 rates=gamma;"+ "\n");
    	 block.append("Prset applyto=(1) revmatpr=Dirichlet(1.0,1.0,1.0,1.0,1.0,1.0) statefreqpr=Fixed(Equal);"+ "\n");
    	 block.append("]"+ "\n");
    	 block.append("mcmcp nruns=1 ngen=1000000 printfreq=1000 samplefreq=1000 nchains=1 diagnfreq=10000 burninfrac=0.25 stoprule=no stopval=0.002 temp=0.2 checkpoint=yes checkfreq=500000;"+ "\n");
    	 block.append("mcmc;"+ "\n");
    	 block.append("sumt burnin=0.7 nruns=1;"+ "\n");
    	 block.append("END;"+ "\n");
    	 
    	 return block.toString();
    	 
     }
}



