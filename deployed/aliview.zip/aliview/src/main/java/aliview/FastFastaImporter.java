package aliview;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import aliview.sequences.FastFastaSequence;
import aliview.sequences.Sequence;

public class FastFastaImporter {
	private static final Logger logger = Logger.getLogger(FastFastaImporter.class);
	private Reader reader;
	private int longestSequenceLength;

	public FastFastaImporter(Reader reader) {
		this.reader = reader;
	}

	public ArrayList<Sequence> importSequences() {

		long startTime = System.currentTimeMillis();
		ArrayList<Sequence> sequences = new ArrayList<Sequence>();
		try {
			StringBuilder sequence = new StringBuilder();
			BufferedReader r = new BufferedReader(this.reader);
			String line;
			String name = null;
			int nLine = 0;
			while ((line = r.readLine()) != null) {
				
				line = line.trim();
				
				if(nLine == 0){
					// if not fasta file then break
					if(line.length() > 0 && line.charAt(0) != '>'){
						// no fasta
						break;
					}
				}
				
				if(line.length() > 0){

					if(line.charAt(0) == '>'){

						// if there is one sequence in buffer already create that one before starting a new one
						if(name != null && name.length() > 0){
							//char[] bases = new char[sequence.length()];
							//sequence.getChars(0, sequence.length() -1, bases, 0);
							
							//char[] bases = sequence.toString().toCharArray();
							
							// remove blank in string todo this could maybe be done quicker
							// in some fasta files there are blanks (ncbi format)
							String seqAsString = sequence.toString();
							seqAsString = seqAsString.replaceAll(" ","");
							sequences.add(new FastFastaSequence(name, seqAsString));
							this.longestSequenceLength = Math.max(this.longestSequenceLength, seqAsString.length());
							sequence = new StringBuilder();
							name = null;
						}	
						name = line;
					}
					else{
						sequence.append(line);
					}

				}
				nLine ++;
			}
			
			// add last sequence
			if(name != null && name.length() > 0){
				
				String seqAsString = sequence.toString();
				seqAsString = seqAsString.replaceAll(" ","");
				sequences.add(new FastFastaSequence(name, seqAsString));
				this.longestSequenceLength = Math.max(this.longestSequenceLength, seqAsString.length());
				name = null;
			}	
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		System.out.println("reading sequences took " + (endTime - startTime) + " milliseconds");

		return sequences;
	}

	public int getLongestSequenceLength() {
		return longestSequenceLength;
	}
}
