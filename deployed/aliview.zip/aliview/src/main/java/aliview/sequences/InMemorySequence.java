package aliview.sequences;


public abstract class InMemorySequence extends Sequence {

	private byte[] bases;

	public byte[] getBases(){
		return this.bases;
	}
	
	/*
	 * This should be handled differently with an editable mode or not (depending on array backend)
	 */
	public void setBases(byte[] bases, boolean[] baseSelection){
		this.bases = bases;
		// also create a new selection matrix
		if(baseSelection != null && baseSelection.length == bases.length){
			this.baseSelection = baseSelection;
		}
		else{
			this.baseSelection = new boolean[bases.length];
		}
		
	}
	
}
