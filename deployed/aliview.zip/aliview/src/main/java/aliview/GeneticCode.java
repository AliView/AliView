package aliview;

public class GeneticCode {
	
	private final static int CODE_STATES = 64;
	
	public static final GeneticCode DEFAULT = new GeneticCode("FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG");
	
	public final AminoAcid[] acidTranslation = new AminoAcid[CODE_STATES];
	
	public GeneticCode(String codeString){
		for(int n = 0; n < CODE_STATES; n++){
			acidTranslation[n] = AminoAcid.getAnminoAcidFromChar(codeString.charAt(n));
		}
	}
	
}
