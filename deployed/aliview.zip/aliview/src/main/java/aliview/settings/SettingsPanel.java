package aliview.settings;

import javax.swing.JPanel;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.regex.Pattern;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SettingsPanel extends JPanel{
	private JTextField textMinPrimLen;
	private JTextField textMaxPrimLen;
	private JTextField textDimerReportThreashold;
	private JFrame parentFrame;
	
	public SettingsPanel(JFrame parFrame) {
		this.parentFrame = parFrame;
		GridLayout gridLayout = new GridLayout(0,2,3,3);
		this.setLayout(gridLayout);
		
		JLabel lblMinPrimerLength = new JLabel("Min primer Length (" + 
				                     Settings.getMinPrimerLength().getMinIntVal() + "-" + Settings.getMinPrimerLength().getMaxIntVal() + ")");
		textMinPrimLen = new JTextField();
		textMinPrimLen.setText("" + Settings.getMinPrimerLength().getIntValue());
	
		JLabel lblMaxPrimerLength = new JLabel("Max primer Length (" + 
                Settings.getMaxPrimerLength().getMinIntVal() + "-" + Settings.getMaxPrimerLength().getMaxIntVal() + ")");
		textMaxPrimLen = new JTextField();
		textMaxPrimLen.setText("" + Settings.getMaxPrimerLength().getIntValue());
		
		JLabel lblDimerReportThreashold = new JLabel("DimerReportThreashold (" + 
                Settings.getDimerReportThreashold().getMinIntVal() + "-" + Settings.getDimerReportThreashold().getMaxIntVal() + ")");
		textDimerReportThreashold = new JTextField();
		textDimerReportThreashold.setText("" + Settings.getDimerReportThreashold().getIntValue());
		
		
		add(lblMinPrimerLength);
		add(textMinPrimLen);
		
		add(lblMaxPrimerLength);
		add(textMaxPrimLen);
		
		add(lblDimerReportThreashold);
		add(textDimerReportThreashold);
		
		add(new JLabel(""));
		add(new JLabel(""));
		
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveSettings();
				parentFrame.dispose();
			}
		});
		add(btnOk);
		add(new JLabel(""));
		
		/*
		Pattern regex = Pattern.compile("10-20");
	    RegexInputVerifier verifier = new RegexInputVerifier(regex, RegexInputVerifier.UseToolTip.FALSE, "20");
	    
	    textMinPrimLen.setToolTipText("Value has to be between...");
		textMinPrimLen.setInputVerifier(verifier);
		*/
		
	}
	
	public void saveSettings(){
		try {
			Settings.getMinPrimerLength().putIntValue(Integer.parseInt(textMinPrimLen.getText()));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			Settings.getMaxPrimerLength().putIntValue(Integer.parseInt(textMaxPrimLen.getText()));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			Settings.getDimerReportThreashold().putIntValue(Integer.parseInt(textDimerReportThreashold.getText()));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	

}
