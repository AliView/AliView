package aliview;

import java.util.ArrayList;

import aliview.sequences.Sequence;

public abstract class Matrix{
	
	// TODO Maybe change to somewhere else
	public int getSequenceType() {
		if(getSequences() != null && getSequences().size() > 0){
			return getSequences().get(0).getSequenceType();
		}
		else{
			return Sequence.TYPE_UNKNOWN;
		}
	}

	public abstract ArrayList<Sequence> getSequences();
	
	public abstract int getLongestSequenceLength();
	

}
