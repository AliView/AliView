package aliview.color;

import java.awt.Color;

import aliview.AminoAcid;

public class DefaultColorScheme extends AlignColorScheme {

}
