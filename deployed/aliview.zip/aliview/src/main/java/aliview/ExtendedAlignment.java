package aliview;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import utils.ListUtils;
import utils.MyUtils;

import com.sun.org.apache.xpath.internal.FoundIndex;

import jebl.evolution.io.FastaImporter;
import jebl.evolution.io.ImportException;
import jebl.evolution.io.NexusImporter;
import jebl.evolution.sequences.Sequence;
import jebl.evolution.sequences.SequenceType;

public class ExtendedAlignment {
	private static final Logger logger = Logger.getLogger(ExtendedAlignment.class);

	private List<SequenceWrapper> wrappedSequences;

	private File alignmentFile;

	private List<Integer> excludes;
	
	public ExtendedAlignment(File alignmentFile) throws ImportException, IOException{
		this.alignmentFile = alignmentFile;
		wrappedSequences = getWrappedSequencesFromFile(alignmentFile);
	}
	
	public List<SequenceWrapper> getWrappedSequences(){
		return wrappedSequences;
	}
	
	public String[] filterOutSequences(String filter){
		
		filter = MyUtils.wildcardToRegex(filter);

		List<SequenceWrapper> toBeRemoved = new ArrayList<SequenceWrapper>();
		for(SequenceWrapper seq: this.wrappedSequences){
			
			/*
			if(seq.getFullName().contains(filter)){
				toBeRemoved.add(seq);
			}*/
			
			 if(Pattern.matches(filter, seq.getFullName())){
				 toBeRemoved.add(seq);
			 }
			
		}
		
		// save names of removed sequences
		String[] removedNames = new String[toBeRemoved.size()];
		for(int n = 0; n < toBeRemoved.size(); n++){
			removedNames[n] = toBeRemoved.get(n).getFullName();
		}
		
		this.wrappedSequences.removeAll(toBeRemoved);
		
		return removedNames;
		
	}
	
	
	public String getName(){
		return alignmentFile.getName();
	}
	
	
	
	private List<SequenceWrapper> getWrappedSequencesFromFile(File alignmentFile) throws ImportException, IOException{
		
		List<SequenceWrapper> wrappedSequences = new ArrayList<SequenceWrapper>();
		

			List<Sequence> sequences = null;

			// First try nexus
			try{
				NexusImporter importer = new NexusImporter(new FileReader(alignmentFile));
				sequences = importer.importSequences();
			}catch (Exception nexExc) {
				
				// nexus didn't work - try fasta
				try{
					FastaImporter importer = new FastaImporter(new FileReader(alignmentFile),SequenceType.NUCLEOTIDE);
					sequences = importer.importSequences();
				}catch (Exception e) {
					
				}			
				
			}

			
			for(Sequence seq: sequences){
				wrappedSequences.add(new SequenceWrapper(seq));
				logger.info(seq.getTaxon());
			}
			
			// get Exset for this alignment
			this.excludes = getExcludesFromAlignmentFile(alignmentFile);
			
			logger.info("sequencesSize=" + sequences.size());
			
			
			Collections.sort(wrappedSequences);
			List<SequenceWrapper> dupes = ListUtils.getToStringDupes(wrappedSequences);
			
			
			logger.info("dupesize=" + dupes.size());
			for(SequenceWrapper dupe: dupes){
				logger.info("dupe: " + dupe.getFullName());
				logger.info("shortName: " + dupe.getSimpleName());
			}
			
		
		return wrappedSequences;
	
	}

	public int getExcludesSize(){
		if(excludes == null){
			return 0;
		}
		return excludes.size();
	}
	
	private List<Integer>getExcludesFromAlignmentFile(File alignmentFile) {
		
		ArrayList<Integer> excludes = new ArrayList<Integer>();
		
		try {
			String alignmentString = FileUtils.readFileToString(alignmentFile).toUpperCase();
			String assumptionsBlock = StringUtils.substringBetween(alignmentString, "BEGIN ASSUMPTIONS;", "END;");
			if(assumptionsBlock == null){
				return null;
			}

			String exsetBlock = StringUtils.substringBetween(assumptionsBlock, "EXSET", ";");
			if(exsetBlock == null){
				return null;
			}
			
			logger.info("Found block");
			
			String excludeString = StringUtils.substringAfter(exsetBlock, "=");
			if(excludeString == null){
				return null;
			}
			
			// clean string
			excludeString = excludeString.trim();
			
			// pad '-' with space to ' - ' to make parsing simpler
			excludeString = excludeString.replaceAll("-", " - ");

		    // parse excludestring
			StringTokenizer tokens = new StringTokenizer(excludeString, " ");		
			while(tokens.hasMoreTokens()){			
				String thisToken = tokens.nextToken();
				if(thisToken.equalsIgnoreCase("-")){			
					// remove last value and use it as range	
					int firstRange = excludes.remove(excludes.size() - 1).intValue();
					String nextToken = tokens.nextToken();
					int lastRange = Integer.parseInt(nextToken);
					
					for(int rangeVal = firstRange; rangeVal <= lastRange; rangeVal++){
						//System.err.println("addingVal" + rangeVal);
						excludes.add(new Integer(rangeVal));
					}
				}
				else{
					excludes.add(new Integer(thisToken));
				}			
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return excludes;
		
	}
	
	
	
	

	public List<Integer> getExcludes() {
		// TODO Auto-generated method stub
		return excludes;
	}
	
	public List<SequenceWrapper> getSimpleNameDuplicates() {
		/*
		Collections.sort(wrappedSequences);
		List<SequenceWrapper> dupes = ListUtils.getToStringDupes(wrappedSequences);
		return dupes;
		*/
		List<SequenceWrapper> duplicateSequences = new ArrayList<SequenceWrapper>();
		
		for(SequenceWrapper compareSeq: wrappedSequences){
			
			for(SequenceWrapper nextSequence: wrappedSequences){
				if(! compareSeq.equals(nextSequence) && compareSeq.getSimpleName().equals((nextSequence.getSimpleName()))){
					// add compared sequence if it not is there already
					if(! duplicateSequences.contains(nextSequence)){
						duplicateSequences.add(nextSequence);
					}
				}
			}	
		}
		return duplicateSequences;
		
		
	}

	public boolean containsSimpleName(String seqName) {
		
		boolean foundName = false;
		for(SequenceWrapper seq: wrappedSequences){
			if(seqName.equals(seq.getSimpleName())){
				foundName = true;
				break;
			}
		}
		
		return foundName;
	}

}
