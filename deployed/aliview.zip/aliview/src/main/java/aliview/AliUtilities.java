package aliview;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;

import javax.swing.AbstractButton;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.log4j.Logger;

import aliview.utils.OSNativeUtils;

public class AliUtilities {
	private static final Logger logger = Logger.getLogger(AliUtilities.class);
	private static int preferedWidth = 650;
	private static int preferedHeight = 450;

	public static File selectOpenFileViaChooser(File suggestedFile, Component parentComponent){

		File selectedFile = null;
	
		// If mac or windows open FileDialog
		if(false) { // OSNativeUtils.isMac()
			// get Frame
			Component root = SwingUtilities.getRoot(parentComponent);
	        Frame parentFrame = null;
	        if (root instanceof Frame) {
	        	parentFrame = (Frame) root;
	        }
			// use the native file dialog on the mac
			FileDialog dialog = new FileDialog(parentFrame, "Open",FileDialog.LOAD);
			dialog.setDirectory(suggestedFile.getParent());
			dialog.setVisible(true);
			String fileDirectory = dialog.getDirectory();
			String fileName = dialog.getFile();
			if(fileName != null){
				selectedFile = new File(fileDirectory, fileName);
			}
		}
		else{

			// Else JFileChooser
			Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
			UIManager.put("FileChooser.readOnly", Boolean.TRUE);  

			JFileChooser fc = new JFileChooser(suggestedFile);
			fc.setPreferredSize(new Dimension(preferedWidth, preferedHeight));

			/*
			AbstractButton button = SwingUtilities.getDescendantOfType(AbstractButton.class,
				      fc, "Icon", UIManager.getIcon("FileChooser.detailsViewIcon"));
			button.doClick();
			 */

			int returnVal = fc.showOpenDialog(parentComponent);


			UIManager.put("FileChooser.readOnly", old);  


			if (returnVal == JFileChooser.APPROVE_OPTION) {
				selectedFile = fc.getSelectedFile();
			} else {
				selectedFile = null;
			}
		
			preferedWidth = fc.getSize().width;
			preferedHeight = fc.getSize().height;
		}
		
		System.out.println("selectedfile" + selectedFile);

		return selectedFile;

	}


	public static File selectSaveFileViaChooser(File suggestedFile, Component parentComponent){

		File selectedFile = null;	

		
		if(false) { // OSNativeUtils.isMac()
			logger.info("isMac");
			// get Frame
			Component root = SwingUtilities.getRoot(parentComponent);
	        Frame parentFrame = null;
	        if (root instanceof Frame) {
	        	parentFrame = (Frame) root;
	        }
			// use the native file dialog on the mac
			FileDialog dialog = new FileDialog(parentFrame, "Save",FileDialog.SAVE);
			dialog.setDirectory(suggestedFile.getParent());
			dialog.setFile(suggestedFile.getName());
			dialog.setVisible(true);
			String fileName = dialog.getFile();
			String directory = dialog.getDirectory(); 
			if(fileName != null && directory != null){
				selectedFile = new File(directory, fileName);
			}
		}
		
		
		else{

			// Else JFileChooser

			// Store old value temp until we ase done
			//Boolean old = UIManager.getBoolean("FileChooser.readOnly");  
			//UIManager.put("FileChooser.readOnly", Boolean.TRUE);  

			// Cannot set file in constructor, then only directory and not also filename is suggested in chooser
			
			
			//FileNameExtensionFilter filter = new FileNameExtensionFilter(
			//        "JPG & GIF Images", "jpg", "gif");
			
			
			JFileChooser fc = new JFileChooser();
			//fc.setFileFilter(filter);
			fc.setSelectedFile(suggestedFile);
			fc.setPreferredSize(new Dimension(preferedWidth, preferedHeight));


			
			int returnVal = fc.showSaveDialog(parentComponent);


			// UIManager.put("FileChooser.readOnly", old);  

			if (returnVal == JFileChooser.APPROVE_OPTION) {
				selectedFile = fc.getSelectedFile();
			} else {
				selectedFile = null;
			}

			preferedWidth = fc.getSize().width;
			preferedHeight = fc.getSize().height;
		}

		return selectedFile;
	}
	
	/*
	 
	  public static File saveFileViaChooser(File theFile, String suffix, InputStream fileStream, JComponent dialogParent){
        // Flagga som håller koll på om sparning lyckats
        boolean fileSaved = false;
        
        System.err.println("Inne i saveFileViaChooser");
        
        // Skapa den panel som visas för användaren
        JFileChooser fileChooser = new JFileChooser();
        //fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); 
		
		// Om inte suffix är specifierat använd eventuellt suffix som finns i filnamn
		if(suffix == null){		
		    suffix = Utilities.getFileSuffix(theFile);		    
		}
		
		System.err.println("Hit");
		
		fileChooser.setFileSystemView(FileSystemView.getFileSystemView());
		
		fileChooser.setSelectedFile(theFile);
		       		       
		while(fileChooser.showSaveDialog(dialogParent) == JFileChooser.APPROVE_OPTION){
		    boolean shouldSaveFile = true;
		    theFile = fileChooser.getSelectedFile();
		    
		    // Lägg eventuellt till suffix
		    theFile = Utilities.assureFileSuffix(theFile, suffix);
		    

		    // Kolla om filen redan finns
		    if(theFile.exists()){
		        String question = theFile.toString() + ",\n" +
		                          "finns redan, vill du ersätta den?";
		        int result = JOptionPane.showOptionDialog(dialogParent,
		                                                   question,
		                                                   "Ersätt?",
		                                                   JOptionPane.YES_NO_OPTION,
                                                           JOptionPane.QUESTION_MESSAGE,
                                                           null,
                                                           new Object[]{"Ja","Nej"},
                                                           "Nej"
                                                           );
                // Användaren ville ej skriva över
                if(result == JOptionPane.NO_OPTION){
                    shouldSaveFile = false;
                }
                else{
                    // Kolla om det går att skriva över filen
                	if(! theFile.canWrite()){
                	    System.err.println("Kan inte skriva");
                		JOptionPane.showOptionDialog(dialogParent,
		                                                   "Det går inte att ersätta filen,\n" +
		                                                   "den kanske används eller är skrivskyddad.",
		                                                   "Går ej att ersätta",
		                                                   JOptionPane.OK_OPTION,
                                                           	JOptionPane.WARNING_MESSAGE,
                                                           	null,
                                                           	new Object[]{"Ok"},
                                                           	"Ok"
                                                           	);
                                                           	
                		shouldSaveFile = false;
                	}
                	
               }
               
                
            }
            
		    // Spara filen   
            if(shouldSaveFile){
		        
		        // Ställ in flaggan så som det skall vara
                fileSaved = Utilities.saveStreamAsFile(fileStream, theFile);
                
                if(fileSaved){
	     	        break;
	     	    }
	     	    else{
	     	        JOptionPane.showOptionDialog(dialogParent,
		                                                   "Det gick inte att spara filen,\n" +
		                                                   "kanske det saknas rättigheter\n" + 
		                                                   "eller den kanske används.",
		                                                   "Går ej att spara",
		                                                   JOptionPane.OK_OPTION,
                                                           	JOptionPane.WARNING_MESSAGE,
                                                           	null,
                                                           	new Object[]{"Ok"},
                                                           	"Ok"
                                                           	);  
	     	        
	     	    }
	        }
	                
 
	   }
		
		if(fileSaved){
		    return theFile;
		}
		else{
		    return null;
		}
	}
	
	*/
	 

}
