package scripts.bio.blast;

import java.io.File;

import ncbi.blast.result.generated.Hit;

public class BlastHit {
	private Hit hit;
	private File sequenceFile;

	public BlastHit(Hit hit, File sequenceFile){
		
		this.hit = hit;
		this.sequenceFile = sequenceFile;
		
	}

	public Hit getHit() {
		return hit;
	}

	public File getDownloadedFile() {
		// TODO Auto-generated method stub
		return sequenceFile;
	}
	
	

}
