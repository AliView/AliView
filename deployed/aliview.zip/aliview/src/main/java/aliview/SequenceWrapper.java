package aliview;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import jebl.evolution.sequences.BasicSequence;
import jebl.evolution.sequences.Sequence;
import jebl.evolution.sequences.SequenceType;
import jebl.evolution.taxa.Taxon;

public class SequenceWrapper implements Comparable<SequenceWrapper>{
	private static final Logger logger = Logger.getLogger(SequenceWrapper.class);

	private static SequenceNameFormatter nameFormater = new DefaultSequenceNameFormatter();

	private Sequence seq;
	private String simpleName;

	public SequenceWrapper(Sequence seq) {
		this.seq = seq;
	}

	public String getSimpleName(){	
		return nameFormater.format(seq.getTaxon().getName());	
	}

	public static void setNameFormater(SequenceNameFormatter nameFormater) {
		SequenceWrapper.nameFormater = nameFormater;
	}

	public int compareTo(SequenceWrapper anotherSeq) {
		return this.getSimpleName().compareTo(anotherSeq.getSimpleName());
	}

	public String getFullName() {
		return seq.getTaxon().getName();
	}

	public String toString(){
		return getSimpleName();
	}

	public String getSequenceString(boolean useExset,List<Integer> excludes){

		if(useExset && excludes != null && excludes.size() != 0){
			StringBuffer sb = new StringBuffer(seq.getString());

			// delete in reverse order otherwise it gets wrong
			for(int n = excludes.size() - 1; n >= 0; n-- ){
				Integer exclude = excludes.get(n);
				sb.deleteCharAt(exclude.intValue() -1 ); // To adjust for excludes counting first char in sequence as 1
			}		
			return sb.toString();

		}
		else{	
			return seq.getString();
		}

	}

	public int getSequenceLength(boolean useExset,List<Integer> excludes) {
		return getSequenceString(useExset, excludes).length();
	}

	/*
	public Sequence getSequence() {
		return seq;
	}
	 */

	public SequenceWrapper getCloneFilledWithMissing(String taxonName) {
		StringBuffer sequenceContents = new StringBuffer();
		for(int n=0; n < this.seq.getLength(); n++){
			sequenceContents.append("?");
		}
		Sequence clone = new BasicSequence(SequenceType.NUCLEOTIDE, Taxon.getTaxon(taxonName), sequenceContents.toString());
		return new SequenceWrapper(clone);
	}


}
