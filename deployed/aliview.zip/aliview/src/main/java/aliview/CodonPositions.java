package aliview;

import java.util.ArrayList;

import jebl.evolution.align.NeedlemanWunsch;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.math.IntRange;
import org.apache.log4j.Logger;

import aliview.utils.Utilities;

public class CodonPositions implements Cloneable{
	private static final Logger logger = Logger.getLogger(CodonPositions.class);
	private int[] positionsArray;
	private int readingFrame;
	
	public CodonPositions(int length) {
		setPositionsArray(new int[length]);
		fillArrayWith123(getPositionsArray());
	}
	
	private CodonPositions(int[] positionsArray, int readingFrame) {
		this.setPositionsArray(positionsArray);
		this.readingFrame = readingFrame;
	}

	private void fillArrayWith123(int[] array){
		for(int n = 0; n < array.length; n++){
			int posVal = (n % 3) + 1;
			array[n] = posVal;
		}
//		
//		for(int n = 0; n < array.length; n++){
//			
//			logger.info(array[n]);
//		}
		
	}

	public boolean isFullCodonStartingAt(int x) {
		boolean isFullCodon = false;
		if(x >= 0 && x < getPositionsArray().length - 2){
			
			if(getReadingFrame() == 1){
				if(getPositionsArray()[x] == 1 && getPositionsArray()[x+1] == 2 && getPositionsArray()[x+2] == 3){
					isFullCodon = true;
				}
			}
			
			if(getReadingFrame() == 2){
				if(getPositionsArray()[x] == 2 && getPositionsArray()[x+1] == 3 && getPositionsArray()[x+2] == 1){
					isFullCodon = true;
				}
			}
			
			if(getReadingFrame() == 3){
				if(getPositionsArray()[x] == 3 && getPositionsArray()[x+1] == 1 && getPositionsArray()[x+2] == 2){
					isFullCodon = true;
				}
			}
			
		}
		return isFullCodon;
	}
	
	/*
	public void updateCodonPositionsToDefault123BetweenExset(Excludes exset){

		// create a new one
		this.positionsArray = new int[exset.getPositions().length];
		
		int includedCounter = 0;
		for(int n = 0; n < exset.getPositions().length; n++){
			
			if(exset.isExcluded(n)){
				getPositionsArray()[n] = 0;
			}else{		
				int posVal = (includedCounter % 3) + 1;
				getPositionsArray()[n] = posVal;
				includedCounter ++;
			}	
		}
	}
*/
	
	
	public ArrayList<IntRange> getAllPositionsAsRanges(int wanted) {
		ArrayList<IntRange> allRanges = new ArrayList<IntRange>();
		int lastPos = -1;
		int firstPos = -1;
		
		
		// look at uninterupted ranges of the wanted codonInteger at every third position
		// loop all position three times, start in position 0 (offset) and after that start in pos 1 and pos 2
		for(int offset = 0; offset <= 2; offset++){
			for(int n = offset; n < getPositionsArray().length; n = n +3){
				if(getPositionsArray()[n] == wanted){
					if(firstPos == -1){
						firstPos = n;
					}
					lastPos = n;
				}else{
					// if there is a firstPos define range
					if(firstPos != -1){
						IntRange range = new IntRange(firstPos,lastPos);
						allRanges.add(range);
					}
					// start a new range
					firstPos = -1;
					lastPos = -1;
				}
			}
			// And at end of offset
			// if there is a firstPos define range
			if(firstPos != -1){
				IntRange range = new IntRange(firstPos,lastPos);
				allRanges.add(range);
			}
			// start a new range
			firstPos = -1;
			lastPos = -1;
		}
		
		return allRanges;

	}

	public void setReadingFrame(int readingFrame) {
		this.readingFrame = readingFrame;
	}

	public int getReadingFrame() {
		return readingFrame;
	}

	public ArrayList<Integer> getAllPositions(int wanted) {
		ArrayList<Integer> allPos = new ArrayList<Integer>();
		for(int n = 0; n < getPositionsArray().length; n++){
			if(getPositionsArray()[n] == wanted){
				allPos.add(new Integer(n));
			}	
		}
		return allPos;
	}

	public void setPosition(int pos, int val) {
		if(pos >= 0 && val < getPositionsArray().length){
			getPositionsArray()[pos] = val;
		}
		
	}

	public void debug() {
		for(int n = 0; n < getPositionsArray().length; n++){
	//		logger.info(positionsArray[n]);
		}
		
	}

	public void reverse() {
		ArrayUtils.reverse(getPositionsArray());
		// turn posval 3 into 1 and 1 into 3
		for(int n = 0; n < getPositionsArray().length; n++){
			if(getPositionsArray()[n] == 3){
				getPositionsArray()[n] = 1;
			}
			else if(getPositionsArray()[n] == 1){
				getPositionsArray()[n] = 3;
			}
		}
		
	}
	
	@Override
	protected CodonPositions clone() throws CloneNotSupportedException {
		
		int[] arrayClone = getPositionsArray().clone(); 
		CodonPositions aClone = new CodonPositions(arrayClone, this.readingFrame);
		
		return aClone;
		
	}

	public int[] getPositionsArray() {
		return positionsArray;
	}

	public void setPositionsArray(int[] positionsArray) {
		this.positionsArray = positionsArray;
	}

	public int getPosAt(int x) {
		return this.positionsArray[x];
	}

}
