package scripts.bio.blast;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import ncbi.blast.result.generated.BlastOutput;
import ncbi.blast.result.generated.BlastOutputIterations;
import ncbi.blast.result.generated.Hit;
import ncbi.blast.result.generated.Hsp;
import ncbi.blast.result.generated.Iteration;
import ncbi.blast.result.generated.IterationHits;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class BlastPrimerEvaluation {
	
	private static final Logger logger = Logger.getLogger(BlastPrimerEvaluation.class);
	
	private ArrayList<BlastHit> isNotInSequenceDirButOtherPrimerDir = new ArrayList<BlastHit>();
	private ArrayList<BlastHit> isNotInSequenceDirAndIsTopHit = new ArrayList<BlastHit>();
	
	public BlastPrimerEvaluation(){
	}
	
	
	
	public ArrayList<BlastHit> getIsNotInSequenceDirButOtherPrimerDir() {
		return isNotInSequenceDirButOtherPrimerDir;
	}



	public ArrayList<BlastHit> getIsNotInSequenceDirAndIsTopHit() {
		return isNotInSequenceDirAndIsTopHit;
	}
	
	public void primer_blast_and_evaluation(File primer1QueryFile, File primer2QueryFile){

		String BLAST_RESULT_FILE_NAME = "blast_query_result.xml";
		String LOCAL_BLAST_TRANSCRIPT_DB = "/opt/all_transcriptomes_local_blastDB";
		boolean blastRemote = false;
		boolean blastDustFilter = false;
		
		//File outputParentDir1 = primer1QueryFile.getParentFile();
		//File outputParentDir2 = primer2QueryFile.getParentFile();

		try {
			// Make subdir for this question
			String queryName1 = "blast_out_" + primer1QueryFile.getName();
			File queryDir1 = new File(primer1QueryFile.getParent(), queryName1);
			
			// if dir already exists - save old one as ".bak"
			if(queryDir1.exists()){
				Date nowDateAndTime = new Date();
				String formatedDateAndTime = new SimpleDateFormat("yyyyMMdd_HH-mm-ss").format(nowDateAndTime);
				logger.info(formatedDateAndTime);
				FileUtils.moveDirectory(queryDir1, new File(queryDir1.getPath() + "." + formatedDateAndTime + ".bak"));
			}
			FileUtils.forceMkdir(queryDir1);

			// Save query result in output folder
			File blastResultFile1 = new File(queryDir1, BLAST_RESULT_FILE_NAME);

			// blast
			Blaster.blast(primer1QueryFile, blastResultFile1, "blastn", 1000, 7, blastDustFilter, LOCAL_BLAST_TRANSCRIPT_DB, blastRemote);
			
			
			// Switch off logging
			Level savedLoggerLevel = logger.getLevel();
			logger.setLevel(Level.ERROR);
			
			// 
			evaluatePrimerFromBlastResult(blastResultFile1, LOCAL_BLAST_TRANSCRIPT_DB, queryDir1, null, primer1QueryFile.getParentFile());
			
			
			// Same for primer 2
			String queryName2 = "blast_out_" + primer2QueryFile.getName();
			File queryDir2 = new File(primer2QueryFile.getParent(), queryName2);
			FileUtils.forceMkdir(queryDir2);

			// Save query result in output folder
			File blastResultFile2 = new File(queryDir2, BLAST_RESULT_FILE_NAME);

			// blast
			Blaster.blast(primer2QueryFile, blastResultFile2, "blastn", 1000, 7, false, LOCAL_BLAST_TRANSCRIPT_DB, blastRemote);
			
			System.out.println("");
			System.out.println("------------------------############------------------------");
			System.out.println("");
			
			
			evaluatePrimerFromBlastResult(blastResultFile2, LOCAL_BLAST_TRANSCRIPT_DB, queryDir2, queryDir1, primer2QueryFile.getParentFile());
			
			logger.setLevel(savedLoggerLevel);
	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}



	private void evaluatePrimerFromBlastResult(File blastResultFile, String blastDatabase, File thisPrimerDirectory, File otherPrimerDirectory, File designedSequenceDirectory){
		
		try {
			// Parse result
			JAXBContext jc = JAXBContext.newInstance(BlastOutput.class);
			Unmarshaller u = jc.createUnmarshaller();
			BlastOutput blastOut = (BlastOutput) u.unmarshal(blastResultFile);

			BlastOutputIterations blastOutIterations = blastOut.getBlastOutputIterations();
			List<Iteration> blastOutIteration = blastOutIterations.getIteration();

			int totalHits = 0;
			int bestIterationNumberOfHits = 0;
			double bestIterationBitScore = 0;
			double totalUniqueSequencesBitScore = 0;
			double totalBitScore = 0;
			int nIterations = 0;
			int bestIterationUniqueSpeciesNumber = 0;
			int nTotalUniqueSpecies = 0;

			// container to store unique sequences in result
			HashSet<String> uniqueSequences = new HashSet<String>();


			// For each iteration (which is one query result each) 
			for(Iteration blastIteration: blastOutIteration){

				logger.info("iteration=" + nIterations);


				// first iteration is filled with hits
				IterationHits iterationHits = blastIteration.getIterationHits();

				logger.info("iterationQueryDef=" + blastIteration.getIterationQueryDef());

				// List of hits
				List<Hit> hits = iterationHits.getHit();

				// container to store unique number of transcriptomes in result
				HashSet<String> uniqueSpecies = new HashSet<String>();

				// Loop through hits
				int numberOfHits = 0;
				double iterationBitScore = 0;
				int nTopResults = 0;
				for(Hit thisHit: hits){
//					logger.info("Num: " + thisHit.getHitNum());
//					logger.info("HitID: " + thisHit.getHitId());
//					logger.info("Def: " + thisHit.getHitDef());
//					logger.info("Len: " + thisHit.getHitLen());

					// get transcriptome species
					String hitDef = thisHit.getHitDef();
					String transcriptName = StringUtils.substringAfterLast(hitDef, "-");

					// add species in set to calculate unique specimes at the end
					uniqueSpecies.add(transcriptName);

					// Loop through hsps
					List<Hsp> hsps = thisHit.getHitHsps().getHsp();			
					String hitFrame = "";
					int thisHitTotalBitScore = 0;
					int nHsp = 0;
					for(Hsp thisHsp: hsps){

						try {
							thisHitTotalBitScore +=  Double.parseDouble(thisHsp.getHspBitScore());
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						hitFrame = thisHsp.getHspHitFrame();
						nHsp ++;
					}

					String seqName = thisHit.getHitDef() + ".fasta";			
					if(uniqueSequences.add(seqName)){
						totalUniqueSequencesBitScore += thisHitTotalBitScore;
					}
					
					// Create a new file for the sequence
					File seqFile = new File(thisPrimerDirectory,seqName);
					
					// Check if sequence is in designedSequenceDirectory
					boolean isInDesignedSequenceDirectory = false;
					if(designedSequenceDirectory != null){
						File checkFile = new File(designedSequenceDirectory,seqName);

						if(checkFile.exists()){
							isInDesignedSequenceDirectory = true;
						}
					}
					
					// Check if sequence is in otherPrimerDirectory
					boolean isInOtherPrimerDirectory = false;
					if(otherPrimerDirectory != null){
						File checkFile = new File(otherPrimerDirectory,seqName);
						if(checkFile.exists()){
							isInOtherPrimerDirectory = true;
						}
					}
					
					// Download sequence from database
					// if dir already exists, delete all contents
					
					
					if(! seqFile.exists()){
						Blaster.downloadSequenceFromLocalBlastDB(blastDatabase,thisHit.getHitId(),seqFile, hitFrame);
					}

					
					// write stats
					
					
					if(isInOtherPrimerDirectory && ! isInDesignedSequenceDirectory){
						System.out.println("Is not in Sequence Dir But other Primer Dir");
						
						BlastHit hit = new BlastHit(thisHit, seqFile);
						isNotInSequenceDirButOtherPrimerDir.add(hit);
						
							
						// Write info
					//	System.out.println("Name:" + seqName);
						// Loop through hsps
						hsps = thisHit.getHitHsps().getHsp();			
						for(Hsp thisHsp: hsps){
							
							StringBuilder textResult = new StringBuilder();
							textResult.append("Hsp: " + thisHsp.getHspNum() + "\n");
							textResult.append("Identity: " + thisHsp.getHspPositive() + "/" + thisHsp.getHspAlignLen() + "\n");
							textResult.append("Query: " + thisHsp.getHspQseq() + "\n");
							textResult.append("Hit  : " + thisHsp.getHspHseq() + "\n");
							textResult.append("Diff : " + thisHsp.getHspMidline() + "\n");
							textResult.append("Hit-frame(strand): " + thisHsp.getHspHitFrame() + "\n");
							
						}
					}
					
					//only top 3
//					if(otherPrimerDirectory != null && isInOtherPrimerDirectory == false &&
//						isInDesignedSequenceDirectory == false && nTopResults < 10 ){
					if(isInDesignedSequenceDirectory == false && nTopResults < 10 ){
					
						BlastHit hit = new BlastHit(thisHit,seqFile);
						isNotInSequenceDirAndIsTopHit.add(hit);
						
						nTopResults ++;
						System.out.println("Is not in Sequence Dir and is Top 10");
						
						// Write info
						System.out.println("Name:" + seqName);
						// Loop through hsps
						hsps = thisHit.getHitHsps().getHsp();			
						for(Hsp thisHsp: hsps){
							System.out.println("Hsp: " + thisHsp.getHspNum());
							System.out.println("Identity: " + thisHsp.getHspPositive() + "/" + thisHsp.getHspAlignLen());
							System.out.println("Query: " + thisHsp.getHspQseq());
							System.out.println("Hit  : " + thisHsp.getHspHseq());
							System.out.println("Diff : " + thisHsp.getHspMidline());
							System.out.println("Hit-frame(strand): " + thisHsp.getHspHitFrame());
						}
					}
					
				}

				bestIterationBitScore = Math.max(iterationBitScore, bestIterationBitScore);
				bestIterationNumberOfHits = Math.max(numberOfHits, bestIterationNumberOfHits);
				bestIterationUniqueSpeciesNumber = Math.max(uniqueSpecies.size(), bestIterationUniqueSpeciesNumber);

				totalBitScore += iterationBitScore;
				totalHits += numberOfHits;
				nTotalUniqueSpecies += uniqueSpecies.size();

				nIterations ++;
			}
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
