package aliview;

public interface SequenceNameFormatter {

	String format(String name);
	
}
