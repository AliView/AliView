package aliview.test;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.log4j.Logger;

public class Test {
	private static final Logger logger = Logger.getLogger(Test.class);
	
	// Preference keys for this package
    private static final String NUM_ROWS = "num_rows";
    private static final String NUM_COLS = "num_cols";


    private void testFileDialog(){
    	
    	Frame f = new Frame();
    	FileDialog fd = new FileDialog(f, "Hej", FileDialog.LOAD);
        fd.setDirectory("/home/anders/_ormbunkar");
        fd.setLocation(100,100);
        fd.setSize(600, 600);
        fd.setFile("");
        fd.setVisible(true);
        File selectedFile = new File(fd.getFile());

    	
    }
    
    private void testprefs(){
        Preferences prefs = Preferences.userNodeForPackage(Test.class);
        
        int numRows = prefs.getInt(NUM_ROWS, 40);
        int numCols = prefs.getInt(NUM_COLS, 80);
        logger.info(numRows);
        logger.info(numCols);
        prefs.putInt(NUM_ROWS, 30);
        prefs.put("Another", "hejHopp");
        prefs.put("Third", "tree");
        try {
			prefs.flush();
		} catch (BackingStoreException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        try {
			Thread.sleep(1000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    
    private static void testBitwise(){
    	
    	int x = 3 | 1 | 4 | 1 | 6;
    	System.out.println("" + x);
    	
    	System.out.println(5 | 2);
    	
  	
    }
    
    public static void runJavascript(){
   	 // create a script engine manager
   	 ScriptEngineManager factory = new ScriptEngineManager();
   	 // create a JavaScript engine
   	 ScriptEngine engine = factory.getEngineByName("JavaScript");
   	 // evaluate JavaScript code from String
   	 try {
		engine.eval("print('Welocme to java world')");
	} catch (ScriptException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   
   }

    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		logger.info(System.getProperty("java.io.tmpdir"));
		
		logger.info(Math.abs(2 % 3) + 1);
		
		int readingFrame = 3;
		int wantedFrame = 2;
		int startPos = 146;
		
		int offset = readingFrame - wantedFrame;
		
		int invertedOffset = 3 - offset;
		offset = invertedOffset % 3; // convert 3 to 0;
		
		startPos = startPos + offset;
		
		logger.info(startPos);
		
		
		//new Test().runJavascript();
		
		//new Test().testBitwise();
		
		//new Test().testFileDialog();
		
		//new Test().testprefs();
		
		// TODO Auto-generated method stub

		// 159 MB file into Stringbuffer = 2.1 sek
		// Only reading = 0.6 sek
		//INFO  2012-05-15 20:37:26,325 Test                  20 - Start
		//INFO  2012-05-15 20:37:26,327 Test                  24 - File length = 159095555
		//INFO  2012-05-15 20:37:28,419 Test                  38 - Finished
		
		
		//logger.info(Math.floor(2.99));
		
		
	   
		
//		
//		long startTime = System.currentTimeMillis();
//		
//		// Kan läsa det allra mesta
//		
//		byte[][] x = new byte[10000][1000];
//		
//		File testFile = new File("/opt/Silva_108/core_aligned/Silva_108_core_aligned_seqs.fasta");
//		//File testFile = new File("/opt/Silva_108/rep_set/Silva_108_rep_set.fna");
//		//File testFile = new File("/opt/Transcriptomefiles/Asplenium_nidus_PSKY/PSKY-assembly.fa");
//		logger.info("File length = " + testFile.length());
//		try {
//		StringBuffer buff = new StringBuffer(100000);
//		BufferedReader r = new BufferedReader(new FileReader(testFile));
//		String line;
//		int nLine = 0;
//			while ((line = r.readLine()) != null) {
//			
//			   char[] nextLine = line.toCharArray();
//			   
//			   /*
//			   if(nLine < 5){
//				   logger.info(nextLine[0]);
//			   }
//			   */
//
//			   nLine ++;
//				
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		long endTime = System.currentTimeMillis();
//		System.out.println("That took " + (endTime - startTime) + " milliseconds");

		
	}
	
	/*
	 * 
	 * Buffered drawing
	 * 
	 * Use a BufferedImage and the setRGB(...) method. Then you draw the entire image in your paint routine.
	 * 
	 */
	
	
	
	// File reading
	/*
	 * 
	 * public class Buffer
{
    public static void main(String args[]) throws Exception
    {
        String inputFile = "charData.xml";
        FileInputStream in = new FileInputStream(inputFile);
        FileChannel ch = in.getChannel();
        ByteBuffer buf = ByteBuffer.allocateDirect(BUFSIZE);  // BUFSIZE = 256

        Charset cs = Charset.forName("ASCII"); // Or whatever encoding you want

        // read the file into a buffer, 256 bytes at a time 
        int rd;
        while ( (rd = ch.read( buf )) != -1 ) {
            buf.rewind();
            System.out.println("String read: ");
            CharBuffer chbuf = cs.decode(buf);
            for ( int i = 0; i < chbuf.length(); i++ ) {
                // print each character 
                System.out.print(chbuf.get());
            }
            buf.clear();
        }
    }
}

	 */

}
