package aliview.sequencelist;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.ListIterator;

import javax.swing.DefaultListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.apache.log4j.Logger;

import aliview.AlignmentPane;
import aliview.sequences.Sequence;

public class SequenceListListener implements ListDataListener, ListSelectionListener{

	private static final Logger logger = Logger.getLogger(SequenceListListener.class);
	private static SequenceList sequenceList;
	private static AlignmentPane alignmentPane;



	public SequenceListListener(SequenceList aliList, AlignmentPane aliPane) {
		SequenceListListener.sequenceList = aliList;
		SequenceListListener.alignmentPane = aliPane;
	}

	@SuppressWarnings("unchecked")
	public void contentsChanged(ListDataEvent e) {
		logger.info("contentsChanged");
		alignmentPane.validateSequenceOrder();
	}

	public void intervalAdded(ListDataEvent e) {
		logger.info("intervalAdded");
		alignmentPane.validateSequenceOrder();
	}

	public void intervalRemoved(ListDataEvent e) {
		logger.info("intervalRemoved");
		alignmentPane.validateSequenceOrder();
		

	}  	

	public void valueChanged(ListSelectionEvent evt) {
		// When the user release the mouse button and completes the selection,
		// getValueIsAdjusting() becomes false
		logger.info("valueChanged");
		if (!evt.getValueIsAdjusting()) {

			Object[] selected = sequenceList.getSelectedValues();
		
			// Iterate all selected items and static them in a list
			ArrayList<Sequence> selectedSequences = new ArrayList<Sequence>();
			for (int i=0; i<selected.length; i++) {
				selectedSequences.add((Sequence) selected[i]);
			}
			int[] selectedIndex = sequenceList.getSelectedIndices();
			if(selectedIndex != null && selectedIndex.length > 0){
				alignmentPane.setDifferenceTraceSequence(selectedIndex[0]);
			}
			
			alignmentPane.selectSequences(selectedSequences);
			alignmentPane.validateSequenceOrder();
		}
		
	}

}
