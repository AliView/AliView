package aliview.settings;

import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import aliview.test.Test;

public class Settings {
	
	private static final String SAVE_ALIGNMENT_DIRECTORY = "SAVE_ALIGNMENT_DIRECTORY";
	private static final String LOAD_ALIGNMENT_DIRECTORY = "LOAD_ALIGNMENT_DIRECTORY";
	private static final String SAVE_SELECTION_DIRECTORY = "SAVE_SELECTION_DIRECTORY";
	private static final String TOGGLE_SHORT_NAME_ONLY = "TOGGLE_SHORT_NAME_ONLY";
	
	private static SettingValue saveAlignmentDir = new SettingValue("SAVE_ALIGNMENT_DIRECTORY", System.getProperty("user.home"));
	private static SettingValue minPrimerLength = new SettingValue("MIN_PRIMER_LEN", 20, 15, 30);
	private static SettingValue maxPrimerLength = new SettingValue("MAX_PRIMER_LEN", 24, 15, 30);
	private static SettingValue dimerReportThreashold = new SettingValue("DIMER_REPORT_THREASHOLD", 5, 1, 30);
	private static SettingValue toggleShortNameOnly = new SettingValue("TOGGLE_SHORT_NAME_ONLY", false);
	
	private static Preferences prefs = Preferences.userNodeForPackage(Settings.class);
	
	
	//TODO Not Used
	/*
	public static SettingValue getSaveAlignmentDir() {
		return saveAlignmentDir;
	}

	public static void setSaveAlignmentDir(SettingValue saveAlignmentDir) {
		Settings.saveAlignmentDir = saveAlignmentDir;
	}
	*/

	public static SettingValue getMinPrimerLength(){
		return minPrimerLength;
	}
	
	public static SettingValue getMaxPrimerLength(){	
		return maxPrimerLength;
	}
	
	public static SettingValue getDimerReportThreashold() {
		return dimerReportThreashold;
	}
	
	public static int getIntValue(SettingValue settingValue) {
		int value = prefs.getInt(settingValue.getPrefsKey(), settingValue.getDefaultIntValue());
		return value;
	}

	public static void putIntValue(SettingValue settingValue, int intValue) {
		prefs.putInt(settingValue.getPrefsKey(), intValue);
		try {
			prefs.flush();
		} catch (BackingStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	/*
	public static void putIntValue(String prefsKey, int value) {
		prefs.putInt(maxPrimerLength.getPrefsKey(), length);
		try {
			prefs.flush();
		} catch (BackingStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
	
	public static final String getSaveAlignmentDirectory(){	
		return prefs.get(SAVE_ALIGNMENT_DIRECTORY, System.getProperty("user.home"));
	}
	
	public static final void putSaveAlignmentDirectory(String dirName){	
		prefs.put(SAVE_ALIGNMENT_DIRECTORY, dirName);
		try {
			prefs.flush();
		} catch (BackingStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static final String getLoadAlignmentDirectory(){	
		return prefs.get(LOAD_ALIGNMENT_DIRECTORY, System.getProperty("user.home"));
	}
	
	
	public static final void putLoadAlignmentDirectory(String dirName){	
		prefs.put(LOAD_ALIGNMENT_DIRECTORY, dirName);
		try {
			prefs.flush();
		} catch (BackingStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static final boolean getToggleShortNameOnly() {
		return prefs.getBoolean(TOGGLE_SHORT_NAME_ONLY, false);
	}

	public static void putToggleShortNameOnly(boolean shortNameOnly) {
		prefs.putBoolean(TOGGLE_SHORT_NAME_ONLY, shortNameOnly);
		try {
			prefs.flush();
		} catch (BackingStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static final String getSaveSelectionDirectory() {
		return prefs.get(SAVE_SELECTION_DIRECTORY, System.getProperty("user.home"));
	}

	public static void putSaveSelectionDirectory(String dirName) {
		prefs.put(SAVE_SELECTION_DIRECTORY, dirName);
		try {
			prefs.flush();
		} catch (BackingStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
