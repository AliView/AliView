package aliview;

import java.util.Stack;

public class LimitedStack<T> {
	Stack<T> stack;
	int maxSize;
	
	public LimitedStack(int maxSize){
		stack = new Stack<T>();
		this.maxSize = maxSize;
	}
	
	public T push(T obj){
		
		T retVal = stack.push(obj);
		if(stack.size() > maxSize){
			stack.removeElementAt(0);
		}
		
		return retVal;
	}
	
	public T pop(){
		return stack.pop();
	}
	
	public boolean isEmpty(){
		return stack.isEmpty();
	}
	
	public int size(){
		return stack.size();
	}

}
