package aliview;

import java.awt.Point;
import java.io.File;
import java.util.regex.Pattern;

import aliview.sequences.Sequence;

public class AminoAcidAlignment extends Alignment {

	public AminoAcidAlignment(File alignmentFile, FileFormat fileFormat, MemoryArrayMatrix matrix, Excludes excludes,
			CodonPositions codonPositions) {
		super(alignmentFile, fileFormat, matrix,excludes,codonPositions);
	}

	public AminoAcidAlignment(MemoryArrayMatrix matrix) {
		super(matrix);
	}

	
	public Point findInSequences(String searchTerm) {
		String regex = "";
		for(int n = 0; n < searchTerm.length(); n++){
			regex += searchTerm.charAt(n);
			// add one or many gap between each character to be found
			regex +="\\-*"; 
		}
		
		Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE);
	
		for(int n = nextFindSequenceNumber; n < sequences.size(); n++){
			Sequence seq = sequences.get(n);
			Base[] foundBases = seq.findAndSelect(pattern,nextFindStartPos);
			if(foundBases != null){
				nextFindSequenceNumber = n;
				int position = foundBases[0].getPosition();		
				// make sure it is not out of index
				nextFindStartPos = Math.min(position + 1, getMaximumSequenceLength() - 1);
				return new Point(position,n);
			}
			// not found in this seq - start again from 0
			nextFindStartPos = 0;

		}
		nextFindSequenceNumber = 0;
		nextFindStartPos = 0;
		return null;
	}
}
