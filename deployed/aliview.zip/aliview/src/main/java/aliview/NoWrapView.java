package aliview;

import javax.swing.text.Element;
import javax.swing.text.ParagraphView;

public class NoWrapView extends ParagraphView{
	
	public NoWrapView(Element arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public void layout(int width, int height) {
        super.layout(Short.MAX_VALUE, height);
    }

}
