package aliview;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import org.apache.log4j.Logger;

import aliview.utils.DialogUtils;

public class SubProcessWindow extends JFrame{
	
	private static final Logger logger = Logger.getLogger(MuscleWrapper.class);
	private Process subProcess;
	private JTextArea consoleTextArea;
	JScrollPane scrollPane;
	private boolean subProcessDestrouedByUser = false;
	
	public SubProcessWindow() {	
		
		consoleTextArea = new JTextArea();
		scrollPane = new JScrollPane(consoleTextArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {		
			public void windowClosing(WindowEvent e) {
				if(subProcess != null){
					subProcess.destroy();
					subProcessDestrouedByUser = true;
				}
			}
		});
			
		this.getContentPane().add(scrollPane, BorderLayout.CENTER);
		this.setTitle("Sub Process Window");
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(SubProcessWindow.class.getResource("/img/alignment_ico_128x128.png")));
		this.setPreferredSize(new Dimension(500,350));
		this.pack();
		
	}
	
	
	public SubProcessWindow(Process subprocess) {
		super();
		this.subProcess = subprocess;
	}
	
	

	public boolean wasSubProcessDestrouedByUser() {
		return subProcessDestrouedByUser;
	}


	public void setActiveProcess(Process subProcess){
		this.subProcess = subProcess;	
	}	
	
	public void centerLocationToThisComponent(Component parent){
		// align to middle of parent window
		if(parent != null){
			int newX = parent.getX() + parent.getWidth()/2 - this.getWidth()/2;
			int newY = parent.getY() + parent.getHeight()/2 - this.getHeight()/2;
			this.setLocation(newX, newY);
		}
	}
	
	
	public void appendOutput(String output){
		logger.info("setting new" + output);
		consoleTextArea.append(output);
		// Make it scroll to end
		consoleTextArea.setCaretPosition(consoleTextArea.getDocument().getLength());
	}
}
