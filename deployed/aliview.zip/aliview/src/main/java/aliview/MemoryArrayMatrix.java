package aliview;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import aliview.sequences.Sequence;
import aliview.sequences.WrappedJEBLSequence;

import sun.util.logging.resources.logging;

import jebl.evolution.io.FastaImporter;
import jebl.evolution.io.NexusImporter;
import jebl.evolution.sequences.SequenceType;

public class MemoryArrayMatrix extends Matrix{
	private static final Logger logger = Logger.getLogger(MemoryArrayMatrix.class);
	private ArrayList<Sequence> sequences = new ArrayList<Sequence>();
	private int longestSequenceLength = 0;
	private FileFormat fileFormat; 

	public MemoryArrayMatrix() {
		// TODO Auto-generated constructor stub
	}
	
	public MemoryArrayMatrix(File alignmentFile){
		// import sequences into memory
		try {
			// First try fast fasta
			FastFastaImporter fastaImporter = new FastFastaImporter(new FileReader(alignmentFile));
			sequences = fastaImporter.importSequences();
			this.longestSequenceLength = fastaImporter.getLongestSequenceLength();
			logger.info("longestSequenceLength" + longestSequenceLength);
			this.fileFormat = FileFormat.FASTA;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
		// Then try jebl
		if(sequences == null || sequences.size() == 0){
			// Import sequences with jebl-library
			List<jebl.evolution.sequences.Sequence> jeblSequences = null;
	
			try{
				NexusImporter importer = new NexusImporter(new FileReader(alignmentFile));
				jeblSequences = importer.importSequences();
				this.fileFormat = FileFormat.NEXUS;
				
			}catch (Exception nexExc) {
				nexExc.printStackTrace();
				String errorMessage = "Could not open file as FASTA or NEXUS" + "\n" + nexExc.getMessage();
				//AliView.putErrorMessage(errorMessage);
			}
			// Try JEBL Fasta
			if(jeblSequences == null || jeblSequences.size() == 0){
				// nexus didn't work - try fasta
				try{
					FastaImporter importer = new FastaImporter(new FileReader(alignmentFile),SequenceType.NUCLEOTIDE);
					jeblSequences = importer.importSequences();
					this.fileFormat = FileFormat.FASTA;
				}catch (Exception e) {
					// try as aminoacid
					try{
						FastaImporter importer = new FastaImporter(new FileReader(alignmentFile),SequenceType.AMINO_ACID);
						jeblSequences = importer.importSequences();
						this.fileFormat = FileFormat.FASTA;
					}catch (Exception exc) {
		
					}
				}		
			}
	
			if(jeblSequences != null && jeblSequences.size() > 0){
	
				sequences = new ArrayList<Sequence>();
				for(jebl.evolution.sequences.Sequence jeblSequence: jeblSequences){
	
					// Craete sequences by wrapping jebl-sequences in AliView-sequences
					Sequence seq = new WrappedJEBLSequence(jeblSequence);
					sequences.add(seq);
					this.longestSequenceLength = Math.max(this.longestSequenceLength, seq.getLength());	
				}	
			}
		}
		
		// Then try phylip
		if(sequences == null || sequences.size() == 0){
			// import sequences into memory
			try {
				// First try fast fasta
				PhylipImporter phylipImporter = new PhylipImporter(new FileReader(alignmentFile));
				sequences = phylipImporter.importSequences();
				this.longestSequenceLength = phylipImporter.getLongestSequenceLength();
				logger.info("longestSequenceLength" + longestSequenceLength);
				this.fileFormat = FileFormat.PHYLIP;
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public MemoryArrayMatrix(StringReader stringReader) {
		// import sequences into memory
			// First try fast fasta
			FastFastaImporter fastaImporter = new FastFastaImporter(stringReader);
			sequences = fastaImporter.importSequences();
			
	}

	public ArrayList<Sequence> getSequences() {
		return sequences;
	}

	public int getLongestSequenceLength() {
		return longestSequenceLength;
	}

	public FileFormat getFileFormat() {
		return this.fileFormat;
	}
}
