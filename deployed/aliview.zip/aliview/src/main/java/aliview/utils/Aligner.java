package aliview.utils;

import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.text.JTextComponent;

import org.apache.log4j.Logger;

import aliview.MuscleWrapper;
import aliview.SubProcessWindow;


public class Aligner {
	private static final Logger logger = Logger.getLogger(Aligner.class);
	
	
	public static void muscleProfileAlign(File in1, File in2, File out){
		muscleProfileAlign(in1, in2, out, null);
	}
	
	public static boolean muscleProfileAlign(File in1, File in2, File out, Component parentComponent){
		
		boolean wasProcessInterrupted = false;
		
		try {

			String[] commandArray = new String[]{
					MuscleWrapper.getMusclePath().toString(),
					"-profile",
					"-in1",in1.toString(),
					"-in2",in2.toString(),
					"-out",out.toString()
			};


			for(String token: commandArray){
				logger.info(token);
			}

			String totalCommand = "";
			for(String token: commandArray){
				totalCommand += token + " ";
			}
				logger.info(totalCommand);



				Process subprocess = Runtime.getRuntime().exec(commandArray);
				
				// Display messages in new frame and allow user to destroy subprocess by closing window
				final SubProcessWindow subProcessWin = new SubProcessWindow();
				subProcessWin.setTitle("Align with muscle");
				subProcessWin.setAlwaysOnTop(true);
				subProcessWin.setActiveProcess(subprocess);
				subProcessWin.centerLocationToThisComponent(parentComponent);
				SwingUtilities.invokeLater(new Runnable() {
				    public void run() {
				      // Here, we can safely update the GUI
				      // because we'll be called from the
				      // event dispatch thread
				    	subProcessWin.setVisible(true);
				    }
				  });
				
				Scanner sc = new Scanner(subprocess.getInputStream());
				Scanner errorSc = new Scanner(subprocess.getErrorStream());

				// First read errors (but everything is written in error stream so use ordinary info-logger)
//				// with the redirect above we dont need to check error - everything is sent to standard
					
				while (errorSc.hasNext()){
					//logger.info(errorSc.nextLine());
					String nextLine = errorSc.nextLine();
					subProcessWin.appendOutput(nextLine + "\n");
					System.out.println(nextLine);
				}

				while (sc.hasNext()){
					//logger.info(sc.nextLine());
					String nextLine = errorSc.nextLine();
					subProcessWin.appendOutput(nextLine + "\n");
					System.out.println(nextLine);
				}
				
				
				// clean up external process
				try {
					subprocess.waitFor();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				// TODO maybe check if user closed window before process was finished	
				wasProcessInterrupted = subProcessWin.wasSubProcessDestrouedByUser();
				
				subProcessWin.dispose();
				subprocess.destroy();


			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return wasProcessInterrupted;
	}
	
	

	public static boolean muscleAlign(File in, File out, Component parentComponent){
		
		boolean wasProcessInterrupted = false;
		
		try {
			// 
			String[] commandArray = new String[]{
					MuscleWrapper.getMusclePath().toString(), // "muscle"
					"-in",in.toString(),
					"-out",out.toString()
			};


			for(String token: commandArray){
				logger.info(token);
			}

			String totalCommand = "";
			for(String token: commandArray){
				totalCommand += token + " ";
			}
				logger.info(totalCommand);

//			String command = "muscle -in " + in.getAbsolutePath() + " -out " + out.getAbsolutePath();		
//			ProcessBuilder builder = new ProcessBuilder(command);
//			builder.redirectErrorStream(true);
//			Process p = builder.start();
				
			
			
			Process subprocess = Runtime.getRuntime().exec(commandArray);
			
			// Display messages in new frame and allow user to destroy subprocess by closing window
			final SubProcessWindow subProcessWin = new SubProcessWindow();
			subProcessWin.setTitle("Align with muscle");
			subProcessWin.setAlwaysOnTop(true);
			subProcessWin.setActiveProcess(subprocess);
			subProcessWin.centerLocationToThisComponent(parentComponent);
			SwingUtilities.invokeLater(new Runnable() {
			    public void run() {
			      // Here, we can safely update the GUI
			      // because we'll be called from the
			      // event dispatch thread
			    	subProcessWin.setVisible(true);
			    }
			  });
			
			Scanner sc = new Scanner(subprocess.getInputStream());
			Scanner errorSc = new Scanner(subprocess.getErrorStream());

			// First read errors (but everything is written in error stream so use ordinary info-logger)
//			// with the redirect above we dont need to check error - everything is sent to standard
				
			while (errorSc.hasNext()){
				//logger.info(errorSc.nextLine());
				String nextLine = errorSc.nextLine();
				subProcessWin.appendOutput(nextLine + "\n");
				System.out.println(nextLine);
			}

			while (sc.hasNext()){
				//logger.info(sc.nextLine());
				String nextLine = errorSc.nextLine();
				subProcessWin.appendOutput(nextLine + "\n");
				System.out.println(nextLine);
			}
			
			
			// clean up external process
			try {
				subprocess.waitFor();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			// TODO maybe check if user closed window before process was finished	
			wasProcessInterrupted = subProcessWin.wasSubProcessDestrouedByUser();
			
			subProcessWin.dispose();
			subprocess.destroy();


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return wasProcessInterrupted;
		
	}
	
	/*

	public static void mafftAlign(File in, File out){
		try {

			// 
			String[] commandArray = new String[]{
					"mafft",
					"--maxiterate", "1000",
					"--localpair", in.toString(),
					">",out.toString()
			};


			for(String token: commandArray){
				logger.info(token);
			}

			String totalCommand = "";
			for(String token: commandArray){
				totalCommand += token + " ";
			}
				logger.info(totalCommand);

//			String command = "muscle -in " + in.getAbsolutePath() + " -out " + out.getAbsolutePath();		
//			ProcessBuilder builder = new ProcessBuilder(command);
//			builder.redirectErrorStream(true);
//			Process p = builder.start();
			
			Process p = Runtime.getRuntime().exec(totalCommand);
			


			Scanner sc = new Scanner(p.getInputStream());
			Scanner errorSc = new Scanner(p.getErrorStream());

			// First read errors (but everything is written in error stream so use ordinary info-logger)
//			// with the redirect above we dont need to check error - everything is sent to standard
			while (errorSc.hasNext()){
				//logger.info(errorSc.nextLine());
				System.out.println(errorSc.nextLine());
			}

			while (sc.hasNext()){
				//logger.info(sc.nextLine());
				System.out.println(sc.nextLine());
			}

			// clean up external process
			try {
				p.waitFor();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			p.destroy();


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	*/
	
	class AlignResult{
		private boolean wasDestroyedByUser;
		
		protected AlignResult() {
		}
		
		protected AlignResult(boolean wasDestroyedByUser) {
			this.wasDestroyedByUser = wasDestroyedByUser;
		}

		public boolean wasDestroyedByUser() {
			return wasDestroyedByUser;
		}

		public boolean isWasDestroyedByUser() {
			return wasDestroyedByUser;
		}

		public void setWasDestroyedByUser(boolean wasDestroyedByUser) {
			this.wasDestroyedByUser = wasDestroyedByUser;
		}
		
		
		
		
		
	}

}
