package aliview.utils;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.KeyStroke;

public class OSNativeUtils {
	
	public static boolean isWindows() {
		 
		String os = System.getProperty("os.name").toLowerCase();
		// windows
		return (os.indexOf("win") >= 0);
 
	}
 
	public static boolean isMac() {
 
		String os = System.getProperty("os.name").toLowerCase();
		// Mac
		return (os.indexOf("mac") >= 0);
 
	}
 
	public static boolean isLinuxOrUnix() {
 
		String os = System.getProperty("os.name").toLowerCase();
		// linux or unix
		return (os.indexOf("nix") >= 0 || os.indexOf("nux") >= 0);
 
	}
 
	public static boolean isSolaris() {
 
		String os = System.getProperty("os.name").toLowerCase();
		// Solaris
		return (os.indexOf("sunos") >= 0);
 
	}
	
	public static boolean is32BitOS() { 
		String os = System.getProperty("os.arch").toLowerCase();
		return (os.indexOf("32") >= 0);
	}
	
	public static boolean is64BitOS() { 
		String os = System.getProperty("os.arch").toLowerCase();
		return (os.indexOf("64") >= 0);
	}
	
	public static boolean isPowerPC() { 
		String os = System.getProperty("os.arch").toLowerCase();
		return (os.indexOf("powerpc") >= 0);
	}
	

	public static KeyStroke getReloadKeyAccelerator() {
		return KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_DOWN_MASK);
	}

	public static KeyStroke getCopySelectionAsFastaKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke getCopyKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.META_DOWN_MASK | InputEvent.ALT_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK);
		}
	}

	public static int getMouseWheelZoomModifierMask() {
		if(isMac()){
			return InputEvent.META_DOWN_MASK;
		}else{
			return InputEvent.CTRL_DOWN_MASK;
		}
	}

	public static KeyStroke getDecreaseFontSizeKeyAccelerator() {
		return KeyStroke.getKeyStroke('-');
	}
	
	public static KeyStroke getIncreaseFontSizeKeyAccelerator() {
		return KeyStroke.getKeyStroke('+');
	}

	public static KeyStroke getPasteKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_DOWN_MASK);
		}
	}
	
	public static KeyStroke getClearKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0);
		}
	}
	
	public static KeyStroke getDeleteKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke getUndoKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK);
		}
	}
	
	public static KeyStroke getRedoKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke getMoveSelectionUpKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_UP, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_UP, InputEvent.CTRL_DOWN_MASK);
		}
	}
	
	public static KeyStroke getMoveSelectionDownKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke getMoveSelectedRightKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke getMoveSelectedLeftKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, InputEvent.CTRL_DOWN_MASK);
		}
	}


	public static KeyStroke getInsertGapMoveRightKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, InputEvent.META_DOWN_MASK | InputEvent.ALT_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK);
		}
	}
	
	public static KeyStroke getInsertGapMoveLeftKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, InputEvent.META_DOWN_MASK | InputEvent.ALT_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, InputEvent.CTRL_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK);
		}
	}

	public static KeyStroke getToggleTranslationKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke incReadingFrameKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_PLUS, InputEvent.SHIFT_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_PLUS, InputEvent.SHIFT_DOWN_MASK);
		}
	}
	
	public static KeyStroke decReadingFrameKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, InputEvent.SHIFT_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, InputEvent.SHIFT_DOWN_MASK);
		}
	}

	public static KeyStroke getAddExcludesKeyAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke getSaveFileAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK);
		}
	}

	public static KeyStroke getOpenFileAccelerator() {
		if(isMac()){
			return KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.META_DOWN_MASK);
		}else{
			return KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK);
		}
	}

	
	

}
