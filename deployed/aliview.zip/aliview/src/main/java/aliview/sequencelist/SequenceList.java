package aliview.sequencelist;

import java.awt.Font;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.DropMode;
import javax.swing.InputMap;
import javax.swing.KeyStroke;
import javax.swing.TransferHandler;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionListener;

import org.apache.log4j.Logger;

import aliview.sequences.Sequence;
import aliview.utils.OSNativeUtils;


public class SequenceList extends javax.swing.JList{
	private static final Logger logger = Logger.getLogger(SequenceList.class);
	// todo These two constants should be synchronized in one class (AlignmentPane & this)
	private static final int MIN_CHAR_SIZE = 2;
	private static final int MAX_CHAR_SIZE = 100;
	private Font baseFont = new Font("Monospace", Font.PLAIN, 11);
	private double charHeight = 12;
	int listFontSize = 10;
	
	
	public SequenceList(SequenceListModel model) {
		super(model);
		this.setFont(baseFont);
		this.updateCharSize();
		this.setDragEnabled(true);
		//this.setTransferHandler(new TableRowTransferHandler());
        //this.setDropMode(DropMode.INSERT_ROWS);

		// Remove default ctrl-C action (because it only copys names in list and not sequence)
		InputMap map = this.getInputMap();
		// remove from input map is not working so I am replacing one with nothing
		map.put(OSNativeUtils.getPasteKeyAccelerator(),"null");
		map.put(OSNativeUtils.getCopyKeyAccelerator(),"null");
		map.put(OSNativeUtils.getMoveSelectionUpKeyAccelerator(),"null");
		map.put(OSNativeUtils.getMoveSelectionDownKeyAccelerator(),"null");
		
		// remove default listselectionlistener
		// todo maybe a bit hacky to reuse AlignmentList and alignment pane??
		/*
		ListSelectionListener[] listeners = this.getListSelectionListeners();
		for(ListSelectionListener listener: listeners){
			this.removeListSelectionListener(listener);
		}
		*/
	}

	public void setCharSize(double charHeight) {
		// TODO Auto-generated method stub
		this.charHeight = charHeight;
		this.setFixedCellHeight((int)charHeight);
		listFontSize = (int)(charHeight -1);
		updateCharSize();
	}
/*
	public void decCharSize(){
		charHeight = charHeight - 1;
		
			
		if(charHeight < MIN_CHAR_SIZE){
			charHeight = MIN_CHAR_SIZE;
		}
		this.setFixedCellHeight(charHeight);
		listFontSize = charHeight -1;
		updateCharSize();
	}
	public void incCharSize(){
		charHeight = charHeight + 1;
			
		if(charHeight > MAX_CHAR_SIZE){
			charHeight = MAX_CHAR_SIZE;
		}
		listFontSize = charHeight -1;
		this.setFixedCellHeight(charHeight);
		
		updateCharSize();

	}		
	*/	

	private void updateCharSize() {
		
		this.setFixedCellHeight((int)charHeight);
		//this.setBorder(new EmptyBorder((int)(charHeight * 2), 1, 1, 1)); // todo read top inset from alignmentPane
		
		// this could be calculated
		this.setFont(new Font(baseFont.getName(), baseFont.getStyle(), listFontSize));
		
		// todo dont know if this is needed
		this.repaint();
		
	}

	
	public void deleteSequence(Object seq) {
			SequenceListModel model =  (SequenceListModel) this.getModel();
			model.removeElement(seq);
	}


	public void deleteSelectedSequences() {
		Object[] selection = this.getSelectedValues();
		for(Object obj: selection){
			SequenceListModel model =  (SequenceListModel) this.getModel();
			model.removeElement(obj);
		}
		
	}
	
	public void reverseComplementSelectedSequences() {
		Object[] selection = this.getSelectedValues();
		for(Object obj: selection){
			Sequence seq = (Sequence) obj;
			seq.reverseComplement();
		}
		
	}
	
	public void moveSelectionUp() {
		int[] selected = this.getSelectedIndices();

		ArrayList<Integer> toSelect = new ArrayList<Integer>();
		
		for(int n = 0; n < selected.length; n++){
			int index = selected[n];
			
			if(index > 0){
				
				SequenceListModel model =  (SequenceListModel) this.getModel();
				Object obj = model.getElementAt(index);
				model.removeElement(obj);
				model.add(index - 1, obj);
				toSelect.add(new Integer(index - 1));

			}
			// break when upper one hits top
			else{
				break;
			}
		}
		
		int[] toSel = new int[toSelect.size()];
		for(int n = 0; n < toSel.length; n++){
			toSel[n] = toSelect.get(n).intValue();
		}
		
		if(toSel.length > 0){
			this.setSelectedIndices(toSel);
		}
		
	}
	
	public void moveSelectionDown() {
		int[] selected = this.getSelectedIndices();

		ArrayList<Integer> toSelect = new ArrayList<Integer>();
		
		for(int n = selected.length - 1; n >=0; n--){
			int index = selected[n];
			
			if(index < this.getModel().getSize() - 1){
				
				SequenceListModel model =  (SequenceListModel) this.getModel();
				Object obj = model.getElementAt(index);
				model.removeElement(obj);
				model.add(index + 1, obj);
				toSelect.add(new Integer(index + 1));

			}
			// break when lower one hits bottom
			else{
				break;
			}
		}
		
		int[] toSel = new int[toSelect.size()];
		for(int n = 0; n < toSel.length; n++){
			toSel[n] = toSelect.get(n).intValue();
		}
		if(toSel.length > 0){
			this.setSelectedIndices(toSel);
		}
		
	}


	public void moveSelectionToTop() {
		Object[] selection = this.getSelectedValues();
		int insertPos = 0;
		for(Object obj: selection){
			SequenceListModel model =  (SequenceListModel) this.getModel();
			model.removeElement(obj);
			model.add(insertPos, obj);
			insertPos ++;
		}	
	}


	public void moveSelectionToBottom() {
		Object[] selection = this.getSelectedValues();
		for(Object obj: selection){
			SequenceListModel model =  (SequenceListModel) this.getModel();
			model.removeElement(obj);
			model.add(model.getSize() - 1, obj);
		}
		
	}

}
