package aliview.settings;

public class SettingValue {

	private String prefsKey;
	private String defaultStringValue;
	private int defaultIntValue;
	private int minIntVal;
	private int maxIntVal;
	private String stringValue;
	private boolean defaultBooleanValue;

	public SettingValue(String prefsKey, String defaultStringValue) {
		this.prefsKey = prefsKey;
		this.defaultStringValue = defaultStringValue;
	}

	public SettingValue(String prefsKey, int defaultIntValue, int minIntVal, int maxIntVal) {
		this.prefsKey = prefsKey;
		this.defaultIntValue = defaultIntValue;
		this.minIntVal = minIntVal;
		this.maxIntVal = maxIntVal;
	}
	
	public SettingValue(String prefsKey, boolean defaultBooleanValue) {
		this.prefsKey = prefsKey;
		this.defaultBooleanValue = defaultBooleanValue;
	}

	public String getPrefsKey() {
		return prefsKey;
	}

	public void setPrefsKey(String prefsKey) {
		this.prefsKey = prefsKey;
	}

	public String getDefaultStringValue() {
		return defaultStringValue;
	}

	public void setDefaultStringValue(String defaultStringValue) {
		this.defaultStringValue = defaultStringValue;
	}

	public int getDefaultIntValue() {
		return defaultIntValue;
	}

	public void setDefaultIntValue(int defaultIntValue) {
		this.defaultIntValue = defaultIntValue;
	}

	public int getMinIntVal() {
		return minIntVal;
	}

	public void setMinIntVal(int minIntVal) {
		this.minIntVal = minIntVal;
	}

	public int getMaxIntVal() {
		return maxIntVal;
	}

	public void setMaxIntVal(int maxIntVal) {
		this.maxIntVal = maxIntVal;
	}

	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}

	public String getStringValue() {
		return stringValue;
	}	

	public void putIntValue(int intValue) {
		Settings.putIntValue(this, intValue);
	}

	public int getIntValue() {
		return Settings.getIntValue(this);
	}	
}
