package aliview;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import aliview.utils.OSNativeUtils;

	public class MuscleWrapper {
		
	public static void main(String[] args) {
		getMusclePath();
	}
	
	private static final Logger logger = Logger.getLogger(MuscleWrapper.class);
	
	public static File getMusclePath(){
		
		// get predefined path
		
		
		// if no predefined path create one for distributed program
		File localMuscleBinFile = new File(getAliViewUserDataDirectory(), "binaries" + File.separator + getMuscleBinDependingOnOS());
		
		// check if file exist if not extract it from jar
		if(! localMuscleBinFile.exists() || localMuscleBinFile.length() == 0){
				ClassLoader cl = MuscleWrapper.class.getClassLoader();
				logger.info(cl);
				InputStream muscleStreamFromJar = cl.getResourceAsStream(localMuscleBinFile.getName());	
				logger.info(muscleStreamFromJar);
				try {
					FileUtils.forceMkdir(localMuscleBinFile.getParentFile());
					FileUtils.copyInputStreamToFile(muscleStreamFromJar, localMuscleBinFile);
					localMuscleBinFile.setExecutable(true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		
		logger.info(localMuscleBinFile);		
		return localMuscleBinFile;
		
	}
	
	
	public static final String getAliViewUserDataDirectory() {
	    return System.getProperty("user.home") + File.separator + ".AliView" + File.separator;
	}
	
	
	
	public static final String getMuscleBinDependingOnOS() {
		
		String binName = "";
		// 64-bit
		if(OSNativeUtils.is64BitOS()){
			if(OSNativeUtils.isMac()){
				binName = "muscle3.8.31_i86darwin64";
			}
			else if(OSNativeUtils.isLinuxOrUnix()){
				binName = "muscle3.8.425_i86linux64";
			}
			// default
			else{
				binName = "muscle3.8.425_win32.exe";
			}
		// 32-bit
		}else{
			if(OSNativeUtils.isMac()){
				if(OSNativeUtils.isPowerPC()){
					binName = "muscle3.8.31_macppc";
				}
				else{
					binName = "muscle3.8.31_i86darwin32";
				}
			}
			else if(OSNativeUtils.isLinuxOrUnix()){
				binName = "muscle3.8.425_i86linux32";
			}
			// default
			else{
				binName = "muscle3.8.425_win32.exe";
			}
		}
		
		return binName;

	}


}


