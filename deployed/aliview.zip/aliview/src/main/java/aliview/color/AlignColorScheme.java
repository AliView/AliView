package aliview.color;

import java.awt.Color;

import aliview.AminoAcid;
import aliview.NucleotideUtilities;

public class AlignColorScheme implements ColorScheme {

	Color[] baseBackgroundColor;
	Color[] baseForegroundColor;
	Color[] baseSelectionBackgroundColor;
	Color[] baseSelectionForegroundColor;
	Color[] aminoAcidBackgroundColor;
	Color[] aminoAcidForegroundColor;
	Color[] aminoAcidSelectionBackgroundColor;
	Color[] aminoAcidSelectionForegroundColor;
	
	Color CLUSTAL_RED =  new Color((float) 0.9, (float) 0.2, (float) 0.1);
	Color CLUSTAL_BLUE = new Color((float) 0.5, (float) 0.7, (float) 0.9);
	Color CLUSTAL_GREEN = new Color((float) 0.1, (float) 0.8, (float) 0.1);
	Color CLUSTAL_ORANGE = new Color((float) 0.9, (float) 0.6, (float) 0.3);
	Color CLUSTAL_CYAN =  new Color((float) 0.1, (float) 0.7, (float) 0.7);
	Color CLUSTAL_PINK = new Color((float) 0.9, (float) 0.5, (float) 0.5);
	Color CLUSTAL_MANGENTA = new Color((float) 0.8, (float) 0.3, (float) 0.8);
	Color CLUSTAL_YELLOW = new Color((float) 0.8, (float) 0.8, (float) 0.0);
	
	public AlignColorScheme() {
		super();
		
		baseForegroundColor = new Color[64];
		baseForegroundColor[NucleotideUtilities.A] = new Color(0,128,0); //Color.green
		baseForegroundColor[NucleotideUtilities.C] = new Color(0,0,255); //Color.blue
		baseForegroundColor[NucleotideUtilities.G] = Color.black; 
		baseForegroundColor[NucleotideUtilities.TU] = new Color(255,0,0); // Color.red
		baseForegroundColor[NucleotideUtilities.R] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.Y] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.M] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.K] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.W] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.S] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.B] = Color.magenta; 
		baseForegroundColor[NucleotideUtilities.D] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.H] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.V] = Color.magenta;
		baseForegroundColor[NucleotideUtilities.N] = Color.magenta; 
		baseForegroundColor[NucleotideUtilities.GAP] = Color.lightGray;
		baseForegroundColor[NucleotideUtilities.UNKNOWN] = Color.lightGray;
		
		baseBackgroundColor = new Color[64];
		baseBackgroundColor[NucleotideUtilities.A] = new Color(130,210,130); 
		baseBackgroundColor[NucleotideUtilities.C] = new Color(160,160,255);
		baseBackgroundColor[NucleotideUtilities.G] = new Color(140,140,140); 
		baseBackgroundColor[NucleotideUtilities.TU] = new Color(255,160,160); 
		baseBackgroundColor[NucleotideUtilities.R] = Color.white;
		baseBackgroundColor[NucleotideUtilities.Y] = Color.white;
		baseBackgroundColor[NucleotideUtilities.M] = Color.white;
		baseBackgroundColor[NucleotideUtilities.K] = Color.white;
		baseBackgroundColor[NucleotideUtilities.W] = Color.white;
		baseBackgroundColor[NucleotideUtilities.S] = Color.white;
		baseBackgroundColor[NucleotideUtilities.B] = Color.white; 
		baseBackgroundColor[NucleotideUtilities.D] = Color.white;
		baseBackgroundColor[NucleotideUtilities.H] = Color.white;
		baseBackgroundColor[NucleotideUtilities.V] = Color.white;
		baseBackgroundColor[NucleotideUtilities.N] = Color.white; 
		baseBackgroundColor[NucleotideUtilities.GAP] = Color.white;
		baseBackgroundColor[NucleotideUtilities.UNKNOWN] = Color.white;
			
	
		baseSelectionForegroundColor = new Color[64];
		baseSelectionForegroundColor[NucleotideUtilities.A] = new Color(60,128,60); 
		baseSelectionForegroundColor[NucleotideUtilities.C] = new Color(60,60,255); 
		baseSelectionForegroundColor[NucleotideUtilities.G] = Color.black; 
		baseSelectionForegroundColor[NucleotideUtilities.TU] = new Color(255,60,60); 
		baseSelectionForegroundColor[NucleotideUtilities.R] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.Y] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.M] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.K] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.W] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.S] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.B] = Color.magenta; 
		baseSelectionForegroundColor[NucleotideUtilities.D] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.H] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.V] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.N] = Color.magenta; 
		baseSelectionForegroundColor[NucleotideUtilities.GAP] = Color.magenta;
		baseSelectionForegroundColor[NucleotideUtilities.UNKNOWN] = Color.magenta;
		
		

		
		baseSelectionBackgroundColor = new Color[64];
		baseSelectionBackgroundColor[NucleotideUtilities.A] = new Color(130+50,210,130+50); 
		baseSelectionBackgroundColor[NucleotideUtilities.C] = new Color(160+50,160+50,255); 
		baseSelectionBackgroundColor[NucleotideUtilities.G] = new Color(140+50,140+50,140+50); 
		baseSelectionBackgroundColor[NucleotideUtilities.TU] = new Color(255,160+50,160+50); 
		baseSelectionBackgroundColor[NucleotideUtilities.R] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.Y] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.M] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.K] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.W] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.S] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.B] = Color.white; 
		baseSelectionBackgroundColor[NucleotideUtilities.D] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.H] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.V] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.N] = Color.white; 
		baseSelectionBackgroundColor[NucleotideUtilities.GAP] = Color.white;
		baseSelectionBackgroundColor[NucleotideUtilities.UNKNOWN] = Color.white;
		
		
		/*
		 * 
		 * This is Clustal color-sceme
		 * 
		 */
		/*
		
		/*
		aminoAcidBackgroundColor = new Color[255];
		aminoAcidBackgroundColor[AminoAcid.F.intVal] = CLUSTAL_BLUE;
		aminoAcidBackgroundColor[AminoAcid.L.intVal] = CLUSTAL_BLUE;
		aminoAcidBackgroundColor[AminoAcid.I.intVal] = CLUSTAL_BLUE;
		aminoAcidBackgroundColor[AminoAcid.M.intVal] = CLUSTAL_BLUE;
		aminoAcidBackgroundColor[AminoAcid.V.intVal] = CLUSTAL_BLUE;
		aminoAcidBackgroundColor[AminoAcid.P.intVal] = CLUSTAL_YELLOW;
		aminoAcidBackgroundColor[AminoAcid.A.intVal] = CLUSTAL_BLUE;
		aminoAcidBackgroundColor[AminoAcid.W.intVal] = CLUSTAL_BLUE;
		aminoAcidBackgroundColor[AminoAcid.G.intVal] = CLUSTAL_ORANGE;
		aminoAcidBackgroundColor[AminoAcid.S.intVal] = CLUSTAL_ORANGE;
		aminoAcidBackgroundColor[AminoAcid.T.intVal] = CLUSTAL_GREEN;
		aminoAcidBackgroundColor[AminoAcid.Y.intVal] = CLUSTAL_CYAN;
		aminoAcidBackgroundColor[AminoAcid.Q.intVal] = CLUSTAL_GREEN;
		aminoAcidBackgroundColor[AminoAcid.N.intVal] = CLUSTAL_GREEN;
		aminoAcidBackgroundColor[AminoAcid.C.intVal] = CLUSTAL_PINK;
		aminoAcidBackgroundColor[AminoAcid.D.intVal] = CLUSTAL_MANGENTA;
		aminoAcidBackgroundColor[AminoAcid.E.intVal] = CLUSTAL_MANGENTA;
		aminoAcidBackgroundColor[AminoAcid.H.intVal] = CLUSTAL_CYAN;
		aminoAcidBackgroundColor[AminoAcid.K.intVal] = CLUSTAL_RED;
		aminoAcidBackgroundColor[AminoAcid.R.intVal] = CLUSTAL_RED;
		aminoAcidBackgroundColor[AminoAcid.STOP.intVal] = Color.darkGray;
		aminoAcidBackgroundColor[AminoAcid.X.intVal] = Color.white;
		*/
		
		/*
		 * 
		 * This is mesquite color-sceme
		 * 
		 */
		/*
		aminoAcidBackgroundColor = new Color[255];
		aminoAcidBackgroundColor[AminoAcid.A.intVal] = new Color(0x82e9ff);
		aminoAcidBackgroundColor[AminoAcid.C.intVal] = new Color(0xffabff);
		aminoAcidBackgroundColor[AminoAcid.D.intVal] = new Color(0xaea876);
		aminoAcidBackgroundColor[AminoAcid.E.intVal] = new Color(0x948f71);
		aminoAcidBackgroundColor[AminoAcid.F.intVal] = new Color(0x94b6ff);
		aminoAcidBackgroundColor[AminoAcid.G.intVal] = new Color(0xe306b0);
		aminoAcidBackgroundColor[AminoAcid.H.intVal] = new Color(0xb914ff);
		aminoAcidBackgroundColor[AminoAcid.I.intVal] = new Color(0x4f9bff);
		aminoAcidBackgroundColor[AminoAcid.K.intVal] = new Color(0xa70de3);
		aminoAcidBackgroundColor[AminoAcid.L.intVal] = new Color(0x0012b8);
		aminoAcidBackgroundColor[AminoAcid.M.intVal] = new Color(0x5eb5b5);
		aminoAcidBackgroundColor[AminoAcid.N.intVal] = new Color(0xff000c);
		aminoAcidBackgroundColor[AminoAcid.P.intVal] = new Color(0x14b86e);
		aminoAcidBackgroundColor[AminoAcid.Q.intVal] = new Color(0x810d0f);
		aminoAcidBackgroundColor[AminoAcid.R.intVal] = new Color(0xa172b7);
		aminoAcidBackgroundColor[AminoAcid.S.intVal] = new Color(0xffdf0a);
		aminoAcidBackgroundColor[AminoAcid.T.intVal] = new Color(0x781b1e);
		aminoAcidBackgroundColor[AminoAcid.V.intVal] = new Color(0x2ab528);
		aminoAcidBackgroundColor[AminoAcid.W.intVal] = new Color(0x9bc186);
		aminoAcidBackgroundColor[AminoAcid.Y.intVal] = new Color(0xea8f85);
		aminoAcidBackgroundColor[AminoAcid.STOP.intVal] = Color.black;
		aminoAcidBackgroundColor[AminoAcid.GAP.intVal] = Color.white;
		aminoAcidBackgroundColor[AminoAcid.X.intVal] = Color.white;
		*/
		
		/*
		 * 
		 * This is seaview color-sceme (almost - but I put shades on same color)
		 * 
		 */
		aminoAcidBackgroundColor = new Color[255];
		aminoAcidBackgroundColor[AminoAcid.A.intVal] = new Color(0x276eb7);
		aminoAcidBackgroundColor[AminoAcid.C.intVal] = new Color(0xe68080);
		aminoAcidBackgroundColor[AminoAcid.D.intVal] = new Color(0xcc4dcc);
		aminoAcidBackgroundColor[AminoAcid.E.intVal] = new Color(0x984097);
		aminoAcidBackgroundColor[AminoAcid.F.intVal] = new Color(0x1980e6);
		aminoAcidBackgroundColor[AminoAcid.G.intVal] = new Color(0xe6994d);
		aminoAcidBackgroundColor[AminoAcid.H.intVal] = new Color(0x19b3b3);
		aminoAcidBackgroundColor[AminoAcid.I.intVal] = new Color(0x4ea0f3);
		aminoAcidBackgroundColor[AminoAcid.K.intVal] = new Color(0xe63319);
		aminoAcidBackgroundColor[AminoAcid.L.intVal] = new Color(0x78a6d5);
		aminoAcidBackgroundColor[AminoAcid.M.intVal] = new Color(0x0f549b);
		aminoAcidBackgroundColor[AminoAcid.N.intVal] = new Color(0x19cc19);
		aminoAcidBackgroundColor[AminoAcid.P.intVal] = new Color(0xcccc00);
		aminoAcidBackgroundColor[AminoAcid.Q.intVal] = new Color(0x5ced5c);
		aminoAcidBackgroundColor[AminoAcid.R.intVal] = new Color(0xf6442c);
		aminoAcidBackgroundColor[AminoAcid.S.intVal] = new Color(0x029602);
		aminoAcidBackgroundColor[AminoAcid.T.intVal] = new Color(0x45c945);
		aminoAcidBackgroundColor[AminoAcid.V.intVal] = new Color(0x047df9);
		aminoAcidBackgroundColor[AminoAcid.W.intVal] = new Color(0x0355a9);
		aminoAcidBackgroundColor[AminoAcid.Y.intVal] = new Color(0x14c6c8);
		aminoAcidBackgroundColor[AminoAcid.STOP.intVal] = Color.black;
		aminoAcidBackgroundColor[AminoAcid.GAP.intVal] = Color.white;
		aminoAcidBackgroundColor[AminoAcid.X.intVal] = Color.white;
		
		aminoAcidForegroundColor = new Color[255];
		aminoAcidForegroundColor[AminoAcid.A.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.C.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.D.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.E.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.F.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.G.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.H.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.I.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.K.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.L.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.M.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.N.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.P.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.Q.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.R.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.S.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.T.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.V.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.W.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.Y.intVal] = Color.BLACK;
		aminoAcidForegroundColor[AminoAcid.STOP.intVal] = Color.CYAN;
		aminoAcidForegroundColor[AminoAcid.GAP.intVal] = Color.MAGENTA;
		aminoAcidForegroundColor[AminoAcid.X.intVal] = Color.white;
		
		aminoAcidSelectionBackgroundColor = new Color[255];
		aminoAcidSelectionBackgroundColor[AminoAcid.A.intVal] = new Color(0x276eb7).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.C.intVal] = new Color(0xe68080).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.D.intVal] = new Color(0xcc4dcc).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.E.intVal] = new Color(0x984097).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.F.intVal] = new Color(0x1980e6).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.G.intVal] = new Color(0xe6994d).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.H.intVal] = new Color(0x19b3b3).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.I.intVal] = new Color(0x4ea0f3).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.K.intVal] = new Color(0xe63319).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.L.intVal] = new Color(0x78a6d5).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.M.intVal] = new Color(0x0f549b).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.N.intVal] = new Color(0x19cc19).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.P.intVal] = new Color(0xcccc00).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.Q.intVal] = new Color(0x5ced5c).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.R.intVal] = new Color(0xf6442c).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.S.intVal] = new Color(0x029602).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.T.intVal] = new Color(0x45c945).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.V.intVal] = new Color(0x047df9).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.W.intVal] = new Color(0x0355a9).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.Y.intVal] = new Color(0x14c6c8).brighter();
		aminoAcidSelectionBackgroundColor[AminoAcid.STOP.intVal] = Color.darkGray;
		aminoAcidSelectionBackgroundColor[AminoAcid.GAP.intVal] = Color.lightGray;
		aminoAcidSelectionBackgroundColor[AminoAcid.X.intVal] = Color.GRAY;
		
		aminoAcidSelectionForegroundColor = new Color[255];
		aminoAcidSelectionForegroundColor[AminoAcid.A.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.C.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.D.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.E.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.F.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.G.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.H.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.I.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.K.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.L.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.M.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.N.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.P.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.Q.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.R.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.S.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.T.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.V.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.W.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.Y.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.STOP.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.GAP.intVal] = Color.GRAY;
		aminoAcidSelectionForegroundColor[AminoAcid.X.intVal] = Color.white;

	}

	public Color getBaseBackgroundColor(int baseValue) {
		return baseBackgroundColor[baseValue];
	}

	public Color getBaseForegroundColor(int baseValue) {
		return baseForegroundColor[baseValue];
	}

	public Color getBaseSelectionForegroundColor(int baseValue) {
		return baseSelectionForegroundColor[baseValue];
	}
	
	public Color getBaseSelectionBackgroundColor(int baseValue) {
		return baseSelectionBackgroundColor[baseValue];
	}

	public Color getAminoAcidBackgroundColor(AminoAcid acid) {
		return aminoAcidBackgroundColor[acid.intVal];
	}

	public Color getAminoAcidForgroundColor(AminoAcid acid) {
		return aminoAcidForegroundColor[acid.intVal];
	}

	public Color getAminoAcidSelectionBackgroundColor(AminoAcid acid) {
		return aminoAcidSelectionBackgroundColor[acid.intVal];
	}

	public Color getAminoAcidSelectionForegroundColor(AminoAcid acid) {
		return aminoAcidSelectionForegroundColor[acid.intVal];
	}
}
