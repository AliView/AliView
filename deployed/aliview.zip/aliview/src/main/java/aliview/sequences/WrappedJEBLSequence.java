package aliview.sequences;


import java.util.Arrays;



public class WrappedJEBLSequence extends InMemorySequence {
	private jebl.evolution.sequences.Sequence jeblSequence;
	

	public WrappedJEBLSequence(jebl.evolution.sequences.Sequence jeblSeq) {
		super();
		
		this.jeblSequence = jeblSeq;
		this.setBases(jeblSeq.getString().getBytes(), null);	
	}
	
	public String getName() {
		return jeblSequence.getTaxon().toString();
	}
	
	public String toString() {
		return jeblSequence.getTaxon().toString();
	}

	@Override
	public String getSimpleName() {
		return getName();
	}

	public int compareTo(Sequence anotherSeq) {
		return this.getSimpleName().compareTo(anotherSeq.getSimpleName());
	}

}
