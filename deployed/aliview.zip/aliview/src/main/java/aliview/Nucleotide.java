package aliview;

import java.io.UnsupportedEncodingException;

import jebl.evolution.sequences.NucleotideState;

public class Nucleotide {
	
	/*
	public static final Nucleotide A = new Nucleotide("Adenine", "A", 1);
	public static final Nucleotide C = new Nucleotide("Cytosine", "C", 2);
	public static final Nucleotide G = new Nucleotide("Guanine", "G", 4);
	public static final Nucleotide T = new Nucleotide("Thymine", "T", 8);
	public static final Nucleotide U = new Nucleotide("Uracil", "U", 8);
	public static final Nucleotide TU = new Nucleotide("Thymnine/Uracil", "T", 8);
	public static final Nucleotide R = new Nucleotide("A or G", "AG", 2);
	public static final Nucleotide C = new Nucleotide("Y", "C", 2);
	public static final Nucleotide C = new Nucleotide("Cytosine", "C", 2);
	public static final Nucleotide C = new Nucleotide("Cytosine", "C", 2);
	public static final Nucleotide C = new Nucleotide("Cytosine", "C", 2);
	public static final Nucleotide C = new Nucleotide("Cytosine", "C", 2);
	public static final Nucleotide C = new Nucleotide("Cytosine", "C", 2);
	public static final Nucleotide C = new Nucleotide("Cytosine", "C", 2);


	private String name;
	private String code;
	public int intVal;

    public Nucleotide(String name, String threeLetterName, String code, int intVal) {
		this.name = name;
		this.code = code;
		this.intVal = intVal;
	}
	*/
    
    
}
