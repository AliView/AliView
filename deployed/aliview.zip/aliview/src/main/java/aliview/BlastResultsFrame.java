package aliview;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JScrollPane;

import scripts.bio.blast.BlastHit;
import scripts.bio.blast.BlastPrimerEvaluation;

public class BlastResultsFrame extends JFrame {
	JPanel mainPanel = new JPanel();
	JTextArea consoleTextArea;
	private AliView aliViewProgram;
	
	public BlastResultsFrame(AliView aliView) {
		this.aliViewProgram = aliView;
		
		// first create textoutput
		/*
		consoleTextArea = new JTextArea();
		PrintStream con=new PrintStream(new TextAreaOutputStream(consoleTextArea,1000));
		System.setOut(con);
		System.setErr(con);
		*/
		mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		//consoleTextArea.setMinimumSize(new Dimension(400,600));
		//mainPanel.add(consoleTextArea);
		
		
		JScrollPane scrollPane = new JScrollPane(mainPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		this.setTitle("Blast Results");
		this.setPreferredSize(new Dimension(600,400));
		this.pack();
		this.setVisible(true);
			
	}
	
	public void createBlastPrimerResult(BlastPrimerEvaluation primEval){
		
		//mainPanel.remove(consoleTextArea);
		
		JLabel txt1 = new JLabel("Is not in Sequence result But other Primer Directory");
		mainPanel.add(txt1);
		ArrayList<BlastHit> isNotInSequenceDirButOtherPrimerDir = primEval.getIsNotInSequenceDirButOtherPrimerDir();
		for(BlastHit hit: isNotInSequenceDirButOtherPrimerDir){
			mainPanel.add(new BlastResultPanel(hit, aliViewProgram));
			
		}
		
		JLabel txt2 = new JLabel("Is not in Sequence result but is a top Hit");
		mainPanel.add(txt2);
		ArrayList<BlastHit> isNotInSequenceDirAndIsTopHit = primEval.getIsNotInSequenceDirAndIsTopHit();
		for(BlastHit hit: isNotInSequenceDirAndIsTopHit){
			mainPanel.add(new BlastResultPanel(hit, aliViewProgram));		
		}
		
		this.pack();
		
		
		
	}
}
