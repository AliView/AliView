package aliview;

import java.io.File;
import java.io.StringReader;

import aliview.sequences.Sequence;

public class AlignmentFactory {

	
	// TODO change so it also reads from buffer
	
	/*
	 * Create alignment i ń factory since we dont know until we have read file if it is a nucleotide
	 * or a protein alignment
	 * 
	 */
	public static Alignment createNewAlignment(File alignmentFile) {

			//this.alignmentFile = alignmentFile;
			long startTime = System.currentTimeMillis();

			MemoryArrayMatrix matrix = new MemoryArrayMatrix(alignmentFile);
			
			// this.sequences = this.matrix.getSequences();
			//logger.info("number of seq" + this.matrix.getSequences().size());
			//this.longestSequenceLength = matrix.getLongestSequenceLength();
			//logger.info("longestSequenceLength" + getMaximumSequenceLength());
			// TODO se till att excludes hamnar i undo

			// read and set excludes
			
			
			// Try to read Excludes from alignmentfile
			Excludes excludes = NexusUtilities.updateExcludesFromFile(alignmentFile,new Excludes(matrix.getLongestSequenceLength()));
			
			// Try to read Excludes from metaFile
			if(excludes == null){
				File metaFile = new File(alignmentFile.getAbsolutePath()+ ".meta");
				if(metaFile.exists()){
					excludes = NexusUtilities.updateExcludesFromFile(metaFile,new Excludes(matrix.getLongestSequenceLength()));
				}
			}
			// No excludes on file - create a new one
			if(excludes == null){
				excludes = new Excludes(matrix.getLongestSequenceLength());	
			}
			
			// try reading codonpos from nexusfile
			CodonPositions codonPositions = NexusUtilities.updateCodonPositionsFromNexusFile(alignmentFile, new CodonPositions(matrix.getLongestSequenceLength()));
			
			// Try to read CodonPos from metaFile
			if(codonPositions == null){
				File metaFile = new File(alignmentFile.getAbsolutePath()+ ".meta");
				if(metaFile.exists()){
					codonPositions = NexusUtilities.updateCodonPositionsFromNexusFile(metaFile, new CodonPositions(matrix.getLongestSequenceLength()));
				}
			}
			
			// not in file create a new one
			if(codonPositions == null){
				codonPositions = new CodonPositions(matrix.getLongestSequenceLength());
				//codonPositions.updateCodonPositionsToDefault123BetweenExset(excludes);
			}
			
			
			Alignment alignment = null;
			if(matrix.getSequenceType() == Sequence.TYPE_NUCLEIC_ACID){
				alignment = new NucleotideAlignment(alignmentFile, matrix.getFileFormat(), matrix, excludes, codonPositions);
			}
			else{
				alignment = new AminoAcidAlignment(alignmentFile, matrix.getFileFormat(), matrix, excludes, codonPositions);
			}
			
			
			long endTime = System.currentTimeMillis();
			System.out.println("Importing sequences took " + (endTime - startTime) + " milliseconds");
			
			return alignment;
		}

}
		
