package aliview;

import org.apache.commons.lang.StringUtils;

import aliview.utils.OSNativeUtils;

public class FileFormat {
	
	private String name;
	private String suffix;
	private String suffixWin;
	
	public static final FileFormat FASTA = new FileFormat("Fasta", "fasta", "fas");
	public static final FileFormat NEXUS = new FileFormat("Nexus", "nexus", "nex");
	public static final FileFormat NEXUS_CODONPOS_CHARSET = new FileFormat("Nexus", "codonpos.nexus", "codonpos.nex");
	public static final FileFormat NEXUS_SIMPLE = new FileFormat("Nexus", "nexus", "nex");
	public static final FileFormat PHYLIP = new FileFormat("Phylip", "phy", "phy");
	
	public FileFormat(String name, String suffix, String suffixWin) {
		this.name = name;
		this.suffix = suffix;
		this.suffixWin = suffixWin;
	}
	
	public static final String stripFileSuffixFromName(String name){
		String strippedName = StringUtils.substringBeforeLast(name, ".");
		return strippedName;
	}
	
	public String getSuffix(){
		if(OSNativeUtils.isWindows()){
			return suffixWin;
		}else{
			return suffix;
		}
	}
}
