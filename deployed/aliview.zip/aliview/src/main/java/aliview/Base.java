package aliview;

import aliview.sequences.Sequence;

public class Base {
	private Sequence sequence;
	private int position;
	
	public Base(Sequence sequence, int position) {
		this.sequence = sequence;
		this.position = position;
	}
	
	public Sequence getSequence() {
		return sequence;
	}
	public int getPosition() {
		return position;
	}
	
	public void setSelection(boolean selected) {
		this.sequence.setBaseSelection(this.position, selected);	
	}

	public boolean isSelected() {
		// TODO Auto-generated method stub
		return this.sequence.getBasesSelection()[this.position];	
	}
	
}
