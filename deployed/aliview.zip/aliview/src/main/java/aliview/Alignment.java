package aliview;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

import org.apache.commons.io.FileExistsException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.output.FileWriterWithEncoding;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.IntRange;
import org.apache.log4j.Logger;

import sun.security.action.GetLongAction;

import aliview.primer.Dimer;
import aliview.primer.Primer;
import aliview.sequencelist.SequenceListModel;
import aliview.sequences.InMemoryBasicSequence;
import aliview.sequences.Sequence;
import aliview.settings.Settings;
import aliview.utils.DialogUtils;
import aliview.utils.Utilities;

public class Alignment {
	private static final Logger logger = Logger.getLogger(Alignment.class);

	ArrayList<Sequence> sequences;
	private byte[][] basesMatrix;
	private boolean[][] basesSelectionMatrix;
	private SequenceListModel seqListModel;
	protected int nextFindSequenceNumber;
	protected int nextFindStartPos;
	//protected int nextNameFindSequenceNumber;
	private File alignmentFile;
	private Matrix matrix;
	private int PRIMER_MAX_DEGENERATE_SCORE = 1000;
	private boolean showPartialNameOnly;
	private Excludes excludes;
	private CodonPositions codonPositions;
	private boolean isEditedAfterLastSave = false;

	private FileFormat fileFormat;

	
	public Alignment() {
		this.matrix = new MemoryArrayMatrix();
		this.sequences = this.matrix.getSequences();
		this.excludes = new Excludes(this.getMaximumSequenceLength());	
		basesMatrix = null;
		basesSelectionMatrix = null;
		setEditedAfterLastSave(false);
	}
	
	
	public Alignment(File file, FileFormat fileFormat, Matrix matrix, Excludes excludes, CodonPositions codonPos) {
		this.alignmentFile = file;
		this.fileFormat = fileFormat;
		this.matrix = matrix;
		this.sequences = this.matrix.getSequences();
		this.excludes = excludes;
		this.codonPositions = codonPos;
		basesMatrix = null;
		basesSelectionMatrix = null;
		setEditedAfterLastSave(false);
	}

	
	public Alignment(MemoryArrayMatrix matrix) {
		this.matrix = matrix;
		this.excludes = new Excludes(this.getMaximumSequenceLength());	
		this.codonPositions = new CodonPositions(this.getMaximumSequenceLength());
		//this.codonPositions.updateCodonPositionsToDefault123BetweenExset(this.excludes);
	}


	/*
	 * 
	 * TODO move this method to Factory
	 * 
	 */
	public void reloadMatrixFromFasta(StringReader stringReader) {
		long startTime = System.currentTimeMillis();

		this.matrix = new MemoryArrayMatrix(stringReader);
		
		this.sequences = this.matrix.getSequences();
		//this.longestSequenceLength = matrix.getLongestSequenceLength();
		this.excludes = new Excludes(this.getMaximumSequenceLength());	

		basesMatrix = null;
		basesSelectionMatrix = null;
		setEditedAfterLastSave(false);

		long endTime = System.currentTimeMillis();
		System.out.println("reloading sequences took " + (endTime - startTime) + " milliseconds");
		
	}



	public byte[][] getBasesMatrix(){

		if(basesMatrix == null){
			
			long startTime = System.currentTimeMillis();
			
			basesMatrix = new byte[sequences.size()][];
			for(int n = 0; n < sequences.size(); n++){
				basesMatrix[n] = sequences.get(n).getBases();
				/*
				if(basesMatrix[n].length < 3710){
					logger.info(basesMatrix[n].length + " seqname " + sequences.get(n).getName());
				}
				 */
			}
			long endTime = System.currentTimeMillis();
			logger.info("Creating matrix took " + (endTime - startTime) + " milliseconds");
			
		}

		return basesMatrix;	
	}
	

	private boolean[][] getBasesSelectionMatrix(){
		
		
		if(basesSelectionMatrix == null){
			long startTime = System.currentTimeMillis();
			basesSelectionMatrix= new boolean[sequences.size()][];

			//logger.info("newMatrix");
			
			for(int n = 0; n < sequences.size(); n++){
				basesSelectionMatrix[n] = sequences.get(n).getBasesSelection();
				
			}
			long endTime = System.currentTimeMillis();
			logger.info("Creating matrix took " + (endTime - startTime) + " milliseconds");
		}
		
		

		return basesSelectionMatrix;	
	}

	public ArrayList<Sequence> getSequences() {
		return sequences;
	}

	public int getMaximumSequenceLength() {
		
		int longest = 0;
		for(byte[] byteSeq : getBasesMatrix()){
			longest = Math.max(longest, byteSeq.length);
		}
		
		return longest;
	}


	public int getSize(){
		return sequences.size();
	}

	public void clearSelection() {
		for(Sequence seq: sequences){
			seq.clearAllBaseSelection();
		}
	}

	public int getSequencePosition(Sequence seq) {
		int sequencePosition = 0;
		for(int n = 0; n < sequences.size(); n++){
			if(sequences.get(n) == seq){
				sequencePosition = n;
				break;
			}
		}
		return sequencePosition;
	}

	public void updateSequenceOrder() {
		updateSequencesMatrix();
	}
	
	

	void updateSequencesMatrix() {
		basesMatrix = null;
		basesSelectionMatrix = null;
	}



	public SequenceListModel createSequenceListModel() {		
		seqListModel = new SequenceListModel(sequences);
		return seqListModel;
	}
	
	
	public void storeAlignmetAsFasta(Writer out) throws IOException{
		
		boolean firstSeq = true;	
		for(Sequence seq: sequences){
			String name = seq.getName();
			
			if(! name.startsWith(">")){
				out.write('>');
			}
			out.write(seq.getName());
			out.write("\r\n");
			out.write(new String(seq.getBases()));
			out.write("\r\n");
		}		
		out.flush();
		out.close();
	}
	
	
	private void storeAlignmetAsPhyFile(Writer out) throws IOException{
		// First line number of seq + seqLen
		out.write("" + sequences.size() + " " + this.getMaximumSequenceLength() + "\n");
		
		for(Sequence seq: sequences){			
			out.write("" + StringUtils.rightPad(seq.getName(),100) + "" +  new String(seq.getBases()));
			out.write("\n");
		}
		
		out.flush();
		out.close();	
		
	}
	
	
	private void storeMetaData(BufferedWriter outMeta) throws IOException {
		
		outMeta.write("" + NexusUtilities.getExcludesAsNexusBlock(this.getExcludes()));
		outMeta.write("\n");
		outMeta.write("" + NexusUtilities.getCodonPosAsNexusBlock(this.getCodonPositions()));
		
		
		outMeta.flush();
		outMeta.close();
		
	}

	public void saveAlignmentAsFile(File outFile) throws IOException{	
		// save as current format
		saveAlignmentAsFile(outFile,this.fileFormat);	
	}

	public void saveAlignmentAsFile(File outFile, FileFormat fileFormat) throws IOException{
			BufferedWriter out = new BufferedWriter(new FileWriter(outFile));
			
			if(fileFormat == FileFormat.FASTA){
				storeAlignmetAsFasta(out);
				// save meta if exset it is set
				if(this.excludes.isAnythingExcluded()){
					BufferedWriter outMeta = new BufferedWriter(new FileWriter(new File(outFile.getAbsoluteFile() + ".meta")));
					storeMetaData(outMeta);
				}
			}else if(fileFormat == FileFormat.PHYLIP){
				storeAlignmetAsPhyFile(out);
				// save meta if exset it is set
				if(this.excludes.isAnythingExcluded()){
					BufferedWriter outMeta = new BufferedWriter(new FileWriter(new File(outFile.getAbsoluteFile() + ".meta")));
					storeMetaData(outMeta);
				}
			}else if(fileFormat == FileFormat.NEXUS){
				NexusUtilities.exportAlignmentAsNexus(new BufferedWriter(new FileWriter(outFile)), this, false);
			}else if(fileFormat == FileFormat.NEXUS_SIMPLE){
				NexusUtilities.exportAlignmentAsNexus(new BufferedWriter(new FileWriter(outFile)), this, true);
			}else if(fileFormat == FileFormat.NEXUS_CODONPOS_CHARSET){
				NexusUtilities.exportAlignmentAsNexusCodonpos(new BufferedWriter(new FileWriter(outFile)), this);
			}		
	}
	



	public Sequence mergeSequences(Sequence seq1, Sequence seq2, boolean allowOverlap){

		Sequence mergedSeq = null;
		byte[] merged = new byte[seq1.getLength()];

		// loop through and check overlap
		boolean isOverlap = false;
		boolean isOverlapExactlySame = true;
		int nExactOverlap = 0;
		int nDifferentOverlap = 0;
		for(int n = 0; n < seq1.getLength(); n++){
			if(isAtLeastOneGap(seq1.getBaseAtPos(n),seq2.getBaseAtPos(n))){

			}else{
				isOverlap = true;
				if(NucleotideUtilities.baseValFromBase(seq1.getBaseAtPos(n)) == NucleotideUtilities.baseValFromBase(seq2.getBaseAtPos(n))){
					nExactOverlap ++;	
				}
				else{
					nDifferentOverlap ++;
					isOverlapExactlySame = false;
				}
				
				// compare strings??

			}
		}

		// Warn
		if(isOverlap){			
			String overlapMessage = "";
			if(isOverlapExactlySame){
				overlapMessage = "Overlapping parts are identical (" + nExactOverlap +"bases)";
			}else{
				overlapMessage = "Overlapping parts are different (" + nDifferentOverlap + "/" + (nDifferentOverlap + nExactOverlap) + ")";
				
			}
			String message="Sequences are overlapping - " + overlapMessage + "\n" +
			"Do you want to continue?";
			
			// TODO I dont know how to deal with dialogs in a nice pattern way if it is within the alignment class? Maybe it should be splited
			// and moved into aliview-class (for example to do a temporary merge and then ask and then call alignment again to do join
			int retVal = JOptionPane.showConfirmDialog(DialogUtils.getDialogParent(), message, "Continue?", JOptionPane.OK_CANCEL_OPTION);
			if(retVal != JOptionPane.OK_OPTION){
				return null;
			}
		}
		else{
			String message= "Sequences are NOT overlapping" + "\n" +
			"Do you want to continue?";
			int retVal = JOptionPane.showConfirmDialog(DialogUtils.getDialogParent(), message, "Continue?", JOptionPane.OK_CANCEL_OPTION);
			if(retVal != JOptionPane.OK_OPTION){
				return null;
			}
		}


		for(int n = 0; n < seq1.getLength(); n++){
			merged[n] = getConsensusFromBases(seq1.getBaseAtPos(n),seq2.getBaseAtPos(n));
		}

		if(isOverlap && allowOverlap == false){

		}
		else{
			// set new merged data - keep selection
			seq1.setBases(merged, seq1.getBasesSelection());
			seq2.setBases(merged.clone(), seq2.getBasesSelection());	
			
			// actually it is easier to remove seq2
			// sequences.remove(seq2);
			
			mergedSeq = new InMemoryBasicSequence(seq1.getName(), merged);
		}
		
		return mergedSeq;

	}
	
	
	public void deleteAllExsetBases(){
		
		// a simple way is to gap all excluded positions and then clear vertical gaps
		for(Sequence seq:sequences){
			for(int n = 0; n < seq.getLength(); n++){
				if(excludes.isExcluded(n)){
					// nucleotide gap is same as protein gap
					seq.replaceBase(n, NucleotideUtilities.charFromBaseVal(NucleotideUtilities.GAP));
				}
			}
		}
			
		// clear vertical gaps
		removeVerticalGaps();
		
	}



	private byte getMinBase(byte base1, byte base2) {

		int baseVal1 = NucleotideUtilities.baseValFromBase(base1);
		int baseVal2 = NucleotideUtilities.baseValFromBase(base2);
		int minBaseVal = Math.min(baseVal1,baseVal2);

		return NucleotideUtilities.byteFromBaseVal(minBaseVal);

	}
	
	private byte getConsensusFromBases(byte base1, byte base2) {

		int baseVal1 = NucleotideUtilities.baseValFromBase(base1);
		int baseVal2 = NucleotideUtilities.baseValFromBase(base2);
		
		
		// Create consensus by bitwise OR of the bases in the same column
		int consensusVal = baseVal1 | baseVal2;
		
		// skip GAP
		/*
		if((consensusVal & NucleotideUtilities.GAP) == NucleotideUtilities.GAP){
			consensusVal = consensusVal - NucleotideUtilities.GAP;
		}
		*/
		
		byte consensus = NucleotideUtilities.byteFromBaseVal(consensusVal);
		
		//logger.info("baseVal1 " + baseVal1 + " baseVal2 " + baseVal2 + " consensus " + consensusVal + " consensus " + consensus);

		return consensus;

	}


	private boolean isAtLeastOneGap(byte base1, byte base2) {
		if('-' == base1 || '-' == base2){
			return true;
		}
		else{
			return false;
		}
	}

	public void saveSelectionAsFastaFile(File selectedFile, int minLen) {
		String selectionAsFasta = getSelectionAsFasta(minLen);
		//logger.info(selectionAsFasta);
		try {
			FileUtils.write(selectedFile, selectionAsFasta);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getSelectionAsFasta(int minLen){
		StringBuilder selectionAsFasta = new StringBuilder();
		for(Sequence sequence : sequences){
			
			if(sequence.hasSelection()){
				
		//		logger.info("foundSeq");
				
				// filter out short uninteresting sequences
				String tempSeq = sequence.getSelectedBasesAsString();

		//		logger.info("tempseq" + tempSeq);

				if(tempSeq.length() > minLen){
					// TODO format name to fasta a bit better
					if(! sequence.getName().startsWith(">")){
						selectionAsFasta.append(">");
					}
					selectionAsFasta.append(sequence.getName());
					selectionAsFasta.append("\n");
					selectionAsFasta.append(sequence.getSelectedBasesAsString());
					selectionAsFasta.append("\n");
				}
			}
		}
		return selectionAsFasta.toString();
	}
	
	public Sequence getSequenceByName(String name){
		if(name == null){
			return null;
		}
		
		Sequence foundSeq = null;
		
		for(Sequence seq: sequences){
			if(name.equalsIgnoreCase(seq.getName())){
				foundSeq = seq;
				break;
			}
		}
		return foundSeq;	
	}
	
	
	public void pasteClipboard() {
		// TODO Auto-generated method stub
		
	}

	public ArrayList<Primer> findPrimerInSelection(){
		String selection = getSelectionAsNucleotides();
		int selectionStartPos = getSelectionStartPos();
		String[] selectionSeq = selection.split("\\n");

		// Start with a prototype as consensus
		int consensusVal[] = new int[selectionSeq[0].length()];

		for(String seq: selectionSeq){
			for(int n = 0; n < consensusVal.length; n++){
				int baseVal = NucleotideUtilities.baseValFromBase(seq.charAt(n));
				// Create consensus by bitwise OR of the bases in the same column 
				consensusVal[n] = consensusVal[n] | baseVal;
			}
		}

		// Create consensus from baseValues
		StringBuilder consensusBuilder = new StringBuilder();
		for(int n = 0; n < consensusVal.length; n++){
			consensusBuilder.append(NucleotideUtilities.charFromBaseVal(consensusVal[n]));
		}
		String consensus = consensusBuilder.toString();
		
		// remove gaps in consensus
		consensus = consensus.replaceAll("\\-", "");
		
		// create primer put them in a list and sort list (on score)
		// create all primer 20-24 bases long 
		int primerMinLen = Settings.getMinPrimerLength().getIntValue();
		int primerMaxLen = Settings.getMaxPrimerLength().getIntValue();
		Dimer.setDimerLengthThreashold(Settings.getDimerReportThreashold().getIntValue());
		ArrayList<Primer> allPrimers = new ArrayList<Primer>();
		
		long nCount = 0;
		for(int winSize = primerMinLen; winSize <= primerMaxLen; winSize ++){
			
			int offset = 0;		
			int startPos = offset;
			int endPos = offset + winSize;
			
			//logger.info(consensus.length());
			//logger.info( endPos);
			
			while(endPos <= consensus.length()){
				String primerSeq = consensus.substring(startPos, endPos);
				Primer aPrimer = new Primer(primerSeq, selectionStartPos + startPos);
				// only add primers below score
				if(aPrimer.getDegenerateFold() <= PRIMER_MAX_DEGENERATE_SCORE){
					allPrimers.add(aPrimer);
				}
				offset ++;
				startPos = offset;
				endPos = offset + winSize;
				nCount ++;
			}
			logger.info("winSize=" + winSize);
		}
		logger.info("Primers tested:" + nCount);
		
		Collections.sort(allPrimers);
		
		/*
		for(Primer primer: allPrimers){
			if(primer.getScore() < PRIMER_MAX_DEGENERATE_SCORE){
				logger.info("score: " + primer.getScore() + " tm: " + primer.getTmAsString() + " len: " + primer.getSequence().length() +  " primerSeq: " + primer.getSequence());
			}
		}
		*/
		
		return allPrimers;
		// https://ecom.mwgdna.com/services/webgist/mops.tcl?ot=OLIGO_ALC_UNMOD&oligoSequence=RTTGCTYRAKACTCGGTRA&ShowModiTables=OFF&oligo_name=&mod3=&mod5=&modx=&modz=&ot=OLIGO_ALC_UNMOD&oligo_name=&oligoSequence=RTT+GCT+YYY+RAK+ACT+CGG+TRA&action=properties&next_url=
		
	}

	private int getSelectionStartPos() {
		int selectionStartPos = 0;
		// get the first selected position
		// todo this could be changed to something nicer, maybe selection should be own class
		for(Sequence sequence : sequences){
			if(sequence.getSelectedBasesAsString() != null && sequence.getSelectedBasesAsString().length() > 0){
				selectionStartPos = sequence.getFirstSelectedPosition();
				break;
			}
		}
		return selectionStartPos;
	}



	private String getSelectionAsNucleotides(){
		StringBuilder selection = new StringBuilder();
		for(Sequence sequence : sequences){
			if(sequence.getSelectedBasesAsString() != null && sequence.getSelectedBasesAsString().length() > 0){
				selection.append(sequence.getSelectedBasesAsString());
				selection.append("\n");
			}
		}
		return selection.toString();
	}


	public void copySelectionToClipboardAsFasta(int minLen){

		// Set to clipboard
		StringSelection ss = new StringSelection(getSelectionAsFasta(minLen));
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

	}
	
 
	public void reverseComplementAlignment(){
		
		for(Sequence seq : sequences){
			seq.reverseComplement();
		}
		
		this.getExcludes().reverse();
		this.getCodonPositions().reverse();
		// always create new codon when new excludes
		//codonPos = createCodonPos(this.getExcludes());
		
	}
	

	public void copySelectionToClipboardAsNucleotides(){

		// Set to clipboard
		StringSelection ss = new StringSelection(getSelectionAsNucleotides());
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

	}
	

	public void sortSequencesByName() {
		Collections.sort(sequences);
		this.updateSequenceOrder();
	}
	
	/*

	public void pushUndoState(){	
		//BufferedWriter out = new BufferedWriter(new StringWriter());
		ArrayList<Sequence> undo_sequences = (ArrayList<Sequence>) sequences.clone();
		undo_sequenceLists.push(undo_sequences);
	}
	
	public void pushRedoState(){	
		//BufferedWriter out = new BufferedWriter(new StringWriter());
		//ArrayList<Sequence> redo_sequences = (ArrayList<Sequence>) sequences.clone();
		ArrayList<Sequence> redo_sequences = (ArrayList<Sequence>) sequences.clone();
		redo_sequenceLists.push(redo_sequences);
	}
	
	public void undo() {
		// first store order so we can redo
		pushRedoState();
		
		logger.info("undoSize" + undo_sequenceLists.size());
		if(! undo_sequenceLists.isEmpty()){
			sequences = (ArrayList<Sequence>) undo_sequenceLists.pop();
		}
		
	}
	
	public void redo() {
		// first store order so we can undo
		pushUndoState();
		
		if(! redo_sequenceLists.isEmpty()){
			sequences = (ArrayList<Sequence>) redo_sequenceLists.pop();
		}
		
	}
	*/
	
	/*
	public void mergeAllIdenticalNonoverlappingSameName() {

		getSequences()

		if(selected.length == 2){
			mergeSequences((Sequence) selected[0], (Sequence) selected[1], false);
		}

	}
	 */
	public boolean mergeSelected(Object[] selected, boolean allowOverlap) {
		boolean isMerged = false;
		if(selected.length == 2){
			Sequence merged = mergeSequences((Sequence) selected[0], (Sequence) selected[1], allowOverlap);
			if(merged != null){
				isMerged = true;
			}
		}
		
		return isMerged;

	}


	public List<Integer> findInNames(String searchTerm, int nextNameFindSequenceNumber, boolean findAll) {
		searchTerm = searchTerm.toLowerCase();
		List<Integer> foundIndices = new ArrayList<Integer>();
		
		if(findAll){
			for(int n = 0; n < seqListModel.getSize(); n++){		
				Sequence seq = seqListModel.get(n);
				if(seq.getName().toUpperCase().indexOf(searchTerm.toUpperCase()) > -1){
					logger.info("Found" + n);
					foundIndices.add(new Integer(n));
				}		
			}
			
		// Find first or next
		}else{
			for(int n = nextNameFindSequenceNumber; n < seqListModel.getSize(); n++){		
				Sequence seq = seqListModel.get(n);
				if(seq.getName().toUpperCase().indexOf(searchTerm.toUpperCase()) > -1){
					logger.info("Found" + n);
					nextNameFindSequenceNumber = n + 1;
					foundIndices.add(new Integer(n));
					break;
				}		
			}
		}
		
		return foundIndices;
	}
	

	public Point findInSequences(String searchTerm) {
		String regex = "";
		for(int n = 0; n < searchTerm.length(); n++){
			regex += searchTerm.charAt(n);
			// add one or many gap between each character to be found
			regex +="\\-*"; 
		}
		
		// lower-case before replace
		regex = regex.toLowerCase();

		// upac-codes
		regex = regex.replaceAll("w", "\\[tua\\]");
		regex = regex.replaceAll("n", "\\[agctu\\]");
		regex = regex.replaceAll("r", "\\[ag\\]");
		regex = regex.replaceAll("y", "\\[ctu\\]");
		regex = regex.replaceAll("m", "\\[ca\\]");
		regex = regex.replaceAll("k", "\\[tug\\]");

		regex = regex.replaceAll("s", "\\[cg\\]");
		regex = regex.replaceAll("b", "\\[ctug\\]");
		regex = regex.replaceAll("d", "\\[atug\\]");
		regex = regex.replaceAll("h", "\\[atuc\\]");
		regex = regex.replaceAll("v", "\\[acg\\]");
		regex = regex.replaceAll("n", "\\[agctu\\]");

		// Step 1: Allocate a Pattern object to compile a regexe
		//String regex = "tc\\-*a\\-*a\\-*a\\-*a\\-*a\\-*";
		//String regex = "t*c*a*a*";
		//String regex = "ctaa";
		Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE);
	
		for(int n = nextFindSequenceNumber; n < sequences.size(); n++){
			Sequence seq = sequences.get(n);
			Base[] foundBases = seq.findAndSelect(pattern,nextFindStartPos);
			if(foundBases != null){
				nextFindSequenceNumber = n;
				int position = foundBases[0].getPosition();		
				// make sure it is not out of index
				nextFindStartPos = Math.min(position + 1, getMaximumSequenceLength() - 1);
				return new Point(position,n);
			}
			// not found in this seq - start again from 0
			nextFindStartPos = 0;

		}
		nextFindSequenceNumber = 0;
		nextFindStartPos = 0;
		return null;
	}



	public Base getFirstBaseInSelection() {
		// TODO Auto-generated method stub
		return null;
	}



	public File getAlignmentFile() {
		return this.alignmentFile;
	}



	public int getMatrixMaxX() {
		int maxLen = 0;
		for(byte[] byteSeq: getBasesMatrix()){
			maxLen = Math.max(maxLen, byteSeq.length);		
		}
		return maxLen;
	}

	public int getMatrixMaxY() {
		return getBasesMatrix().length;
	}



	public byte getBaseAt(int x, int y) {
		return getBasesMatrix()[y][x];
	}
	
	public byte[] getCodonAt(int x, int y){
		byte[] codon = new byte[3];
		for(int n = 0; n < 3; n ++){
			if(x + n < getBasesMatrix()[y].length){
				codon[n] = getBasesMatrix()[y][x + n];
			}
			else{
				codon[n] = '-';
			}
		}
		return codon;
	}



	public boolean isBaseSelected(int x, int y) {
		return getBasesSelectionMatrix()[y][x];
	}



	public void setBaseSelection(int x, int y, boolean b) {
		getBasesSelectionMatrix()[y][x] = b;
	}



	public void clearFindLastPos() {
		nextFindSequenceNumber = 0;
		nextFindStartPos = 0;
	}


	public String getFileName() {
		if(alignmentFile == null){
			return null;
		}
		return alignmentFile.getName();
		
	}



	public void setAlignmentFile(File alignmentFile) {
		if(alignmentFile != null && alignmentFile.exists()){
			this.alignmentFile = alignmentFile;
			
			// update name
		}
	}



	public void clearSelectedBases() {
		for(Sequence sequence : sequences){
			sequence.replaceSelectedBasesWithGap();
		}
		
	}
	
	public void deleteSelectedBases() {
		for(Sequence sequence : sequences){
			sequence.deleteSelectedBases();
		}
		updateSequencesMatrix();	
	}
	
	public String getConsensus(){
		int[] consVals = new int[getMatrixMaxX()];
		for(Sequence sequence : sequences){
			int[] baseVals = sequence.getBaseVals();
			// bitwise add everything
			for(int n = 0; n < baseVals.length; n++){
				consVals[n] = consVals[n] | baseVals[n];
			}
		}
		
		char[] cons = new char[consVals.length];
		for(int n = 0; n < cons.length; n++){
			cons[n] = NucleotideUtilities.charFromBaseVal(consVals[n]);
		}
		
		return new String(cons);
	}
	
	public void removeVerticalGaps(){
		String cons = getConsensus();
		int nGaps = Utilities.countMatches(cons, '-');
		if(nGaps > 0){
			for(Sequence sequence : sequences){
				int startPos = 0;
				int startPosInDestArray = 0;
				int nBytesToCopy = 0;
				
				byte[] newSeq = new byte[sequence.getBases().length - nGaps];
				for(int n = 0; n < sequence.getLength(); n++){
					if(cons.charAt(n) == '-'){
						if(nBytesToCopy > 0){
							//copy from start to end
							System.arraycopy(sequence.getBases(), startPos, newSeq, startPosInDestArray, nBytesToCopy);
							// next startPos
							startPosInDestArray = startPosInDestArray + nBytesToCopy;
							nBytesToCopy = 0;
							startPos = n + 1;
						}else{
							startPos = n + 1;
							nBytesToCopy = 0;
						}
					}else{
						nBytesToCopy ++;
					}
				}
				// and for the last
				if(nBytesToCopy > 0){
					//copy from start to end
					System.arraycopy(sequence.getBases(), startPos, newSeq, startPosInDestArray, nBytesToCopy);
				}
				// set new seq
				sequence.setBases(newSeq, null);
			}
			
			//remove in excludes & codonpos
			int startPos = 0;
			int startPosInDestArray = 0;
			int nBytesToCopy = 0;
			boolean[] newExsetPositions = new boolean[excludes.getPositions().length - nGaps];
			int[] newCodonPositionsArray = new int[codonPositions.getPositionsArray().length - nGaps];
			for(int n = 0; n < excludes.getPositions().length; n++){
				if(cons.charAt(n) == '-'){
					if(nBytesToCopy > 0){
						//copy from start to end
						System.arraycopy(excludes.getPositions(), startPos, newExsetPositions, startPosInDestArray, nBytesToCopy);
						System.arraycopy(codonPositions.getPositionsArray(), startPos, newCodonPositionsArray, startPosInDestArray, nBytesToCopy);
						startPosInDestArray = startPosInDestArray + nBytesToCopy;
						nBytesToCopy = 0;
						startPos = n + 1;
					}else{
						startPos = n + 1;
						nBytesToCopy = 0;
					}
				}else{
					nBytesToCopy ++;
				}
			}
			// and for the last
			if(nBytesToCopy > 0){
				//copy from start to end
				System.arraycopy(excludes.getPositions(), startPos, newExsetPositions, startPosInDestArray, nBytesToCopy);
				System.arraycopy(codonPositions.getPositionsArray(), startPos, newCodonPositionsArray, startPosInDestArray, nBytesToCopy);
			}
			
			// set new 
			excludes.setPositions(newExsetPositions);
			codonPositions.setPositionsArray(newCodonPositionsArray);
				
		}
		
		// to clear selection and so on
		updateSequencesMatrix();
	}



	public void addFasta(String clipboardSelection) {
		MemoryArrayMatrix alignmentMatrixFromClipboard = new MemoryArrayMatrix(new StringReader(clipboardSelection));
		ArrayList<Sequence> newSeqs = alignmentMatrixFromClipboard.getSequences();
		logger.info("sqssize" + newSeqs.size());
		sequences.addAll(newSeqs);
		updateSequencesMatrix();
	}

	public void moveSelectionRight() {
		for(Sequence sequence : sequences){
			sequence.moveSelectionRightIfGapIsPresent();
		}
		updateSequencesMatrix();
	}

	public void moveSelectionLeft() {
		for(Sequence sequence : sequences){
			sequence.moveSelectionLeftIfGapIsPresent();
		}
		updateSequencesMatrix();
	}
	
	public void moveSelection(int diff) {
		for(Sequence sequence : sequences){
			sequence.moveSelectionIfGapIsPresent(diff);
		}
		updateSequencesMatrix();
	}
	
	public void clearSelectionOffset() {
		for(Sequence sequence : sequences){
			sequence.setSelectionOffset(0);
		}
	}
	
	
	public void insertGapLeftOfSelectionMoveRight() {
		for(Sequence sequence : sequences){
			sequence.insertGapLeftOfSelectedBaseMoveRight();
		}
		updateSequencesMatrix();
		rightPadSequencesWithGapUntilEqualLength();
		updateSequencesMatrix();
	}

	private void rightPadSequencesWithGapUntilEqualLength() {
		int maxLen = 0;
		for(Sequence sequence : sequences){
			maxLen = Math.max(maxLen,sequence.getLength());
		}
		for(Sequence sequence : sequences){
			int diffLen = maxLen - sequence.getLength();
			sequence.rightPadSequencesWithGaps(diffLen);
		}
	}
	
	private void leftPadSequencesWithGapUntilEqualLength() {
		int maxLen = 0;
		for(Sequence sequence : sequences){
			maxLen = Math.max(maxLen,sequence.getLength());
		}
		for(Sequence sequence : sequences){
			int diffLen = maxLen - sequence.getLength();
			sequence.leftPadSequencesWithGaps(diffLen);
		}
	}



	public void insertGapRightOfSelectionMoveLeft() {
		for(Sequence sequence : sequences){
			sequence.insertGapRightOfSelectedBaseMoveLeft();
		}
		updateSequencesMatrix();
		leftPadSequencesWithGapUntilEqualLength();
		updateSequencesMatrix();
	}

	public void togglePartialNameOnly() {
		this.showPartialNameOnly = ! this.showPartialNameOnly;
		for(Sequence sequence : sequences){
			sequence.toggleSimpleName();
		}	
	}
	
	public boolean getTogglePartialNameOnly() {
		return this.showPartialNameOnly;
	}
	
	/**
	 * 
	 * This method is just for speed testing
	 * 
	 */
	public void getSelectedBases(){
		for(Sequence sequence : sequences){
			int[] selection = sequence.getSelectedBasesPositions();
		}
	}
	
	public Rectangle getSelectionAsMinRect(){
		int minX = Integer.MAX_VALUE;
		int minY = Integer.MAX_VALUE;
		int maxX = Integer.MIN_VALUE;
		int maxY = Integer.MIN_VALUE;
		
		int seqIndex = 0;
		for(int n = 0; n < sequences.size(); n++){
			int[] selection = sequences.get(n).getSelectedBasesPositions();
			if(selection.length > 0){
				minY = Math.min(minY, n);
				maxY = Math.max(maxY, n);
				minX = Math.min(minX, selection[0]);
				maxX = Math.max(minX, selection[selection.length - 1]);
			}
		}
		
		return new Rectangle(minX, minY, maxX - minX, maxY - minY);
		
	}
	

	public void addSelectionToExcludes() {
		for(Sequence sequence : sequences){
			int[] selection = sequence.getSelectedBasesPositions();
			if(selection != null){
				for(int n = 0; n < selection.length; n++){
					this.excludes.getPositions()[selection[n]] = true;
				}
			}
		}
		
		// always create new codon when new excludes
		//codonPositions.updateCodonPositionsToDefault123BetweenExset(this.getExcludes());
	}
	
	public void removeSelectionFromExcludes() {
		for(Sequence sequence : sequences){
			int[] selection = sequence.getSelectedBasesPositions();
			if(selection != null){
				for(int n = 0; n < selection.length; n++){
					this.excludes.getPositions()[selection[n]] = false;
				}
			}
		}		
		// always create new codon when new excludes
		//codonPositions.updateCodonPositionsToDefault123BetweenExset(this.getExcludes());
	}
	
	public void setSelectionAsCoding(int startOffset) {
		for(Sequence sequence : sequences){
			int[] selection = sequence.getSelectedBasesPositions();
			if(selection != null){
				for(int n = 0; n < selection.length; n++){
					int posVal = ((n + startOffset) % 3) + 1;
					this.codonPositions.setPosition(selection[n], posVal);
				}
			}
		}	
	}
	
	public void setSelectionAsNonCoding() {
		for(Sequence sequence : sequences){
			int[] selection = sequence.getSelectedBasesPositions();
			if(selection != null){
				for(int n = 0; n < selection.length; n++){
					int posVal = (n % 3) + 1;
					this.codonPositions.setPosition(selection[n], 0);
				}
			}
		}	
	}
	
	
	public void setExcludes(Excludes excludes) {
		this.excludes = excludes;
		// always create new codon when new excludes
		//codonPositions.updateCodonPositionsToDefault123BetweenExset(this.getExcludes());
	}
	
	
	public Excludes getExcludes(){
		return excludes;
	}


	
	
	public CodonPositions getCodonPositions() {
		return codonPositions;
	}

	

	private int countIncludedPositionsBefore(int minimumInteger) {
		int count = 0;
		for(int n = 0; n < minimumInteger; n++){
			if(this.excludes.isExcluded(n)){

			}else{
				count ++;
			}
		}
		return count;
	}

	public void complementAlignment() {	
		for(Sequence seq : sequences){
			seq.complement();
		}	
	}

	public void setCodonPositions(CodonPositions codonPositions) {
		this.codonPositions = codonPositions;
		
	}

	public boolean isEditedAfterLastSave() {
		return isEditedAfterLastSave;
	}

	public void setEditedAfterLastSave(boolean isEditedAfterLastSave) {
		this.isEditedAfterLastSave = isEditedAfterLastSave;
	}


	public boolean isAllCharactersValid() {
		return getInvalidCharacters().length() == 0;
	}


	// TODO should be different depending on alignment class nuce or protein
	public String getInvalidCharacters() {
		String testChars = "?ÅÄÖ*";
		String invalidCharsInAlignment = "";
	    for(int n = 0; n < testChars.length(); n++){
	    	char testChar = testChars.charAt(n);
	    	for(Sequence seq: getSequences()){
				if(seq.contains(testChar)){
					invalidCharsInAlignment += testChar;
					break; // breaking out of this is loop no reason to check other seq
				}
			}
		}
	    return invalidCharsInAlignment;
	}


	public void setAlignmentFormat(FileFormat fileFormat) {
		this.fileFormat = fileFormat;
		
	}


	public FileFormat getFileFormat() {
		return fileFormat;
	}


	public int getLongestSequenceName() {
		int maxlen = 0;
		for(Sequence seq: sequences){
			maxlen = Math.max(maxlen, seq.getName().length());
		}
		return maxlen;
	}


	

	
	
	/*private ArrayList<CodonPos> createCodonPositions(Excludes exset){
		
		ArrayList<CodonPos> allPos = new ArrayList<CodonPos>();
		
		boolean lastPos = true;
		CodonPos codonPos = new CodonPos(0, 0);
		
		for(int n = 0; n < exset.getPositions().length; n++){
			
			boolean thisPos = exset.isExcluded(n);
			
			if(thisPos != lastPos){
				if(thisPos == false){
					codonPos = new CodonPos(n, n);
					allPos.add(codonPos);
				}
				else{
					allPos.add(codonPos);
				}
			}else{
				if(thisPos == false){
					codonPos.incEndPos();
				}
				else{
					// yet another excluded pos in row;
				}
			}
			
			lastPos = thisPos;
			
		}
		
		return allPos;
	}

*/


	

	
	
	/*
	
	public static ArrayList<Sequence> cloneListOfSequeces(ArrayList<Sequence> list) {
		ArrayList<Sequence> clone = new ArrayList<Sequence>(list.size());
	    for(Sequence item: list){
	    	try {
				Sequence clonedSeq = item.clone();
				clone.add(clonedSeq);
			} catch (CloneNotSupportedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    return clone;
	}

*/

}
