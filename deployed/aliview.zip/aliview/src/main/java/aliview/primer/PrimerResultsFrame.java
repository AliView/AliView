package aliview.primer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

import javax.swing.BoxLayout;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import org.apache.log4j.Logger;

import aliview.AliView;
import aliview.BlastResultPanel;

import scripts.bio.blast.BlastHit;
import scripts.bio.blast.BlastPrimerEvaluation;
import javax.swing.ListSelectionModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PrimerResultsFrame extends JFrame {
	private static final Logger logger = Logger.getLogger(PrimerResultsFrame.class);
	private static final int MAX_NUMBER_OF_PRIMERS_REPORTED = 1000;
	JPanel mainPanel = new JPanel();
	private AliView aliViewProgram;
	JTable mainTable;
	PrimerDetailFrame primerDetailFrame;
	private ArrayList<Primer> primerResult;
	
	public PrimerResultsFrame(ArrayList<Primer> primRes, AliView aliView) {
		this.aliViewProgram = aliView;
		this.primerResult = primRes;
		
		//DefaultTableModel tm = new DefaultTableModel(new Object[0][1], new String[]{"PrimerData"});
		DefaultTableModel tm = new DefaultTableModel(PrimerResultTableRow.getColumnHeaders().toArray(),0);
		
		mainTable = new JTable(tm);
		mainTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		mainTable.setRowHeight(44);
		//mainTable.setDefaultRenderer(PrimerPanel.class, new PrimerPanelCellRenderer());
		mainTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			    public void valueChanged(ListSelectionEvent e) {
			        // If cell selection is enabled, both row and column change events are fired
			        if (e.getValueIsAdjusting()) {
			            // The mouse button has not yet been released
			        }
			        else{
			        	int colIndex = 0;
			  
			        	int rowIndex = mainTable.getSelectedRow();
			        	
			        	Primer selectedPrimer = primerResult.get(rowIndex); 
			        	
			        	
			        	//PrimerPanel selected = (PrimerPanel) mainTable.getModel().getValueAt(mainTable.getSelectedRow(),0);
			        	
			        	// find primer in alignment
			        	aliViewProgram.performFind(selectedPrimer.getSequence());
			        	
			        	// show detail in new frame 	
			        	String data = selectedPrimer.getPrimerDetailsAsText();
			        	
			        	if(primerDetailFrame == null){
			        		primerDetailFrame = new PrimerDetailFrame(aliViewProgram);
			        	}
			        	primerDetailFrame.setText(data);
			        	primerDetailFrame.setVisible(true);
			        	
			        }
			    }

		});	
		
		mainTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getButton() == e.BUTTON3){
					logger.info("copy Primer To clipboard");
					
					int colIndex = 0;
					if(mainTable.getSelectedColumn() == colIndex){
			        	PrimerPanel selected = (PrimerPanel) mainTable.getModel().getValueAt(mainTable.getSelectedRow(),0);   	
			        	String data = selected.getPrimer().getPrimerDetailsAsText();
			        	
			        	System.out.println(data);
					}
				}
			}
		});
		
		
//		TableColumn col = mainTable.getColumnModel().getColumn(0);
//		col.setCellRenderer(new PrimerPanelCellRenderer());
//		col.setCellEditor(new PrimerPanelCellRenderer());

		/*
		TableColumn col = mainTable.getColumnModel().getColumn(3);
		col.setCellRenderer(new ComponentCellRenderer());
		col.setCellEditor(new ComponentCellRenderer());
		*/
		
		
		Enumeration<TableColumn> enu = mainTable.getColumnModel().getColumns();
		while(enu.hasMoreElements()) {
			TableColumn col = enu.nextElement();
			col.setCellRenderer(new ComponentCellRenderer());
			col.setCellEditor(new ComponentCellRenderer());
		}
		
		/*
		TableColumn col = mainTable.getColumnModel().getColumn(2);
		col.setCellRenderer(new ComponentCellRenderer());
		col.setCellEditor(new ComponentCellRenderer());
		*/
		
		for(int n = 0; n < mainTable.getColumnModel().getColumnCount(); n++){
			 mainTable.getColumnModel().getColumn(n).setPreferredWidth(PrimerResultTableRow.getColumnSizes().get(n));
		}
		//TableColumn col = table.getColumnModel().getColumn(vColIndex);

		
		//mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		JScrollPane scrollPane = new JScrollPane(mainTable, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		//getContentPane().add(mainTable, BorderLayout.CENTER);
		
		int nCount = 0;
		for(Primer primer: primRes){
			if(primer.getScore() <= 1000 && nCount < MAX_NUMBER_OF_PRIMERS_REPORTED){
				//logger.info("AddingPanel");
				//tm.addRow(new Object[]{new PrimerPanel(primer)});
				//logger.info("AddingRow");
				tm.addRow( new PrimerResultTableRow(primer).getRow().toArray() );
				nCount ++;
				
			}
		}
		
		
		/*
		mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		
		JScrollPane scrollPane = new JScrollPane(mainPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		for(Primer primer: primerResult){
			if(primer.getScore() < 1000){
				logger.info("AddingPanel");
				mainPanel.add(new PrimerPanel(primer));
			}
		}
		*/
		
		//mainTable.set
		
		
		this.setTitle("Primer finds");
		this.setPreferredSize(new Dimension(700,400));
		this.pack();
		this.setVisible(true);
			
	}

	@Override
	public void dispose() {
		super.dispose();
		if(primerDetailFrame != null){
			primerDetailFrame.dispose();
		}
	}
	
	
	
	
}
