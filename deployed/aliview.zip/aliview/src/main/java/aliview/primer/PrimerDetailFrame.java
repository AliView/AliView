package aliview.primer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import org.apache.log4j.Logger;

import aliview.AliView;
import aliview.BlastResultPanel;

import scripts.bio.blast.BlastHit;
import scripts.bio.blast.BlastPrimerEvaluation;
import javax.swing.ListSelectionModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;

public class PrimerDetailFrame extends JFrame {
	private static final Logger logger = Logger.getLogger(PrimerDetailFrame.class);
	JPanel mainPanel = new JPanel();
	private AliView aliViewProgram;
	JTextArea mainTextArea;
	private Font textFont = new Font(Font.MONOSPACED, Font.PLAIN, 11);
	
	public PrimerDetailFrame(AliView aliView) {
		this.aliViewProgram = aliView;
		mainPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		mainPanel.setBackground(Color.WHITE);
		JScrollPane scrollPane = new JScrollPane(mainPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		mainPanel.setLayout(new BorderLayout(0, 0));
		
		mainTextArea = new JTextArea();
		mainTextArea.setText("This is demo text");
		mainTextArea.setEditable(false);
		mainTextArea.setFont(textFont);
		mainPanel.add(mainTextArea, BorderLayout.CENTER);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
			
		this.setTitle("Primer detail");
		this.setPreferredSize(new Dimension(500,400));
		this.setLocation(150, 150);
		this.pack();
		this.setVisible(true);
			
	}
	
	public void setText(String text){
		mainTextArea.setText(text);
		mainTextArea.setCaretPosition(0);
	}
}
