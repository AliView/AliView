package aliview.color;

import java.awt.Color;

import aliview.AminoAcid;

public interface ColorScheme {
	
	Color GREY_TRANSPARENT = new Color(0,0,0,97);

	public Color getBaseForegroundColor(int baseValue);
	
	public Color getBaseBackgroundColor(int baseValue);
	
	public Color getBaseSelectionForegroundColor(int baseValue);

	public Color getBaseSelectionBackgroundColor(int baseValue);
	
	public Color getAminoAcidBackgroundColor(AminoAcid acid);

	public Color getAminoAcidForgroundColor(AminoAcid acid);

	public Color getAminoAcidSelectionBackgroundColor(AminoAcid acid);

	public Color getAminoAcidSelectionForegroundColor(AminoAcid acid);
}
