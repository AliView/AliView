package scripts.bio.blast;

import java.io.*;
import java.util.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import jebl.evolution.alignments.Alignment;
import jebl.evolution.alignments.ConsensusSequence;
import jebl.evolution.io.FastaImporter;
import jebl.evolution.io.NexusImporter;
import jebl.evolution.sequences.BasicSequence;
import jebl.evolution.sequences.Sequence;
import jebl.evolution.sequences.SequenceType;
import jebl.evolution.taxa.Taxon;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FalseFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import ncbi.blast.result.generated.BlastOutput;
import ncbi.blast.result.generated.BlastOutputIterations;
import ncbi.blast.result.generated.Hit;
import ncbi.blast.result.generated.Hsp;
import ncbi.blast.result.generated.Iteration;
import ncbi.blast.result.generated.IterationHits;


public class Blaster {

	private static final Logger logger = Logger.getLogger(Blaster.class);
	private static final String LOCAL_BLAST_TRANSCRIPT_DB = "/opt/all_transcriptomes_local_blastDB";
	//private static final String LOCAL_BLAST_TRANSCRIPT_DB = "/opt/all_transcriptomes_local_blastDB";
	private static final File SEQ_OUTPUT_PARENT_DIR = new File("/opt/fernloci/blast_output_selected_more_transcripts");
	private static final String BLAST_RESULT_FILE_NAME = "blast_query_result.xml";

	public static void main(String[] args) {

		if(args != null && args.length >= 1){	
			String queryFileName = args[0];
			String questionType = args[1];
			/*
			if(questionType.equalsIgnoreCase("primer")){
				transcriptome_blast_and_align_single_query_in_this_dir(queryFileName,"blastn", 1000, 11, false);	
			}else{
				transcriptome_blast_and_align_single_query_in_this_dir(queryFileName,"blastn", 10, 7, true);
			}
			*/
		}
		else{


			//String inputFileName = "/home/anders/tmp/local_blast_results2.xml";
			//

			/*
		File queryFile = new File("/home/anders/projekt/ormbunkar/sekvenser_output/allFastaFiles/Woodsia_scopulina_ssp._scopulina_6965_RPA2_F112_a_DM4_381bp.fasta");		
		transcriptome_blast_and_align_single_query(queryFile);
			 */
			/*
		File queryDir = new File("/home/anders/projekt/ormbunkar/sekvenser_output/transcriptome_search");
		transcriptome_blast_and_align_directory(queryDir);
			 */

			//transcriptome_blast_and_align_directory(new File("/home/anders/projekt/ormbunkar/sekvenser_output/1kp_alignments_test"));

			/*
		File queryDir = new File("/home/anders/projekt/ormbunkar/sekvenser_output/1kp_manySeeds_maj_rule_consensus");		
		transcriptome_blast_and_align_directory(queryDir);
			 */


			//transcriptome_blast_and_align_directory(new File("/home/anders/projekt/ormbunkar/sekvenser_output/lowcopy_alignments_from1KP/FNA2AA_many_SeePlants"));
			//transcriptome_blast_and_align_directory(new File("/home/anders/projekt/ormbunkar/sekvenser_output/fern.transcriptome.alignments"));

			//transcriptome_blast_and_align_directory(new File("/opt/fernloci/transcript_blast_output_new_selected/"), 10, 11, true);
			//transcriptome_blast_and_align_directory(new File("/opt/fernloci/blast_input_selected"), "dc-megablast", 10, 12, true);
			//transcriptome_blast_and_align_directory(new File("/opt/fernloci/blast_input_selected"), "megablast", 10, 28, true);
			// default megablast = 28
			//transcriptome_blast_and_align_directory(new File("/opt/fernloci/blast_input_selected"),SEQ_OUTPUT_PARENT_DIR, "megablast", 10, 28, true, false, LOCAL_BLAST_TRANSCRIPT_DB, false);
			//transcriptome_blast_and_align_directory(new File("/opt/fernloci/blast_input_selected"),SEQ_OUTPUT_PARENT_DIR, "megablast", 10, 28, true, false, "/opt/Transcriptomefoles_first_round/Psilotum_nudum_QVMR/blastdb", false);
			
			transcriptome_blast_and_align_directory(new File("/opt/fernloci/blast_input_selected"),SEQ_OUTPUT_PARENT_DIR, "dc-megablast", 10, 12, true, false, "/vol2/opt/Transcriptomefiles/Woodsia_ilvensis_YQEC/blastDB", false);

			
			//transcriptome_blast_and_align_directory(new File("/opt/blast/blast_input"), new File("/opt/blast/blast_output"), "megablast", 10, 28, true, false, "nr", true);
			
			//transcriptome_blast_and_align_single_query(new File("/home/anders/projekt/ormbunkar/fernloci/primer.fasta.bak3"), 1000, 7, false);

//			primer_blast_and_evaluation(new File("/opt/fernloci/transcript_blast_output_selected/good_046616total-score_62501best-single_38hit_25unique_16extra_6560.query/primer1.fasta"),
//							new File("/opt/fernloci/transcript_blast_output_selected/good_046616total-score_62501best-single_38hit_25unique_16extra_6560.query/primer2.fasta"));
//			
//			primer_blast_and_evaluation(new File("/opt/fernloci/transcript_blast_output_selected/022487total-score_40576best-single_49hit_25unique_38extra_aligned-pgiC-ferns-mafft.fasta.aligned.fern.transcriptomes.fasta/primer1.fasta"),
//					new File("/opt/fernloci/transcript_blast_output_selected/022487total-score_40576best-single_49hit_25unique_38extra_aligned-pgiC-ferns-mafft.fasta.aligned.fern.transcriptomes.fasta/primer2.fasta"));
			
			
			
			//transcriptome_refine_directory(new File("/home/anders/tmp/transcript_blast_output.alignments/"));
		}

	}

	/*
	private static void transcriptome_refine_directory(File queryDir) {

		Collection<File> fileCollection = FileUtils.listFilesAndDirs(queryDir,DirectoryFileFilter.INSTANCE, TrueFileFilter.INSTANCE); // TrueFileFilter.INSTANCE (detta betyder recurse subdir)
		for(File currentFile: fileCollection){
			logger.info(currentFile);
		}
	}
	 */


	/*
	private static void transcriptome_blast_and_align_alignment_directory(File queryDir,double expectValue, int wordSize, boolean dustFilter) {

		Collection<File> fileCollection = FileUtils.listFiles(queryDir, new WildcardFileFilter(new String[]{"*.fa","*.fas","*.fna","*.fasta","*.query"}), FalseFileFilter.INSTANCE); // TrueFileFilter.INSTANCE (detta betyder recurse subdir)
		for(File currentFile: fileCollection){

			logger.info(currentFile);

			// read alignment
			List<Sequence> sequences = null;
			// First try nexus
			try{
				NexusImporter importer = new NexusImporter(new FileReader(currentFile));
				sequences = importer.importSequences();
			}catch (Exception nexExc) {

				// nexus didn't work - try fasta
				try{
					FastaImporter importer = new FastaImporter(new FileReader(currentFile),SequenceType.NUCLEOTIDE);
					sequences = importer.importSequences();
				}catch (Exception e) {

				}			

			}

			for(Sequence seq: sequences){

				String seqString = seq.getString();
				StringUtils.remove(seqString, '-');

				ArrayList<String> lines = new ArrayList<String>();
				lines.add(">" + seq.getTaxon());
				lines.add(seqString);

				File tempdir = new File("/home/anders/tmp");
				File queryFile = new File(tempdir, currentFile.getName());
				try {
					FileUtils.writeLines(queryFile, lines);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				transcriptome_blast_and_align_single_query(queryFile, expectValue, wordSize, dustFilter);

			}
		}
	}
	 */


/*

	private static void transcriptome_primerchecker(File primer1, File primer2) {
		
		
		
		
		File outputParentDir1 = primer1.getParentFile();
		File outDir1 = transcriptome_blast_and_align_single_query(primer1, outputParentDir1, 1000, 7, false, true);

		File outputParentDir2 = primer2.getParentFile();
		File outDir2 = transcriptome_blast_and_align_single_query(primer2, outputParentDir2, 1000, 7, false, true);

		// for all files in primer1-directory
		Collection<File> fileCollection = FileUtils.listFiles(outDir1, new WildcardFileFilter(new String[]{"*.fa","*.fas","*.fna","*.fasta","*.query"}), FalseFileFilter.INSTANCE);
		for(File currentFile: fileCollection){
			// check if file exists in parent-dit-then-it its of no interest
			File sameNameFileInParentDir = new File(outputParentDir1,currentFile.getName());
			//logger.info(sameNameFileInParentDir);
			if(! sameNameFileInParentDir.exists()){
				//logger.info("otherFile=" + currentFile);
				File sameNameFileInOtherPrimerDir = new File(outDir2,currentFile.getName());
				if(sameNameFileInOtherPrimerDir.exists()){
					logger.info("Sequence in both primer dir but not parent=" + currentFile);
				}

			}


		}

		logger.info("Finished checking primer");


	}
	
	*/
	


	

	private static void transcriptome_blast_and_align_directory(File queryDir, File seqOutputParentDir, String task, double expectValue, int wordSize, boolean filter,
			                                                     boolean skipAlign, String db, boolean remote) {

		Collection<File> fileCollection = FileUtils.listFiles(queryDir, new WildcardFileFilter(new String[]{"*.fa","*.fas","*.fna","*.fasta","*.query"}), FalseFileFilter.INSTANCE); // TrueFileFilter.INSTANCE (detta betyder recurse subdir)

		for(File currentFile: fileCollection){

			transcriptome_blast_and_align_single_query(currentFile, seqOutputParentDir, task, expectValue, wordSize, filter, skipAlign, db, remote);
			/*

			// Skip if dir already is there
			String queryName = currentFile.getName();

			String queryDirName = "_" + queryName;	
			Collection<File> sameNameFiles = FileUtils.listFilesAndDirs(new File(SEQ_OUTPUT_BASE_DIR), DirectoryFileFilter.INSTANCE, TrueFileFilter.INSTANCE); 

			boolean fileExists = false;
			for(File aFile: sameNameFiles){			
				if( aFile.getName().endsWith(queryDirName)){				
					fileExists = true;
				}			
			}
			if(! fileExists){
				transcriptome_blast_and_align_single_query(currentFile);
			}
			else{
				logger.info("Exists already: " + currentFile.getName());
			}
			 */


		}	
	}
/*
	public static void transcriptome_blast_and_align_single_query_in_this_dir(String queryFileName, double expectValue, int wordSize, boolean dustFilter){

		File queryFile = new File(queryFileName);
		File outputParentDir = queryFile.getParentFile();

		transcriptome_blast_and_align_single_query(queryFile, outputParentDir, expectValue, wordSize, dustFilter);

	}
*/

	
	public static void evaluatePrimerFromBlastResult(File blastResultFile, File thisPrimerDirectory, File otherPrimerDirectory, File designedSequenceDirectory){
		
		try {
			// Parse result
			JAXBContext jc = JAXBContext.newInstance(BlastOutput.class);
			Unmarshaller u = jc.createUnmarshaller();
			BlastOutput blastOut = (BlastOutput) u.unmarshal(blastResultFile);

			BlastOutputIterations blastOutIterations = blastOut.getBlastOutputIterations();
			List<Iteration> blastOutIteration = blastOutIterations.getIteration();

			int totalHits = 0;
			int bestIterationNumberOfHits = 0;
			double bestIterationBitScore = 0;
			double totalUniqueSequencesBitScore = 0;
			double totalBitScore = 0;
			int nIterations = 0;
			int bestIterationUniqueSpeciesNumber = 0;
			int nTotalUniqueSpecies = 0;

			// container to store unique sequences in result
			HashSet<String> uniqueSequences = new HashSet<String>();


			// For each iteration (which is one query result each) 
			for(Iteration blastIteration: blastOutIteration){

				logger.info("iteration=" + nIterations);


				// first iteration is filled with hits
				IterationHits iterationHits = blastIteration.getIterationHits();

				logger.info("iterationQueryDef=" + blastIteration.getIterationQueryDef());

				// List of hits
				List<Hit> hits = iterationHits.getHit();

				// container to store unique number of transcriptomes in result
				HashSet<String> uniqueSpecies = new HashSet<String>();

				// Loop through hits
				int numberOfHits = 0;
				double iterationBitScore = 0;
				int nTopResults = 0;
				for(Hit thisHit: hits){
//					logger.info("Num: " + thisHit.getHitNum());
//					logger.info("HitID: " + thisHit.getHitId());
//					logger.info("Def: " + thisHit.getHitDef());
//					logger.info("Len: " + thisHit.getHitLen());

					// get transcriptome species
					String hitDef = thisHit.getHitDef();
					String transcriptName = StringUtils.substringAfterLast(hitDef, "-");

					// add species in set to calculate unique specimes at the end
					uniqueSpecies.add(transcriptName);

					// Loop through hsps
					List<Hsp> hsps = thisHit.getHitHsps().getHsp();			
					String hitFrame = "";
					int thisHitTotalBitScore = 0;
					int nHsp = 0;
					for(Hsp thisHsp: hsps){

						try {
							thisHitTotalBitScore +=  Double.parseDouble(thisHsp.getHspBitScore());
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						hitFrame = thisHsp.getHspHitFrame();
						nHsp ++;
					}

					String seqName = thisHit.getHitDef() + ".fasta";			
					if(uniqueSequences.add(seqName)){
						totalUniqueSequencesBitScore += thisHitTotalBitScore;
					}
					
					// Create a new file for the sequence
					File seqFile = new File(thisPrimerDirectory,seqName);
					
					// Check if sequence is in designedSequenceDirectory
					boolean isInDesignedSequenceDirectory = false;
					if(designedSequenceDirectory != null){
						File checkFile = new File(designedSequenceDirectory,seqName);

						if(checkFile.exists()){
							isInDesignedSequenceDirectory = true;
						}
					}
					
					// Check if sequence is in otherPrimerDirectory
					boolean isInOtherPrimerDirectory = false;
					if(otherPrimerDirectory != null){
						File checkFile = new File(otherPrimerDirectory,seqName);
						if(checkFile.exists()){
							isInOtherPrimerDirectory = true;
						}
					}
					
					// Download sequence from database
					downloadSequenceFromLocalBlastDB(LOCAL_BLAST_TRANSCRIPT_DB,thisHit.getHitId(),seqFile, hitFrame);

					
					// write stats
					
					if(isInDesignedSequenceDirectory){
					//	logger.info("isInDesignedSequenceDirectory");
					}
					
					if(isInOtherPrimerDirectory && ! isInDesignedSequenceDirectory){
						System.out.println("Is not in Sequence Dir But other Primer Dir");
						
						// Write info
					//	System.out.println("Name:" + seqName);
						// Loop through hsps
						hsps = thisHit.getHitHsps().getHsp();			
						for(Hsp thisHsp: hsps){
							
							StringBuilder textResult = new StringBuilder();
							textResult.append("Hsp: " + thisHsp.getHspNum() + "\n");
							textResult.append("Identity: " + thisHsp.getHspPositive() + "/" + thisHsp.getHspAlignLen() + "\n");
							textResult.append("Query: " + thisHsp.getHspQseq() + "\n");
							textResult.append("Hit  : " + thisHsp.getHspHseq() + "\n");
							textResult.append("Diff : " + thisHsp.getHspMidline() + "\n");
							textResult.append("Hit-frame(strand): " + thisHsp.getHspHitFrame() + "\n");
							
						}
					}
					
					//only top 3
//					if(otherPrimerDirectory != null && isInOtherPrimerDirectory == false &&
//						isInDesignedSequenceDirectory == false && nTopResults < 10 ){
					if(isInDesignedSequenceDirectory == false && nTopResults < 10 ){
					
						nTopResults ++;
						System.out.println("Is not in Sequence Dir and is Top 10");
						
						// Write info
						System.out.println("Name:" + seqName);
						// Loop through hsps
						hsps = thisHit.getHitHsps().getHsp();			
						for(Hsp thisHsp: hsps){
							System.out.println("Hsp: " + thisHsp.getHspNum());
							System.out.println("Identity: " + thisHsp.getHspPositive() + "/" + thisHsp.getHspAlignLen());
							System.out.println("Query: " + thisHsp.getHspQseq());
							System.out.println("Hit  : " + thisHsp.getHspHseq());
							System.out.println("Diff : " + thisHsp.getHspMidline());
							System.out.println("Hit-frame(strand): " + thisHsp.getHspHitFrame());
						}
					}
					
				}

				bestIterationBitScore = Math.max(iterationBitScore, bestIterationBitScore);
				bestIterationNumberOfHits = Math.max(numberOfHits, bestIterationNumberOfHits);
				bestIterationUniqueSpeciesNumber = Math.max(uniqueSpecies.size(), bestIterationUniqueSpeciesNumber);

				totalBitScore += iterationBitScore;
				totalHits += numberOfHits;
				nTotalUniqueSpecies += uniqueSpecies.size();

				nIterations ++;
			}
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void primer_blast_and_evaluation(File primer1QueryFile, File primer2QueryFile){

		String task ="blastn";
		double evalue = 1000;
		int wordsize = 7;
		boolean dustfilter = false;
		String db = LOCAL_BLAST_TRANSCRIPT_DB;
		boolean remote = false;
		
		
		File outputParentDir1 = primer1QueryFile.getParentFile();
		File outputParentDir2 = primer2QueryFile.getParentFile();

		try {
			// Make subdir for this question
			String queryName1 = "blast_out_" + primer1QueryFile.getName();
			File queryDir1 = new File(primer1QueryFile.getParent(), queryName1);
			FileUtils.forceMkdir(queryDir1);

			// Save query result in output folder
			File blastResultFile1 = new File(queryDir1, BLAST_RESULT_FILE_NAME);

			// blast
			blast(primer1QueryFile, blastResultFile1, task, evalue, wordsize, dustfilter, db, remote);
			
			
			// Switch off logging
			Level savedLoggerLevel = logger.getLevel();
			logger.setLevel(Level.ERROR);
			
			// 
			evaluatePrimerFromBlastResult(blastResultFile1, queryDir1, null, primer1QueryFile.getParentFile());
			
			
			// Same for primer 2
			String queryName2 = "blast_out_" + primer2QueryFile.getName();
			File queryDir2 = new File(primer2QueryFile.getParent(), queryName2);
			FileUtils.forceMkdir(queryDir2);

			// Save query result in output folder
			File blastResultFile2 = new File(queryDir2, BLAST_RESULT_FILE_NAME);

			// blast
			blast(primer2QueryFile, blastResultFile2, task, evalue, wordsize, dustfilter, db, remote);
			
			System.out.println("");
			System.out.println("------------------------############------------------------");
			System.out.println("");
			
			
			// 
			evaluatePrimerFromBlastResult(blastResultFile2, queryDir2, queryDir1, primer2QueryFile.getParentFile());
			
			logger.setLevel(savedLoggerLevel);
	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}

	

	public static File transcriptome_blast_and_align_single_query(File queryFile, File outputParentDir, String task, double expectValue, int wordSize, boolean dustFilter, boolean skipAligning, String db, boolean remote){

		File dirNameIncludingScore = null;

		try{

			String queryName = "blast_out_" + queryFile.getName();

			// Make subdir for this question
			File queryDir = new File(outputParentDir, queryName);
			FileUtils.forceMkdir(queryDir);

			// Save copy of query-sequence in directory
			FileUtils.copyFileToDirectory(queryFile, queryDir);
			
			// Save query result in output folder
			File blastResultFile = new File(queryDir, BLAST_RESULT_FILE_NAME);
				
			// blast
			blast(queryFile, blastResultFile, task, expectValue, wordSize, dustFilter, db, remote);

			// Parse result
			JAXBContext jc = JAXBContext.newInstance(BlastOutput.class);
			Unmarshaller u = jc.createUnmarshaller();
			BlastOutput blastOut = (BlastOutput) u.unmarshal(blastResultFile);

			BlastOutputIterations blastOutIterations = blastOut.getBlastOutputIterations();
			List<Iteration> blastOutIteration = blastOutIterations.getIteration();

			int totalHits = 0;
			int bestIterationNumberOfHits = 0;
			double bestIterationBitScore = 0;
			double totalUniqueSequencesBitScore = 0;
			double totalBitScore = 0;
			int nIterations = 0;
			int bestIterationUniqueSpeciesNumber = 0;
			int nTotalUniqueSpecies = 0;

			// container to store unique sequences in result
			HashSet<String> uniqueSequences = new HashSet<String>();


			// For each iteration (which is one query result each) 
			for(Iteration blastIteration: blastOutIteration){

				logger.info("iteration=" + nIterations);


				// first iteration is filled with hits
				IterationHits iterationHits = blastIteration.getIterationHits();

				logger.info("iterationQueryDef=" + blastIteration.getIterationQueryDef());

				// List of hits
				List<Hit> hits = iterationHits.getHit();

				// container to store unique number of transcriptomes in result
				HashSet<String> uniqueSpecies = new HashSet<String>();

				// Loop through hits
				int numberOfHits = 0;
				double iterationBitScore = 0;
				for(Hit thisHit: hits){
					logger.info("Num: " + thisHit.getHitNum());
					logger.info("HitID: " + thisHit.getHitId());
					logger.info("Def: " + thisHit.getHitDef());
					logger.info("Len: " + thisHit.getHitLen());


					// get transcriptome species
					String hitDef = thisHit.getHitDef();
					String transcriptName = StringUtils.substringAfterLast(hitDef, "-");

					// add species in set to calculate unique specimes at the end
					uniqueSpecies.add(transcriptName);

					// Loop through hsps
					List<Hsp> hsps = thisHit.getHitHsps().getHsp();			
					String hitFrame = "";
					int thisHitTotalBitScore = 0;
					int nHsp = 0;
					for(Hsp thisHsp: hsps){
						logger.info("  HspNum: " + thisHsp.getHspNum());
						logger.info("  Score: " + thisHsp.getHspScore());
						logger.info("  HitFrame: " + thisHsp.getHspHitFrame());
						logger.info("  Query-from: " + thisHsp.getHspQueryFrom());
						logger.info("  Query-to: " + thisHsp.getHspQueryTo());

						try {
							thisHitTotalBitScore +=  Double.parseDouble(thisHsp.getHspBitScore());
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						hitFrame = thisHsp.getHspHitFrame();
						nHsp ++;
					}

					String seqName = thisHit.getHitDef() + ".fasta";			
					if(uniqueSequences.add(seqName)){
						totalUniqueSequencesBitScore += thisHitTotalBitScore;
					}

					// Download sequence from database
					File seqFile = new File(queryDir,seqName);
					downloadSequenceFromLocalBlastDB(db,thisHit.getHitId(),seqFile, hitFrame);

					iterationBitScore += thisHitTotalBitScore;

					numberOfHits ++;
				}

				bestIterationBitScore = Math.max(iterationBitScore, bestIterationBitScore);
				bestIterationNumberOfHits = Math.max(numberOfHits, bestIterationNumberOfHits);
				bestIterationUniqueSpeciesNumber = Math.max(uniqueSpecies.size(), bestIterationUniqueSpeciesNumber);

				totalBitScore += iterationBitScore;
				totalHits += numberOfHits;
				nTotalUniqueSpecies += uniqueSpecies.size();

				nIterations ++;
			}

			
			// Cat all sequences
			File allSequencesInOneFastaFile = new File(queryDir, "all.fa");
			catFiles(queryDir, "*fasta", allSequencesInOneFastaFile);
			
			// Mafft sequences
			File alignmentOutputFile = new File(queryDir, "aligned_all.fas");
			mafftAlign(allSequencesInOneFastaFile, alignmentOutputFile);


			// Save a copy of fern transcriptome alignment with a new name
			FileUtils.copyFile(alignmentOutputFile, new File(queryDir, queryName + ".aligned.fern.transcriptomes.query"));
			
			// modify catalog name and include scoring (initially total-score padded so catalog easily sortable)
			String scoreString = "" + (int) totalUniqueSequencesBitScore;
			scoreString = StringUtils.leftPad(scoreString, 6, '0');
			scoreString +="total-score";

			int nExtraSequencesFromMultipleIterations = uniqueSequences.size() - bestIterationNumberOfHits;

			// add more data to score filename
			scoreString += "_" + (int) bestIterationBitScore + "best-single" + "_" + bestIterationNumberOfHits + "hit" + "_" + bestIterationUniqueSpeciesNumber + "unique" + "_" + nExtraSequencesFromMultipleIterations + "extra";

			dirNameIncludingScore = new File(queryDir.getParent(), scoreString + "_" + queryDir.getName());			
			queryDir.renameTo(dirNameIncludingScore);




		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dirNameIncludingScore;
	}

	public static void blast(File queryFile, File resultFile, String task, double expectValue, int wordSize, boolean dustFilter, String db, boolean remote) throws IOException{

		String dustOption = "no";
		if(dustFilter){
			dustOption = "yes";
		}
		
		String remoteOption = "";
		String remoteValue = "";
		if(remote){
			remoteOption = "-remote";
			remoteValue = "";
		}
		
		
		//blastn -outfmt 5 -db /opt/all_transcriptomes_local_blastDB -query /home/anders/tmp/transcript_blast_output/a_short_a_allel_381bp/query.fasta -out /home/anders/tmp/blaster_search_result.xml 
		// skicka kommando och argument som array (annars problem med parsning av ex space)
		String[] commandArray = new String[]{
				"blastn",
				"-outfmt","5",
				"-task", task, // + wordSize,
				"-db",db,
			//	remoteOption,
				"-dust", dustOption,
				"-evalue", "" + expectValue,
				"-word_size", "" + wordSize,
				"-query",queryFile.getPath(),
				"-out",resultFile.getPath(),

		};

		String totalCommand = "";
		for(String token: commandArray){
			totalCommand += token + " ";
		}
		logger.info(totalCommand);

		Process p = Runtime.getRuntime().exec(commandArray);

		Scanner sc = new Scanner(p.getInputStream());
		Scanner errorSc = new Scanner(p.getErrorStream());

		// First read errors
		while (errorSc.hasNext()){
			logger.error(errorSc.nextLine());		
		}

		// read from st-output
		while (sc.hasNext()){
			logger.info(sc.nextLine());
		}

		// clean up external process
		try {
			p.waitFor();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		p.destroy();

	}
	
	public static void makeBlastDB(File fastaInput, File dataBase, String title) throws IOException{
	
		//blastn -outfmt 5 -db /opt/all_transcriptomes_local_blastDB -query /home/anders/tmp/transcript_blast_output/a_short_a_allel_381bp/query.fasta -out /home/anders/tmp/blaster_search_result.xml 
		// skicka kommando och argument som array (annars problem med parsning av ex space)
		String[] commandArray = new String[]{
				"makeblastdb",
				"-in",fastaInput.getAbsolutePath(),
				"-hash_index",
				"-dbtype","nucl", // + wordSize,
				"-title", title,
				"-out",dataBase.getAbsolutePath(),

		};

		String totalCommand = "";
		for(String token: commandArray){
			totalCommand += token + " ";
		}
		logger.info(totalCommand);

		Process p = Runtime.getRuntime().exec(commandArray);

		Scanner sc = new Scanner(p.getInputStream());
		Scanner errorSc = new Scanner(p.getErrorStream());

		// First read errors
		while (errorSc.hasNext()){
			logger.error(errorSc.nextLine());		
		}

		// read from st-output
		while (sc.hasNext()){
			logger.info(sc.nextLine());
		}

		// clean up external process
		try {
			p.waitFor();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		p.destroy();

	}
	
	
	public static void catFiles(File directory, String fileFilter, File outputFile) throws IOException{


		// Skicka kommand inuti en bash-shell för att kunna expandera * och använda pipe >
		String command = "cat " + directory.getPath() + "/" + fileFilter + " > " + outputFile.getPath();
		String[] commandArray = new String[]{
				"/bin/bash",
				"-c",command
		};

		String totalCommand = "";
		for(String token: commandArray){
			totalCommand += token + " ";
		}
		logger.info(totalCommand);

		Process p = Runtime.getRuntime().exec(commandArray);

		Scanner sc = new Scanner(p.getInputStream());
		Scanner errorSc = new Scanner(p.getErrorStream());

		// First read errors
		while (errorSc.hasNext()){
			logger.error(errorSc.nextLine());		
		}

		// read from st-output
		while (sc.hasNext()){
			logger.info(sc.nextLine());
		}
		// clean up external process
		try {
			p.waitFor();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		p.destroy();

	}
	
	private static void mafftAlign(File inputFile, File outputFile) throws IOException {
		// Skicka kommand inuti en bash-shell för att kunna expandera * och använda pipe >
		String command = "mafft --localpair --reorder --maxiterate 1000 " + inputFile.getPath() + " > " +
		outputFile.getPath();
		String[] commandArray = new String[]{
				"/bin/bash",
				"-c",command
		};

		String totalCommand = "";
		for(String token: commandArray){
			totalCommand += token + " ";
		}
		logger.info(totalCommand);

		Process p = Runtime.getRuntime().exec(commandArray);

		Scanner sc = new Scanner(p.getInputStream());
		Scanner errorSc = new Scanner(p.getErrorStream());

		// Mafft puts output in errors-pipe
		while (errorSc.hasNext()){
			logger.info(errorSc.nextLine());		
		}

		// read from st-output
		while (sc.hasNext()){
			logger.info(sc.nextLine());
		}
		// clean up external process
		try {
			p.waitFor();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		p.destroy();
		
	}

	public static void downloadSequenceFromLocalBlastDB(String localBlastDb, String accID, File seqFile, String strand) {

		logger.info("Download" + seqFile);

		try {

			String strandString = "plus";
			if("-1".equals(strand)){
				strandString = "minus";
			}

			// blastdbcmd -db /opt/all_transcriptomes_local_blastDB -entry 'gnl|BL_ORD_ID|521086' -strand plus -out /tmp/
			String[] commandArray = new String[]{
					"blastdbcmd",
					"-db",localBlastDb,
					"-entry",accID,
					"-strand",strandString,
					"-out",seqFile.getPath()
			};


			for(String token: commandArray){
//				logger.info(token);
			}

			String totalCommand = "";
			for(String token: commandArray){
				totalCommand += token + " ";
			}
//			logger.info(totalCommand);



			Process p = Runtime.getRuntime().exec(commandArray);


			Scanner sc = new Scanner(p.getInputStream());
			Scanner errorSc = new Scanner(p.getErrorStream());

			// First read errors
			while (errorSc.hasNext()){
				logger.error(errorSc.nextLine());		
			}

			while (sc.hasNext()){
				logger.info(sc.nextLine());
			}

			// clean up external process
			try {
				p.waitFor();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			p.destroy();


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


}