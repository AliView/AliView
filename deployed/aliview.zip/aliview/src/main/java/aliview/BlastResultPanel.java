package aliview;

import java.awt.Font;
import java.io.File;
import java.util.HashSet;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import ncbi.blast.result.generated.BlastOutput;
import ncbi.blast.result.generated.BlastOutputIterations;
import ncbi.blast.result.generated.Hit;
import ncbi.blast.result.generated.Hsp;
import ncbi.blast.result.generated.Iteration;
import ncbi.blast.result.generated.IterationHits;

import org.apache.commons.lang.StringUtils;

import scripts.bio.blast.BlastHit;
import scripts.bio.blast.BlastPrimerEvaluation;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BlastResultPanel extends JPanel{
	private AliView aliViewProgram;
	private BlastHit blastHit;

	public BlastResultPanel(BlastHit hit, AliView aliView) {
		this.aliViewProgram = aliView;
		this.blastHit = hit;
		
		// GUI
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
		add(textArea);

		JButton btnAddtoalignment = new JButton("AddToAlignment");
		btnAddtoalignment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliViewProgram.addSequenceWithMuscle(blastHit.getDownloadedFile());
			}
		});
		add(btnAddtoalignment);

		
		// Get data from hit
		StringBuilder textResult = new StringBuilder();
		textResult.append("HitNum: " + hit.getHit().getHitId() + "\n");
		textResult.append("HitDef: " + hit.getHit().getHitDef() + "\n");
		textResult.append("HitLen: " + hit.getHit().getHitLen() + "\n");

		// Loop through hsps
		List<Hsp> hsps = hit.getHit().getHitHsps().getHsp();
		for(Hsp thisHsp: hsps){	
			textResult.append("HspNum: " + thisHsp.getHspNum() + "\n");
			textResult.append("Score: " + thisHsp.getHspScore() + "\n");
			textResult.append("e-value: " + thisHsp.getHspEvalue() + "\n");
			textResult.append("Similairity: " + thisHsp.getHspPositive() + "/" + thisHsp.getHspAlignLen() + "\n");
			textResult.append("Query: " + thisHsp.getHspQseq() + "\n");
			textResult.append("Hit  : " + thisHsp.getHspHseq() + "\n");
			textResult.append("Diff : " + thisHsp.getHspMidline() + "\n");
			textResult.append("Hit-frame(strand): " + thisHsp.getHspHitFrame() + "\n");
		}

		textArea.setText(textResult.toString());

	}
}
