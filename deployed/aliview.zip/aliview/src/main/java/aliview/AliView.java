package aliview;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JViewport;

import java.awt.BorderLayout;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.omg.CORBA.CharHolder;
import org.simplericity.macify.eawt.Application;
import org.simplericity.macify.eawt.ApplicationEvent;
import org.simplericity.macify.eawt.ApplicationListener;
import org.simplericity.macify.eawt.DefaultApplication;

import com.sun.corba.se.spi.legacy.connection.GetEndPointInfoAgainException;

import aliview.AlignmentPane.AlignmentRuler;
import aliview.AlignmentPane.InvalidAlignmentPositionException;
import aliview.primer.Primer;
import aliview.primer.PrimerResultsFrame;
import aliview.sequencelist.SequenceList;
import aliview.sequencelist.SequenceListListener;
import aliview.sequencelist.SequenceListModel;
import aliview.sequences.Sequence;
import aliview.settings.Settings;
import aliview.settings.SettingsPanel;
import aliview.utils.Aligner;
import aliview.utils.DialogUtils;
import aliview.utils.FileDrop;
import aliview.utils.OSNativeUtils;

import scripts.bio.blast.BlastPrimerEvaluation;
import utils.ReorderListener;
import utils.Utilities;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.Stack;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JToggleButton;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.Box;
import javax.swing.JTextArea;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;

public class AliView implements ApplicationListener{

	private static Preferences prefs = Preferences.userNodeForPackage(AliView.class);
	private static final Rectangle DEFAULT_WIN_GEOMETRY = new Rectangle(20,20,600,400);
	private static final Logger logger = Logger.getLogger(AliView.class);
	private JFrame frame;
	protected JViewport viewport;
	protected AlignmentPane alignmentPane;
	JScrollPane alignmentScrollPane;
	private static AliView aliView;
	private static File alignmentFile;
	private SequenceList alignmentList;
	private Alignment alignment;
	private JTextField minSelectionLength;
	private final JTextField searchField = new JTextField();
	private JLabel lblSelectionInfo;
	private JTextField primer1txtField;
	private JTextField primer2txtField;
	private PrimerResultsFrame primerResultsFrame;
	private Application macApplication;
	private int nextNameFindSequenceNumber;

	private LimitedStack<String> undo_fastaBuffers = new LimitedStack<String>(100);
	private LimitedStack<String> redo_fastaBuffers = new LimitedStack<String>(100);
	private LimitedStack<Excludes> redo_exsetBuffers = new LimitedStack<Excludes>(100);
	private LimitedStack<Excludes> undo_exsetBuffers = new LimitedStack<Excludes>(100);
	private LimitedStack<CodonPositions> redo_codonposBuffers = new LimitedStack<CodonPositions>(100);
	private LimitedStack<CodonPositions> undo_codonposBuffers = new LimitedStack<CodonPositions>(100);
	private boolean hasUnsavedUndoableEdits;
	private Component glassPane;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args){	

		/*
		String username = System.getenv("USERNAME");
		if(username != null && username.equals("anders")){
			Logger.getRootLogger().setLevel(Level.ERROR);
		}
		 */

		
		try{
			if(args != null){
				logger.info("args.length=" + args.length);
				for(String arg: args){	
					logger.info("arg=" + arg);
				}
			}
			else{
				logger.info("args(null)=" + args);
			}

			RepeatingKeyEventsFixer rf = new RepeatingKeyEventsFixer();

			rf.install();

			if(OSNativeUtils.isMac()){

				// First set properties, doesn't matter what OS they are not used by other than intended
				// This might actually be to late for setting mac-application menu
				System.setProperty("apple.laf.useScreenMenuBar", "true");
				// Mac application menu
				System.setProperty("com.apple.mrj.application.apple.menu.about.name", "AliView");

				logger.info("apple.awt.antialiasing" + System.getProperty("apple.awt.antialiasing"));
				logger.info("apple.awt.graphics.UseQuartz" + System.getProperty("apple.awt.graphics.UseQuartz"));
				logger.info("apple.awt.graphics.EnableQ2DX" + System.getProperty("apple.awt.graphics.EnableQ2DX"));
				logger.info("apple.awt.rendering" + System.getProperty("apple.awt.rendering"));


				// ToDo turn off anti-aliasing on Mac
				System.setProperty("apple.awt.antialiasing","off");
				System.setProperty("apple.awt.rendering", "VALUE_RENDER_SPEED");		
				System.setProperty("apple.awt.graphics.UseQuartz", "false");
				//System.setProperty("apple.awt.graphics.EnableQ2DX", "true");

				logger.info("apple.awt.antialiasing" + System.getProperty("apple.awt.antialiasing"));
				logger.info("apple.awt.graphics.UseQuartz" + System.getProperty("apple.awt.graphics.UseQuartz"));
				logger.info("apple.awt.graphics.EnableQ2DX" + System.getProperty("apple.awt.graphics.EnableQ2DX"));
				logger.info("apple.awt.rendering" + System.getProperty("apple.awt.rendering"));

				//System.setProperty("apple.awt.graphics.EnableQ2DX", "false");
				//
			}




			if(OSNativeUtils.isLinuxOrUnix()){
				try {
					for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
						if ("Nimbus".equals(info.getName())) {
							UIManager.setLookAndFeel(info.getClassName());
							break;
						}
					}

				} catch (UnsupportedLookAndFeelException e) {
					// handle exception
				} catch (ClassNotFoundException e) {
					// handle exception
				} catch (InstantiationException e) {
					// handle exception
				} catch (IllegalAccessException e) {
					// handle exception
				}
			}
			else{

				try {
					try {
						UIManager.setLookAndFeel(
								UIManager.getSystemLookAndFeelClassName());
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InstantiationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (UnsupportedLookAndFeelException ex) {
					System.out.println("Unable to load native look and feel");
				}
			}


			//alignmentFile = new File("/home/anders/projekt/ormbunkar/analys/sekv_analysis/aligned-WoodsiatrnGR-mafft.fasta.nexus");
			alignmentFile = new File("/home/anders/projekt/ormbunkar/analys/test_seqconcat/test_seqconcat.nexus");
			//alignmentFile = new File("/home/anders/projekt/ormbunkar/fernloci/alignments_work/refined/6928/6928_all_w_arabid.27.fasta");
			//alignmentFile = new File("/home/anders/projekt/ormbunkar/analys/test_protein_alignment.fasta");
			//alignmentFile = new File("/home/anders/projekt/ormbunkar/analys/phylip.example.phy");
			//alignmentFile = new File("/home/anders/projekt/ormbunkar/analys/pgiC_20121215/pgiC_20121215.phylip");
			//alignmentFile = new File("/home/anders/tmp/Purple_ITScut2.nexus");
			//alignmentFile = new File("/home/anders/projekt/ormbunkar/fernloci/carls_example/locus_alignments_transcriptome/4321_transcriptome_alignments_etc/4321_v2.2_allin.nex");
			//alignmentFile = new File("/opt/Silva_108/core_aligned/Silva_108_core_aligned_seqs.fasta");

			if(args != null && args.length >= 1){	
				alignmentFile = new File(args[0]);
			}

			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						aliView = new AliView();
						aliView.frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}catch(Error err){
						err.printStackTrace();
					}
				}
			});

		}catch(Exception ex){
			ex.printStackTrace();
		}catch(Error err){
			err.printStackTrace();
		}

	}

	/**
	 * Create the application.
	 */
	public AliView() {
		initialize();
	}

	private void initialize() {


		/*
		 * 
		 * Mac stuff
		 * 
		 */
		if(OSNativeUtils.isMac()){
			macApplication = new DefaultApplication();
			macApplication.addApplicationListener(this);
			macApplication.addPreferencesMenuItem();
			macApplication.setEnabledPreferencesMenu(true);
		}


		logger.info("before Frame");

		frame = new JFrame();
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				saveWindowGeometry();
			}
		});


		logger.info("after Frame");
		// Init dialog utilities with this frame
		DialogUtils.init(frame);



		Action doNothing = new AbstractAction() {
			public void actionPerformed(ActionEvent e) {
				logger.info("doing nothing");
			}
		};					/*

		// From datasheet get extraction
		String specimenName = labDB.getSpecimenNameFromPCRID(pcrID);
		if(specimenName == null){
			logger.error("no specimenf found for this macrogen result");
		}
		else{
			logger.info("specimenName" + specimenName);
		}

		String primerName = labDB.getRegionNameFromPCRID(pcrID);

		String extractionID = labDB.getExtractionIDFromPCRID(pcrID);

		String externalID = labDB.selectFromWhere("external_id", "extraction", extractionID);


		 */

		logger.info("before Root");
		frame.getRootPane().getInputMap().put(KeyStroke.getKeyStroke("F2"),
				"doNothing");
		frame.getRootPane().getActionMap().put("doNothing", doNothing);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(AliView.class.getResource("/img/alignment_ico_128x128.png")));
		//frame.setBounds(100, 100, 1400, 800);
		restoreWindowGeometry();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		logger.info("here");

		// TODO edit after last save
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {

				if(aliView.hasUnsavedEdits()){        	
					// optionpane
					String message = "There might be unsaved edits - save before close?";

					int retVal = JOptionPane.showConfirmDialog(DialogUtils.getDialogParent(), message, "Save edits?", JOptionPane.YES_NO_CANCEL_OPTION);

					if(retVal == JOptionPane.YES_OPTION){			
						aliView.saveAlignmentAsFileViaChooser();		
					}
					if(retVal == JOptionPane.NO_OPTION){			
						frame.dispose();
					}
					if(retVal == JOptionPane.CANCEL_OPTION){			
						return;
					}

				}
				else{
					frame.dispose();
				}


			}



		});



		JPanel statusPanel = new JPanel();
		FlowLayout flowLayout = (FlowLayout) statusPanel.getLayout();
		flowLayout.setAlignment(FlowLayout.RIGHT);
		frame.getContentPane().add(statusPanel, BorderLayout.SOUTH);

		logger.info("here");

		lblSelectionInfo = new JLabel("");
		statusPanel.add(lblSelectionInfo);

		JLabel lblAlignmentStatistics = new JLabel("xx sequences, xx bases long");
		statusPanel.add(lblAlignmentStatistics);

		alignmentPane = new AlignmentPane(lblAlignmentStatistics);

		logger.info("here");

		AlignmentMouseListener ml = new AlignmentMouseListener();
		alignmentPane.addMouseListener(ml);
		alignmentPane.addMouseMotionListener(ml);
		alignmentPane.addMouseWheelListener(ml); 

		AlignmentRulerListener rl = new AlignmentRulerListener();
		alignmentPane.getRulerComponent().addMouseListener(rl);
		alignmentPane.getRulerComponent().addMouseMotionListener(rl);

		logger.info("before create alignment");

		if(alignmentFile != null && alignmentFile.exists()){
			alignment = AlignmentFactory.createNewAlignment(alignmentFile);
		}else{
			logger.info("nofile");
			alignment = new Alignment();
		}

		logger.info("created alignment");

		// File drop
		new  FileDrop( frame.getRootPane(), new FileDrop.Listener()
		{   public void  filesDropped( java.io.File[] files )
		{   

			for(File droppedFile: files){
				aliView.loadNewAlignmentFile(droppedFile);
				// jut open one file for now
				break;
			}
		}   // end filesDropped
		}); // end FileDrop.Listener


		alignmentPane.setAlignment(alignment);

		logger.info("before GUI");

		this.updateWindowTitle();

		// if you only want partial clip when scroll in pane then put alignmentPane in panel before put in jscrollpane

		/*
		JPanel extraPanel = new JPanel();
		extraPanel.add(alignmentPane);
		 */

		// Always horizontal scrollbar so list and pane not have varied height - then list and alignment could get out of synch	
		alignmentScrollPane = new JScrollPane(alignmentPane, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

		alignmentScrollPane.setAutoscrolls(true);
		alignmentScrollPane.setMinimumSize(new Dimension(150, 150));
		alignmentScrollPane.setDoubleBuffered(true);
		alignmentScrollPane.getVerticalScrollBar().setUnitIncrement(16);
		alignmentScrollPane.getHorizontalScrollBar().setUnitIncrement(160);
		//alignmentScrollPane.setDropTarget(alignmentPane);
		alignmentPane.setDoubleBuffered(true);
		alignmentScrollPane.setBorder(null);
		viewport = alignmentScrollPane.getViewport();
		viewport.setAutoscrolls(true);



		/*
        List<Sequence> sequences = alignmentPane.getAlignmnent().getSequences();
        DefaultListModel model = new DefaultListModel();
		 */

		SequenceListModel seqListModel = alignment.createSequenceListModel();
		alignmentList = new SequenceList(seqListModel);
		SequenceListListener aliListener = new SequenceListListener(alignmentList, alignmentPane);
		alignmentList.addListSelectionListener(aliListener);
		seqListModel.addListDataListener(aliListener);

		/*
		MouseAdapter listReorderListener = new ReorderListener(alignmentList);
		alignmentList.addMouseListener(listReorderListener);
		alignmentList.addMouseMotionListener(listReorderListener);
		 */

		// Always horizontal scrollbar so list and pane not have varied height - then list and alignment could get out of synch
		JScrollPane listScrollPane = new JScrollPane(alignmentList, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		listScrollPane.setMinimumSize(new Dimension(200, 50));
		listScrollPane.setPreferredSize(new Dimension(300,600));
		listScrollPane.setDoubleBuffered(true);
		listScrollPane.setBorder(null);

		// Synchronize vertical scroll between two panes
		listScrollPane.getVerticalScrollBar().setModel(alignmentScrollPane.getVerticalScrollBar().getModel());


		// TODO implement this with the ruler as a panel

		AlignmentRuler alignmentRuler = alignmentPane.getRulerComponent();
		alignmentRuler.setPreferredSize(new Dimension(1000,20));
		
		JPanel alignmentAndRuler = new JPanel(new BorderLayout());
		
		alignmentAndRuler.add(alignmentScrollPane, BorderLayout.CENTER);
		alignmentAndRuler.add(alignmentRuler, BorderLayout.NORTH);

		JPanel listTopOffset = new JPanel();
		listTopOffset.setBackground(Color.white);
		listTopOffset.setPreferredSize(new Dimension(100, 20));
		JPanel listAndTopOffset = new JPanel(new BorderLayout());
		listAndTopOffset.add(listScrollPane, BorderLayout.CENTER);
		listAndTopOffset.add(listTopOffset, BorderLayout.NORTH);


		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, listAndTopOffset, alignmentAndRuler);
		splitPane.setDividerSize(6);



		//JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, listScrollPane, alignmentScrollPane);

		logger.info("middle of GUI");


		frame.getContentPane().add(splitPane, BorderLayout.CENTER);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);    

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenuItem mntmOpenFile = new JMenuItem("Open File");
		mntmOpenFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openNewAlignmentFileViaChooser();
			}

		});
		mntmOpenFile.setAccelerator(OSNativeUtils.getOpenFileAccelerator());
		mnFile.add(mntmOpenFile);

		JMenuItem mntmSaveFile = new JMenuItem("Save");
		mntmSaveFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveAlignmentFile();
			}
		});
		mntmSaveFile.setAccelerator(OSNativeUtils.getSaveFileAccelerator());
		mnFile.add(mntmSaveFile);

		JMenuItem mntmSaveAlignmentAs = new JMenuItem("Save alignment as Fasta");
		mntmSaveAlignmentAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveAlignmentAsFileViaChooser(FileFormat.FASTA);
			}
		});
		mnFile.add(mntmSaveAlignmentAs);


		JMenuItem mntmSaveAlignmentAsNexus = new JMenuItem("Save alignment as Nexus");
		mntmSaveAlignmentAsNexus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveAlignmentAsFileViaChooser(FileFormat.NEXUS);
			}

		});
		mnFile.add(mntmSaveAlignmentAsNexus);
		
		JMenuItem mntmSaveAlignmentAsSimpleNexus = new JMenuItem("Save alignment as Nexus (Simplified Names - MrBayes)");
		mntmSaveAlignmentAsSimpleNexus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveAlignmentAsFileViaChooser(FileFormat.NEXUS_SIMPLE);
			}
		});
		mnFile.add(mntmSaveAlignmentAsSimpleNexus);

		JMenuItem mntmSaveAlignmentAsNexusCodon = new JMenuItem("Save alignment as codonpos Nexus (codonpos as charsets - excluded removed)");
		mntmSaveAlignmentAsNexusCodon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveAlignmentAsFileViaChooser(FileFormat.NEXUS_CODONPOS_CHARSET);
			}

		});
		mnFile.add(mntmSaveAlignmentAsNexusCodon);

		JMenuItem mntmSaveAlignmentAsPhylip = new JMenuItem("Save alignment as Phylip");
		mntmSaveAlignmentAsPhylip.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveAlignmentAsFileViaChooser(FileFormat.PHYLIP);
			}

		});
		mnFile.add(mntmSaveAlignmentAsPhylip);

		JMenuItem mntmExportAlignmentAsImage = new JMenuItem("Export alignment as image");
		mntmExportAlignmentAsImage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exportAlignmentAsImage();
			}
		});
		mnFile.add(mntmExportAlignmentAsImage);


		JMenuItem mntmReloadFile = new JMenuItem("Reload file");
		mntmReloadFile.setAccelerator(OSNativeUtils.getReloadKeyAccelerator());
		mntmReloadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				reloadCurrentFile();
			}
		});
		mnFile.add(mntmReloadFile);


		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Save selection as Fasta");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveSelectionAsFastaFileViaChooser();
			}


		});
		mnFile.add(mntmNewMenuItem_2);

		JMenuItem mntmLogFile = new JMenuItem("Show message log");
		mntmLogFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showMessageLog();
			}


		});
		mnFile.add(mntmLogFile);

		JMenuItem mntmDebug = new JMenuItem("Start debug");
		mntmDebug.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Logger.getRootLogger().setLevel(Level.ALL);
			}
		});
		mnFile.add(mntmDebug);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Properties versionProp = new Properties(); 
				InputStream in = AliView.class.getResourceAsStream("/connections.properties");
				try {
					versionProp.load(in);
					String value = (String)versionProp.get("version");
					logger.info("version=" + value);				
				} catch (Exception exc) {
					logger.error("error loading version config");
					exc.printStackTrace();
					return;
				}
				
				
			}

		});
		//mnFile.add(mntmAbout);


		JMenu mnEdit = new JMenu("Edit");
		menuBar.add(mnEdit);

		JMenuItem mntmUndoItem = new JMenuItem("Undo");
		mntmUndoItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				undo();

			}
		});
		mntmUndoItem.setAccelerator(OSNativeUtils.getUndoKeyAccelerator());
		mnEdit.add(mntmUndoItem);

		JMenuItem mntmRedoItem = new JMenuItem("Redo");
		mntmRedoItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				redo();
				/*
				// Todo this should be moved to class above alignment/alignmentpane & sequencelist
				alignment.redo();
				SequenceListModel sm = (SequenceListModel)alignmentList.getModel();
				sm.setSequences(alignment.getSequences());

				alignmentPane.validateSequenceOrder();
				alignmentPane.updateSize();
				alignmentList.validate();
				alignmentPane.repaint();
				alignmentList.repaint();
				 */

			}
		});
		mntmRedoItem.setAccelerator(OSNativeUtils.getRedoKeyAccelerator());
		mnEdit.add(mntmRedoItem);



		JMenuItem mntmClearSelectedItem = new JMenuItem("Clear selected bases");
		mntmClearSelectedItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				aliView.pushUndoState();

				alignment.clearSelectedBases();

				logger.info(alignment.getConsensus());

				alignmentPane.repaint();

			}
		});
		mntmClearSelectedItem.setAccelerator(OSNativeUtils.getClearKeyAccelerator());
		mnEdit.add(mntmClearSelectedItem);

		JMenuItem mntmDeleteSelectedItem = new JMenuItem("Delete selected");
		mntmDeleteSelectedItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {


				aliView.pushUndoState();

				alignmentList.deleteSelectedSequences();
				alignment.deleteSelectedBases();

				logger.info(alignment.getConsensus());

				// todo remove this ugly synch of list and pane so they communicate themselves
				SequenceListModel lm = (SequenceListModel) alignmentList.getModel();
				ArrayList<Sequence> sequences = new ArrayList<Sequence>();
				for(Sequence seq: lm){
					sequences.add(seq);
				}


				//alignmentList.revalidate();
				alignmentPane.validateSequenceOrder();
				alignmentPane.repaint();
				alignmentList.repaint();

			}
		});
		mntmDeleteSelectedItem.setAccelerator(OSNativeUtils.getDeleteKeyAccelerator());
		mnEdit.add(mntmDeleteSelectedItem);
		
		JMenuItem mntmDeleteExcluded = new JMenuItem("Delete excluded bases");
		mntmDeleteExcluded.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				aliView.pushUndoState();
				alignment.deleteAllExsetBases();
				// Currently recalc codon-pos after deletion
				//alignment.getCodonPositions().updateCodonPositionsToDefault123BetweenExset(alignment.getExcludes());
				alignmentPane.updateStatisticsLabel();
				alignmentPane.repaint();

			}
		});
		//mntmDeleteExcluded.setAccelerator(OSNativeUtils.getDeleteKeyAccelerator());
		mnEdit.add(mntmDeleteExcluded);


		JMenuItem mntmCopySelectionAsFasta = new JMenuItem("Copy selection as fasta");
		mntmCopySelectionAsFasta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logger.info("copy");
				int minLen = Integer.parseInt(minSelectionLength.getText());
				alignment.copySelectionToClipboardAsFasta(minLen);
			}
		});
		mntmCopySelectionAsFasta.setAccelerator(OSNativeUtils.getCopySelectionAsFastaKeyAccelerator());
		mnEdit.add(mntmCopySelectionAsFasta);

		JMenuItem mntmCopySelectionAsNucleotides = new JMenuItem("Copy selection as nucleotides");
		mntmCopySelectionAsNucleotides.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logger.info("copy");
				int minLen = Integer.parseInt(minSelectionLength.getText());
				alignment.copySelectionToClipboardAsNucleotides();
			}
		});
		mntmCopySelectionAsNucleotides.setAccelerator(OSNativeUtils.getCopyKeyAccelerator());
		mnEdit.add(mntmCopySelectionAsNucleotides);

		JMenuItem mntmPasteClipboard = new JMenuItem("Paste (fasta-sequences)");
		mntmPasteClipboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String clipboardSelection = getClipboard();

				aliView.pushUndoState();
				alignment.addFasta(clipboardSelection);
				// ToDO change this list update (is done at other places to)
				SequenceListModel sm = (SequenceListModel)alignmentList.getModel();
				sm.setSequences(alignment.getSequences());
				alignmentPane.validateSequenceOrder();
				alignmentPane.updateSize();
				alignmentPane.revalidate();
				alignmentList.revalidate();
				alignmentPane.repaint();
				alignmentList.repaint();


			}
		});
		mntmPasteClipboard.setAccelerator(OSNativeUtils.getPasteKeyAccelerator());
		mnEdit.add(mntmPasteClipboard);


		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Merge 2 selected sequences");
		mntmNewMenuItem_1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.CTRL_MASK | InputEvent.SHIFT_MASK));
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object[] selected = alignmentList.getSelectedValues();
				if(selected != null && selected.length == 2){
					aliView.pushUndoState();
					boolean isMerged = alignment.mergeSelected(selected, true);
					if(isMerged){

						alignmentList.deleteSequence(selected[1]);	
						// todo remove this ugly synch of list and pane so they communicate themselves
						SequenceListModel lm = (SequenceListModel) alignmentList.getModel();
						ArrayList<Sequence> sequences = new ArrayList<Sequence>();
						for(Sequence seq: lm){
							sequences.add(seq);
						}
					}

				}
				alignmentPane.validateSequenceOrder();
				alignmentPane.repaint();
			}
		});
		mnEdit.add(mntmNewMenuItem_1);

		JMenuItem mntmRemoveVerticalGaps = new JMenuItem("Remove vertical gaps");
		mntmRemoveVerticalGaps.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();	
				alignment.removeVerticalGaps();	
				// Currently recalc codon-pos after deletion
				//alignment.getCodonPositions().updateCodonPositionsToDefault123BetweenExset(alignment.getExcludes());
				alignmentPane.updateStatisticsLabel();
				alignmentPane.repaint();
				logger.info("alignment.getMaximumSequenceLength()" + alignment.getMaximumSequenceLength());

			}
		});
		//mntmRemoveVerticalGaps.setAccelerator(KeyStroke.getKeyStroke(??));
		mnEdit.add(mntmRemoveVerticalGaps);

		JMenuItem mntmFind = new JMenuItem("Find");
		mntmFind.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		mntmFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				searchField.requestFocus();
				searchField.selectAll();
			}
		});
		mnEdit.add(mntmFind);
		
		JMenuItem mntmFindClipboardNames = new JMenuItem("Find sequence names from clipboard");
		mntmFindClipboardNames.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		mntmFindClipboardNames.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				findNamesFromClipboard();
			}
		});
		mnEdit.add(mntmFindClipboardNames);
		
		

		JMenuItem mntmRevComp = new JMenuItem("Reverse Complement Clipboard");
		//mntmFind.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK));
		mntmRevComp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				logger.info("action perf");
				reverseComplementClipboard();

			}
		});
		mnEdit.add(mntmRevComp);

		JMenuItem mntmRevCompSequences = new JMenuItem("Reverse Complement Selected Sequences");
		//mntmFind.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK));
		mntmRevCompSequences.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				logger.info("action perf mntmRevCompSequences");
				// ToDO maybe move this method from alignmentlist
				alignmentList.reverseComplementSelectedSequences();
				alignmentPane.repaint();
			}

		});
		mnEdit.add(mntmRevCompSequences);
		
		JMenuItem mntmRevCompAlignment = new JMenuItem("Reverse Complement Alignmnet");
		//mntmFind.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK));
		mntmRevCompAlignment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				logger.info("action perf");
				alignment.reverseComplementAlignment();
				alignmentPane.validateSequenceOrder();
				alignmentPane.repaint();
			}

		});
		mnEdit.add(mntmRevCompAlignment);

		JMenuItem mntmCompAlignment = new JMenuItem("Complement Alignmnet");
		//mntmFind.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK));
		mntmCompAlignment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				logger.info("action perf");
				alignment.complementAlignment();
				alignmentPane.validateSequenceOrder();
				alignmentPane.repaint();
			}

		});
		mnEdit.add(mntmCompAlignment);

		JMenu mnSelection = new JMenu("Selection");
		menuBar.add(mnSelection);

		JMenuItem mntmClearSelection = new JMenuItem("Clear selection");
		mntmClearSelection.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignmentPane.clearSelection();
				alignmentList.clearSelection();
			}
		});
		mnSelection.add(mntmClearSelection);

		JMenuItem mntmMoveSelectionRight = new JMenuItem("Move selection right");
		mntmMoveSelectionRight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.moveSelectionRight();

				// This is to update only selection
				Rectangle selectRect = alignment.getSelectionAsMinRect();
				Point paneXY = alignmentPane.matrixCoordToPaneCoord(new Point(selectRect.x, selectRect.y));
				Rectangle selectInPaneCoord = new Rectangle(   paneXY.x, paneXY.y,
						(int) (selectRect.width * alignmentPane.charWidth),
						(int) (selectRect.height * alignmentPane.charHeight + alignmentPane.charHeight));

				selectInPaneCoord.grow(2,0);
				alignmentPane.paintImmediately(selectInPaneCoord);
				alignmentPane.paintImmediately(alignmentPane.getVisibleRect());
			}
		});
		mntmMoveSelectionRight.setAccelerator(OSNativeUtils.getMoveSelectedRightKeyAccelerator());
		mnSelection.add(mntmMoveSelectionRight);

		JMenuItem mntmMoveSelectionLeft = new JMenuItem("Move selection left");
		mntmMoveSelectionLeft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				long startTime = System.nanoTime();
				alignment.getSelectedBases();
				long endTime = System.nanoTime();
				long timeSpent = endTime - startTime;
				double timeSpentMS = (double)timeSpent / 1000000000.0;
				logger.info("Get selection took " + (timeSpentMS) + " millisec");
				aliView.pushUndoState();
				alignment.moveSelectionLeft();

				// This is to update only selection
				Rectangle selectRect = alignment.getSelectionAsMinRect();
				Point paneXY = alignmentPane.matrixCoordToPaneCoord(new Point(selectRect.x, selectRect.y));
				Rectangle selectInPaneCoord = new Rectangle(   paneXY.x, paneXY.y,
						(int) (selectRect.width * alignmentPane.charWidth),
						(int) (selectRect.height * alignmentPane.charHeight + alignmentPane.charHeight));

				selectInPaneCoord.grow(2,0);
				alignmentPane.paintImmediately(selectInPaneCoord);
				alignmentPane.paintImmediately(alignmentPane.getVisibleRect());
			}
		});
		mntmMoveSelectionLeft.setAccelerator(OSNativeUtils.getMoveSelectedLeftKeyAccelerator());
		mnSelection.add(mntmMoveSelectionLeft);

		JMenuItem mntmInsertGapMoveRight = new JMenuItem("Insert Gap move right");
		mntmInsertGapMoveRight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.insertGapLeftOfSelectionMoveRight();
				logger.info("ask repaint");
				//alignmentPane.repaint();
				alignmentPane.paintImmediately(alignmentPane.getVisibleRect());
			}
		});
		mntmInsertGapMoveRight.setAccelerator(OSNativeUtils.getInsertGapMoveRightKeyAccelerator());
		mnSelection.add(mntmInsertGapMoveRight);

		JMenuItem mntmInsertGapMoveLeft = new JMenuItem("Insert Gap move left");
		mntmInsertGapMoveLeft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.insertGapRightOfSelectionMoveLeft();
				//alignmentPane.repaint();
				alignmentPane.paintImmediately(alignmentPane.getVisibleRect());

			}
		});
		mntmInsertGapMoveLeft.setAccelerator(OSNativeUtils.getInsertGapMoveLeftKeyAccelerator());
		mnSelection.add(mntmInsertGapMoveLeft);




		JMenuItem mntmMoveSelectionUp = new JMenuItem("Move selection up");
		mntmMoveSelectionUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignmentList.moveSelectionUp();
				alignmentPane.updateSize();
			}
		});
		mntmMoveSelectionUp.setAccelerator(OSNativeUtils.getMoveSelectionUpKeyAccelerator());
		mnSelection.add(mntmMoveSelectionUp);

		JMenuItem mntmMoveSelectionDown = new JMenuItem("Move selection down");
		mntmMoveSelectionDown.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignmentList.moveSelectionDown();
				alignmentPane.updateSize();
			}
		});
		mntmMoveSelectionDown.setAccelerator(OSNativeUtils.getMoveSelectionDownKeyAccelerator());
		mnSelection.add(mntmMoveSelectionDown);


		JMenuItem mntmMoveSelectionToTop = new JMenuItem("Move selection to top");
		mntmMoveSelectionToTop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignmentList.moveSelectionToTop();
				alignmentPane.updateSize();
			}
		});
		mntmMoveSelectionToTop.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_UP, InputEvent.ALT_MASK));
		mnSelection.add(mntmMoveSelectionToTop);

		JMenuItem mntmMoveSelectionToBottom = new JMenuItem("Move selection to bottom");
		mntmMoveSelectionToBottom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignmentList.moveSelectionToBottom();
				alignmentPane.updateSize();
			}
		});
		mntmMoveSelectionToBottom.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, InputEvent.ALT_MASK));
		mnSelection.add(mntmMoveSelectionToBottom);

		JMenuItem mntmAddExcludes = new JMenuItem("Add selection to Excludes/Exset");
		mntmAddExcludes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.addSelectionToExcludes();
				alignmentPane.repaint();
			}
		});
		mntmAddExcludes.setAccelerator(OSNativeUtils.getAddExcludesKeyAccelerator());
		mnSelection.add(mntmAddExcludes);

		JMenuItem mntmRemoveExcludes = new JMenuItem("Remove selection from Excludes/Exset");
		mntmRemoveExcludes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.removeSelectionFromExcludes();
				alignmentPane.repaint();
			}
		});
		//mntmRemoveExcludes.setAccelerator(OSNativeUtils.getAddExcludesKeyAccelerator());
		mnSelection.add(mntmRemoveExcludes);
		
		JMenuItem mntmSetSelectionAsCoding0 = new JMenuItem("Set selection as coding");
		mntmSetSelectionAsCoding0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.setSelectionAsCoding(0);
				alignmentPane.repaint();
			}
		});
		mnSelection.add(mntmSetSelectionAsCoding0);
		
		JMenuItem mntmSetSelectionAsCoding1 = new JMenuItem("Set selection as coding (start pos 2)");
		mntmSetSelectionAsCoding1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.setSelectionAsCoding(1);
				alignmentPane.repaint();
			}
		});
		mnSelection.add(mntmSetSelectionAsCoding1);
		
		JMenuItem mntmSetSelectionAsCoding2 = new JMenuItem("Set selection as coding (start pos 3)");
		mntmSetSelectionAsCoding2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.setSelectionAsCoding(2);
				alignmentPane.repaint();
			}
		});
		mnSelection.add(mntmSetSelectionAsCoding2);
		
		JMenuItem mntmSetSelectionAsNonCoding = new JMenuItem("Set selection as Non-coding");
		mntmSetSelectionAsNonCoding.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.setSelectionAsNonCoding();
				alignmentPane.repaint();
			}
		});

		mnSelection.add(mntmSetSelectionAsNonCoding);


		JMenu mnViewMenu = new JMenu("View");
		menuBar.add(mnViewMenu);

		JMenuItem mntmDecreaseFontSize = new JMenuItem("Decrease Font Size");
		mntmDecreaseFontSize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				decCharSize();
			}
		});
		mntmDecreaseFontSize.setAccelerator(OSNativeUtils.getDecreaseFontSizeKeyAccelerator());
		mnViewMenu.add(mntmDecreaseFontSize);

		JMenuItem mntmIncreaseFontSize = new JMenuItem("Increase Font Size");
		mntmIncreaseFontSize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				incCharSize();
			}
		});
		mntmIncreaseFontSize.setAccelerator(OSNativeUtils.getIncreaseFontSizeKeyAccelerator());
		mnViewMenu.add(mntmIncreaseFontSize);

		JMenuItem mntmSortSequencesBy = new JMenuItem("Sort sequences by name");
		mntmSortSequencesBy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				alignment.sortSequencesByName();
				alignmentPane.validateSequenceOrder();
				alignmentList.repaint();
			}
		});
		mnViewMenu.add(mntmSortSequencesBy);

		boolean togglePartialName = Settings.getToggleShortNameOnly();
		if(togglePartialName){
			alignment.togglePartialNameOnly();
		}
		JCheckBoxMenuItem mntmPartialName = new JCheckBoxMenuItem("Toggle partial name only", togglePartialName);
		mntmPartialName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alignment.togglePartialNameOnly();
				Settings.putToggleShortNameOnly(alignment.getTogglePartialNameOnly());
				alignmentPane.validateSequenceOrder();
				alignmentList.repaint();
			}
		});
		mnViewMenu.add(mntmPartialName);



		JMenuItem mntmToggleTranslation = new JMenuItem("Toggle translation");
		mntmToggleTranslation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alignmentPane.toggleTranslation();
				alignmentPane.repaint();
			}
		});
		mntmToggleTranslation.setAccelerator(OSNativeUtils.getToggleTranslationKeyAccelerator());
		mnViewMenu.add(mntmToggleTranslation);

		JMenuItem mntmToggleAminoAcidCode = new JMenuItem("Toggle draw Amino acid code");
		mntmToggleAminoAcidCode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alignmentPane.setDrawAminoAcidCode(! alignmentPane.getDrawAminoAcidCode());
				alignmentPane.repaint();
			}
		});
		mnViewMenu.add(mntmToggleAminoAcidCode);

		JMenuItem mntmIncreaseReadingFrame = new JMenuItem("Reading frame +1");
		mntmIncreaseReadingFrame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				alignmentPane.incReadingFrame();
				alignmentPane.repaint();
			}
		});
		mntmIncreaseReadingFrame.setAccelerator(OSNativeUtils.incReadingFrameKeyAccelerator());
		mnViewMenu.add(mntmIncreaseReadingFrame);

		JMenuItem mntmDecreaseReadingFrame = new JMenuItem("Reading frame -1");
		mntmDecreaseReadingFrame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alignmentPane.decReadingFrame();
				alignmentPane.repaint();
			}
		});
		mntmDecreaseReadingFrame.setAccelerator(OSNativeUtils.decReadingFrameKeyAccelerator());
		mnViewMenu.add(mntmDecreaseReadingFrame);
		
		JMenuItem mntmToggleDrawCodonPos = new JMenuItem("Toggle draw codonpos");
		mntmToggleDrawCodonPos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alignmentPane.setDrawCodonPosRuler(! alignmentPane.getDrawCodonPosRuler());
				alignmentPane.repaint();
			}
		});
		//mntmToggleDrawCodonPos.setAccelerator(OSNativeUtils....);
		mnViewMenu.add(mntmToggleDrawCodonPos);
		

		JMenu mnAlign = new JMenu("Align");
		menuBar.add(mnAlign);

		JMenuItem mntmAlignInCurrent = new JMenuItem("Add and align sequences from clipboard");
		mntmAlignInCurrent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					String clipboardSelection = getClipboard();

					logger.info(clipboardSelection);

					// Firstly see if there is a file in clipboard
					File clipboardSequenceFile = new File(clipboardSelection);

					// if clipboard not was file
					if(! clipboardSequenceFile.exists()){

						// if clipboard not is is fasta try to create fasta out of it
						if(! clipboardSelection.startsWith(">")){
							clipboardSelection = ">clipboard_sequence" + "\n" + clipboardSelection;				
						}
						// save clipboard to file
						clipboardSequenceFile = File.createTempFile( "clipboard_selection", ".fasta");
						FileUtils.writeStringToFile(clipboardSequenceFile, clipboardSelection);			

					}
					final File newSequenceFile = clipboardSequenceFile;

					Thread thread = new Thread(new Runnable(){
						public void run(){
							aliView.addSequenceWithMuscle(newSequenceFile);
							// aligning is done the new thread should activate GUI again before it is finished
							glassPane.setVisible(false);
						}
					});
					// Lock GUI while second thread is working
					glassPane.setVisible(true);
					thread.start();

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}




			}
		});
		mnAlign.add(mntmAlignInCurrent);
		
		/*
		 * 
		 * TODO This has to be looked over so it works with thread
		 * 
		 */
		
		JMenuItem mntmAlignInMultiple = new JMenuItem("Add and align multiple sequences from clipboard one by one");
		mntmAlignInMultiple.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

					String clipData = getClipboard();
					
					String revComp = "";
					
					// check if fasta 
					if(clipData != null && clipData.startsWith(">")){
						MemoryArrayMatrix matrix = new MemoryArrayMatrix(new StringReader(clipData));
						
						final ArrayList<Sequence> sequences = matrix.getSequences();				

						Thread thread = new Thread(new Runnable(){
							public void run(){
									
								try {
									for(Sequence seq: sequences){

											// ToDO create some better general export sequence as fasta-method
											String oneSeqAsFasta = ">" + seq.getName() + "\n" + seq.getBasesAsString();
											// save clipboard to file
											File clipboardSequenceFile = File.createTempFile( "clipboard_selection", ".fasta");
											FileUtils.writeStringToFile(clipboardSequenceFile, oneSeqAsFasta);			
											File newSequenceFile = clipboardSequenceFile;
											aliView.addSequenceWithMuscle(newSequenceFile);
									}
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								
								// all aligning is done the new thread should activate GUI again before it is finished
								glassPane.setVisible(false);
								
								}
							});
						// Lock GUI while second thread is working
						glassPane.setVisible(true);
						thread.start();
															
					}
					// no fasta try to make sequence out of it
					else{
						// clipData = ">clipboard_sequence" + "\n" + clipboardSelection;	
					}

			}
		});
		mnAlign.add(mntmAlignInMultiple);
		
		

		JMenuItem mntmReAlignSelection = new JMenuItem("Realign selection with muscle");
		mntmReAlignSelection.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Thread thread = new Thread(new Runnable(){
					public void run(){
						aliView.reAlignSelectionWithMuscle();
						// aligning is done the new thread should activate GUI again before it is finished
						glassPane.setVisible(false);
					}
				});
				// Lock GUI while second thread is working
				glassPane.setVisible(true);
				thread.start();

			}

		});
		mnAlign.add(mntmReAlignSelection);
		
		
		
		JMenuItem mntmAlign = new JMenuItem("Realign everything with muscle");
		mntmAlign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// optionpane
				String message = "Are you sure you want to" + "\n" + "realign the whole alignment?";
				int retVal = JOptionPane.showConfirmDialog(DialogUtils.getDialogParent(), message, "Realign the whole alignment?", JOptionPane.OK_CANCEL_OPTION);
				if(retVal == JOptionPane.OK_OPTION){			
					Thread thread = new Thread(new Runnable(){
						public void run(){
							aliView.alignWithMuscle();
							// aligning is done the new thread should activate GUI again before it is finished
							glassPane.setVisible(false);
						}
					});
					// Lock GUI while second thread is working
					glassPane.setVisible(true);
					thread.start();
				}			
			}
		});
		mnAlign.add(mntmAlign);

		/*

		JMenuItem mntmReAlignSelectionMafft = new JMenuItem("Realign selection with mafft");
		mntmReAlignSelectionMafft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aliView.pushUndoState();
				aliView.reAlignSelectionWithMafft();
			}
		});
		mnAlign.add(mntmReAlignSelectionMafft);

		 */

		JMenu mnPrimer = new JMenu("Primer");
		menuBar.add(mnPrimer);

		JMenuItem mntmPrimerInCurrent = new JMenuItem("Find primer in current selection");
		mntmPrimerInCurrent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ArrayList<Primer> primerResult = alignment.findPrimerInSelection();
				// kill old frame
				if(primerResultsFrame != null){
					primerResultsFrame.dispose();
				}
				primerResultsFrame = new PrimerResultsFrame(primerResult, aliView);
				primerResultsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


			}
		});
		mnPrimer.add(mntmPrimerInCurrent);

		JMenuItem mntmFindPrimerSettings = new JMenuItem("Find primer settings");
		mntmFindPrimerSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame settingsFrame = new JFrame("Settings");
				settingsFrame.getContentPane().add(new SettingsPanel(settingsFrame));
				settingsFrame.pack();
				settingsFrame.setVisible(true);
			}
		});
		mnPrimer.add(mntmFindPrimerSettings);



		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(false);

		frame.getContentPane().add(toolBar, BorderLayout.NORTH);

		JToggleButton toggleButton = new JToggleButton("show only diff");
		//toggleButton.setAccelerator(OSNativeUtils.incReadingFrameKeyAccelerator());
		toggleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				JToggleButton btn = (JToggleButton) evt.getSource();
				if (btn.isSelected()) {
					alignmentPane.setOnlyDrawDiff(true);
				}
				else{
					alignmentPane.setOnlyDrawDiff(false);
				}
			}
		});
		toolBar.add(toggleButton);


		JToggleButton tglbtnView = new JToggleButton("View");
		tglbtnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alignmentPane.setInteractionMode(AlignmentPane.INTERACTION_MODE_VIEW);
			}
		});
		//toolBar.add(tglbtnView);

		JToggleButton tglbtnSelect = new JToggleButton("Select");
		tglbtnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alignmentPane.setInteractionMode(AlignmentPane.INTERACTION_MODE_SELECT);
			}
		});
		//toolBar.add(tglbtnSelect);

		ButtonGroup buttonGroupAliMode = new ButtonGroup();
		buttonGroupAliMode.add(tglbtnSelect);
		buttonGroupAliMode.add(tglbtnView);

		/*
		JButton btnBlastresults = new JButton("BlastPrimers");
		btnBlastresults.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					String primer1 = ">Primer1" + "\r\n" + primer1txtField.getText();
					String primer2 = ">Primer2" + "\r\n" + primer2txtField.getText();

					File currentAlignmentDir = alignment.getAlignmentFile().getParentFile();

					File primer1File = new File(currentAlignmentDir, "primer1_aliview.fasta");
					FileUtils.writeStringToFile(primer1File, primer1);
					File primer2File = new File(currentAlignmentDir, "primer2_aliview.fasta");
					FileUtils.writeStringToFile(primer2File, primer2);

					BlastResultsFrame blastResultsFrame = new BlastResultsFrame(aliView);
					BlastPrimerEvaluation primerEvaluation = new BlastPrimerEvaluation();
					primerEvaluation.primer_blast_and_evaluation(primer1File,primer2File);

					blastResultsFrame.createBlastPrimerResult(primerEvaluation);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				//evaluation.primer_blast_and_evaluation(new File("/opt/fernloci/transcript_blast_output_selected/022487total-score_40576best-single_49hit_25unique_38extra_aligned-pgiC-ferns-mafft.fasta.aligned.fern.transcriptomes.fasta/primer1.fasta"),
				//								new File("/opt/fernloci/transcript_blast_output_selected/022487total-score_40576best-single_49hit_25unique_38extra_aligned-pgiC-ferns-mafft.fasta.aligned.fern.transcriptomes.fasta/primer2.fasta"));



			}
		});
		toolBar.add(btnBlastresults);
		 */

		minSelectionLength = new JTextField();
		minSelectionLength.setText("0");
		//toolBar.add(minSelectionLength);
		minSelectionLength.setColumns(10);

		toolBar.add(searchField);
		searchField.setText("Search");
		searchField.setColumns(10);
		searchField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				performFind();
			}
		});

		/*
		JLabel lblNewLabel = new JLabel("Primer1");
		toolBar.add(lblNewLabel);

		primer1txtField = new JTextField();
		toolBar.add(primer1txtField);
		primer1txtField.setColumns(30);

		JLabel lblPrimer = new JLabel("Primer2");
		toolBar.add(lblPrimer);

		primer2txtField = new JTextField();
		primer2txtField.setColumns(30);
		toolBar.add(primer2txtField);
		 */

		Component horizontalGlue = Box.createHorizontalGlue();
		toolBar.add(horizontalGlue);

		// Set default mode and button pressed
		tglbtnSelect.doClick();
		//tglbtnView.doClick();


		//		for(Sequence seq: alignment.sequences){
		//			logger.info(seq);
		//		}
		//		logger.info(alignment.getMaximumSequenceLength());




		// prepare glassPane
		glassPane = frame.getGlassPane();
		glassPane.addMouseListener(new GlassPaneMouseListener());
		glassPane.addKeyListener(new GlassPaneKeyListener());


		logger.info("initialize finished");

	}


	protected void findNamesFromClipboard() {
		
		// get clipboard
		String clipboard = getClipboard();
		
		if(clipboard != null){
			String[] lines = clipboard.split("\\n");
			List<Integer> allFoundIndices = new ArrayList<Integer>();
			
			for(String line: lines){
				allFoundIndices.addAll(alignment.findInNames(line, 0, true));		
			}


			int[] indexArray = new int[allFoundIndices.size()];
			for(int n = 0; n < allFoundIndices.size(); n++){
				indexArray[n] = allFoundIndices.get(n).intValue();
			}
		
			alignmentPane.clearSelection();
			alignmentList.clearSelection();
			
			if(indexArray.length > 0){
				alignmentList.setSelectedIndices(indexArray);
				alignmentList.ensureIndexIsVisible(indexArray[0]);
			}
			
		}

		
	}

	protected boolean hasUnsavedEdits() {
		return hasUnsavedUndoableEdits;
	}

	// ToDO shoulc skip reverse complement fasta name if in clipboard
	public void reverseComplementClipboard(){
			
			String clipData = AliView.getClipboard();
			
			String revComp = "";
			
			// check if fasta 
			if(clipData != null && clipData.startsWith(">")){
				MemoryArrayMatrix matrix = new MemoryArrayMatrix(new StringReader(clipData));
				
				// TODO change everywhere to fixed new-line
				for(Sequence seq: matrix.getSequences()){
					seq.reverseComplement();
					revComp += ">" + seq.getName() + "\n";
					revComp += seq.getBasesAsString() + "\n";
				}
				
			}
			// no fasta just revcomp brutally
			else{
				revComp = aliview.NucleotideUtilities.reverse(clipData);
				revComp = aliview.NucleotideUtilities.complement(revComp);
			}
			
			// set clipboard
			StringSelection ss = new StringSelection(revComp);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
			
		}
	
	protected void saveAlignmentFile() {

		// skip chooser
		saveAlignmentAsFile();
	}

	private void pushUndoState(){
		long startTime = System.currentTimeMillis();

		StringWriter fastaWriter = new StringWriter();
		try {
			alignment.storeAlignmetAsFasta(new BufferedWriter(fastaWriter));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String fastaBuffer = fastaWriter.toString();
		undo_fastaBuffers.push(fastaBuffer);

		try {
			undo_exsetBuffers.push(alignment.getExcludes().clone());
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			undo_codonposBuffers.push(alignment.getCodonPositions().clone());
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TODO this should maybe be handled better than indirect as here
		hasUnsavedUndoableEdits = true;
		this.updateWindowTitle();

		long endTime = System.currentTimeMillis();
		logger.info("Push undo took " + (endTime - startTime) + " milliseconds");
	}

	protected void pushRedoState(){	
		StringWriter fastaWriter = new StringWriter();
		try {
			alignment.storeAlignmetAsFasta(new BufferedWriter(fastaWriter));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String fastaBuffer = fastaWriter.toString();
		redo_fastaBuffers.push(fastaBuffer);
		try {
			redo_exsetBuffers.push(alignment.getExcludes().clone());
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			redo_codonposBuffers.push(alignment.getCodonPositions().clone());
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TODO this should maybe be handled better than indirect as here
		hasUnsavedUndoableEdits = true;
		this.updateWindowTitle();
	}


	public void undo() {

		if(! undo_fastaBuffers.isEmpty()){

			// first store order so we can redo
			pushRedoState();

			logger.info("undoSize" + undo_fastaBuffers.size());

			alignment.reloadMatrixFromFasta(new StringReader(undo_fastaBuffers.pop()));
			SequenceListModel sm = (SequenceListModel)alignmentList.getModel();
			sm.setSequences(alignment.getSequences());
			alignment.setExcludes(undo_exsetBuffers.pop());
			alignment.setCodonPositions(undo_codonposBuffers.pop());
			alignmentPane.validateSequenceOrder();
			alignmentPane.updateSize();
			alignmentList.validate();
			alignmentPane.repaint();
			alignmentList.repaint();

			if(undo_fastaBuffers.size() == 0){
				hasUnsavedUndoableEdits = false;
				updateWindowTitle();
			}
		}
	}


	public void redo() {
		if(! redo_fastaBuffers.isEmpty()){
			// first store order so we can undo
			pushUndoState();

			alignment.reloadMatrixFromFasta(new StringReader(redo_fastaBuffers.pop()));
			SequenceListModel sm = (SequenceListModel)alignmentList.getModel();
			sm.setSequences(alignment.getSequences());
			alignment.setExcludes(redo_exsetBuffers.pop());
			alignment.setCodonPositions(redo_codonposBuffers.pop());
			alignmentPane.validateSequenceOrder();
			alignmentPane.updateSize();
			alignmentList.validate();
			alignmentPane.repaint();
			alignmentList.repaint();
		}

	}


	public void exportAlignmentAsImage(){

		String suggestedDir = Settings.getSaveAlignmentDirectory();
		File suggestedFile = new File(suggestedDir, "alignment.png");
		Component parent = frame.getParent();

		File selectedFile = AliUtilities.selectSaveFileViaChooser(suggestedFile,parent);
		logger.info("selectedFile=" + selectedFile);
		// Assure ".png" on file
		selectedFile = Utilities.assureFileSuffix(selectedFile, ".png");

		if(selectedFile != null){
			try {
				writeToFile(selectedFile, "png");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


	public void writeToFile(File outFile, String fileFormat) 
			throws IOException {	
		// Create the directory path if necessary
		//File file = new File(fileName);

		//file.mkdirs();



		// Write to file
		ImageIO.write(getBufferedAlignmentImage(), fileFormat, outFile);

	}

	/**
	 * Todo I could use formula sqr (2b/3h) för at få reda på i hur många delar den skall delas för att hamna på ett a4  förhållande 2/3 
	 * @return
	 */
	private synchronized BufferedImage getBufferedAlignmentImage() {

		// Create a buffered image
		BufferedImage image = new BufferedImage(alignmentPane.getWidth(), alignmentPane.getHeight(),
				BufferedImage.TYPE_INT_RGB);

		Graphics2D g2 = (Graphics2D) image.getGraphics();

		// First draw a background
		g2.setColor(Color.WHITE);
		g2.fillRect(0, 0, alignmentPane.getWidth(), alignmentPane.getHeight());

		//Then draw tree
		alignmentPane.paint(g2);

		return image;
	}

	protected JTextArea openCommandOutputWindow() {
		JTextArea messageArea = new JTextArea();
		try {
			flushAllLogs();
			File logFile = new File( System.getProperty("java.io.tmpdir"),"AliView.log");
			String message = FileUtils.readFileToString(logFile);
			messageArea.setText(logFile.getAbsolutePath() + "\n" + message);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JScrollPane scrollPane = new JScrollPane(messageArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JFrame messagesFrame = new JFrame("Log");
		messagesFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		messagesFrame.setPreferredSize(new Dimension(400,400));
		messagesFrame.pack();
		messagesFrame.setVisible(true);

		return messageArea;
	}

	protected void showMessageLog() {
		JTextArea messageArea = new JTextArea();
		try {
			flushAllLogs();
			File logFile = new File( System.getProperty("java.io.tmpdir"),"AliView.log");
			String message = FileUtils.readFileToString(logFile);
			messageArea.setText(logFile.getAbsolutePath() + "\n" + message);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JScrollPane scrollPane = new JScrollPane(messageArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JFrame messagesFrame = new JFrame("Log");
		messagesFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		messagesFrame.setPreferredSize(new Dimension(400,400));
		messagesFrame.pack();
		messagesFrame.setVisible(true);
	}

	public void updateWindowTitle() {
		String fileName = alignment.getFileName();
		if(fileName == null){
			frame.setTitle("AliView");
		}else{

			// Add a symbol if unsaved
			if(hasUnsavedUndoableEdits){
				frame.setTitle("AliView - " + "*" + fileName);
			}
			else{
				frame.setTitle("AliView - " + fileName);
			}
		}
	}

	public void performFind(String searchText) {
		searchField.setText(searchText);
		alignment.clearFindLastPos();
		performFind();
	}

	public void performFind() {
		alignmentPane.clearSelection();
		alignmentList.clearSelection();

		// First try in names
		List<Integer> foundSeqIndex = alignment.findInNames(searchField.getText(),nextNameFindSequenceNumber,false);

		if(foundSeqIndex.size() > 0){
			alignmentList.clearSelection();
			alignmentList.setSelectedIndex(foundSeqIndex.get(0).intValue());
			alignmentList.ensureIndexIsVisible(foundSeqIndex.get(0).intValue());
			nextNameFindSequenceNumber = foundSeqIndex.get(0).intValue() + 1;
		}else{
			nextNameFindSequenceNumber = 0;
			Point findPosition = alignment.findInSequences(searchField.getText());
			logger.info("findPosition" + findPosition);
			if(findPosition != null){
				Point paneCoord = alignmentPane.matrixCoordToPaneCoord(findPosition);
				logger.info("paneCoord" + paneCoord);
				if(! alignmentPane.getVisibleRect().contains(paneCoord)){
					logger.info("not visible");
					Rectangle newVisible = new Rectangle(paneCoord);
					//logger.info("new visible" + newVisible);
					newVisible.grow(alignmentPane.getVisibleRect().width/2,alignmentPane.getVisibleRect().height/2);
					//logger.info("newVisible" + newVisible);
					alignmentPane.scrollRectToVisible(newVisible);
				}

			}
		}
		alignmentPane.revalidate();

	}

	public static final String getClipboard() {
		Transferable t = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);

		try {
			if (t != null && t.isDataFlavorSupported(DataFlavor.stringFlavor)) {
				String text = (String)t.getTransferData(DataFlavor.stringFlavor);
				return text;
			}
		} catch (UnsupportedFlavorException e) {
		} catch (IOException e) {
		}
		return null;
	}




	/*
	 * These methods should be moved out to parent container
	 */

	public void zoomInAt(Point mousePos){

		// TODO Problem is that a scrollpane need to be resized before setViewPosiiton()
		// and all should be done at once before repaint!!!

		//		Base atBase = alignmentPane.getClosestBaseAt(mousePos);
		//		incCharSize();
		//		alignmentPane.scrollBaseTo(atBase,mousePos)


		// Get alignmentPane size before resize since it will change afeter resize
		// we need to now relative size different between new and old size because
		// we want to zoom in on same position (same nucleotide) where mouse was in
		// old pane
		Dimension oldSize = alignmentPane.getPreferredSize();
		Point viewPoint = alignmentScrollPane.getViewport().getViewPosition();
		Point mousePosInScrollPaneCoord = new Point(mousePos.x - viewPoint.x, mousePos.y - viewPoint.y);

		logger.info("oldSize" + oldSize);

		incCharSize();

		Dimension newSize = alignmentPane.getPreferredSize();
		logger.info("newSize" + newSize);

		// Now when alignmentPanel coordinates have changed due to resize, lets focus on the 
		// relative position where mouse pointer were earlier (same nucleotide)		
		double paneRelSizeX = newSize.getWidth()/oldSize.getWidth();
		double paneRelSizeY = newSize.getHeight()/oldSize.getHeight();

		int mousePosXOnResizedPane = (int) (mousePos.getX() * paneRelSizeX);
		int mousePosYOnResizedPane = (int) (mousePos.getY() * paneRelSizeY);

		Point mousePosOnResizedPane = new Point(mousePosXOnResizedPane, mousePosYOnResizedPane);

		// calculate new view location	
		int newX = mousePosOnResizedPane.x - mousePosInScrollPaneCoord.x;
		int newY = mousePosOnResizedPane.y - mousePosInScrollPaneCoord.y;

		logger.info("newX" + newX);
		logger.info("newY" + newY);

		Point newViewPoint = new Point(newX, newY);

		// move viewport so base moves to mouse pointer (absolute position on)
		viewPoint = alignmentScrollPane.getViewport().getViewPosition();
		logger.info("beforeViewPoint" + viewPoint);
		logger.info("newViewPoint" + newViewPoint);
		
		// Validate vas the key to getting zoom in right!!!
		alignmentScrollPane.getViewport().validate();
		alignmentScrollPane.getViewport().setViewPosition(newViewPoint);
		alignmentScrollPane.getViewport().validate();
		
		viewPoint = alignmentScrollPane.getViewport().getViewPosition();
		logger.info("afterViewPoint" + viewPoint);

	}

	public void zoomOutAt(Point mousePos){

		// Get alignmentPane size before resize since it will change afeter resize
		// we need to now relative size different between new and old size because
		// we want to zoom in on same position (same nucleotide) where mouse was in
		// old pane
		Dimension oldSize = alignmentPane.getPreferredSize();
		Point viewPoint = alignmentScrollPane.getViewport().getViewPosition();
		Point mousePosInScrollPaneCoord = new Point(mousePos.x - viewPoint.x, mousePos.y - viewPoint.y);

		Point mouseInMatrixCoord = alignmentPane.paneCoordToMatrixCoord(mousePosInScrollPaneCoord);


		logger.info("oldSize" + oldSize);

		decCharSize();

		/*
		upperLeftMatrixCoord = alignmentPane.paneCoordToMatrixCoord(mousePosInScrollPaneCoord);

		// scrollMatrixPosToPaneCoord
		alignmentScrollPane.getViewport().setViewPosition(p)

		alignmentScrollPane.getViewport().
		 */

		Dimension newSize = alignmentPane.getPreferredSize();
		logger.info("newSize" + newSize);

		// Now when alignmentPanel coordinates have changed due to resize, lets focus on the 
		// relative position where mouse pointer were earlier (same nucleotide)		
		double paneRelSizeX = newSize.getWidth()/oldSize.getWidth();
		double paneRelSizeY = newSize.getHeight()/oldSize.getHeight();

		int mousePosXOnResizedPane = (int) (mousePos.getX() * paneRelSizeX);
		int mousePosYOnResizedPane = (int) (mousePos.getY() * paneRelSizeY);

		Point mousePosOnResizedPane = new Point(mousePosXOnResizedPane, mousePosYOnResizedPane);

		// calculate new vew location	
		int newX = mousePosOnResizedPane.x - mousePosInScrollPaneCoord.x;
		int newY = mousePosOnResizedPane.y - mousePosInScrollPaneCoord.y;
		Point newViewPoint = new Point(newX, newY);

		// move viewport so base moves to mouse pointer (absolute position on)
		alignmentScrollPane.getViewport().setViewPosition(newViewPoint);
		alignmentPane.revalidate();
		alignmentPane.repaint();

		//viewPoint = alignmentScrollPane.getViewport().getViewPosition();

	}


	/*
	 * End t hese methods should be moved out to parent container
	 */


	/**
	 * Initialize the contents of the frame.
	 */
	public void saveAlignmentAsFileViaChooser(){
		saveAlignmentAsFileViaChooser(alignment.getFileFormat());
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void saveAlignmentAsFileViaChooser(FileFormat fileFormat){

		// Get dir for saving
		String suggestedDir = alignment.getAlignmentFile().getParent();

		// and filename
		String suggestedFileName = alignment.getFileName();

		// if file format not is same as alignment strip surrent suffix and add new one
		if(fileFormat != alignment.getFileFormat()){		
			suggestedFileName = FileFormat.stripFileSuffixFromName(suggestedFileName);
			suggestedFileName += "." + fileFormat.getSuffix();	
		}

		// make sure there is a file name
		if(suggestedFileName == null || suggestedFileName.length() < 1){
			suggestedFileName = "alignment" + "." + fileFormat.getSuffix();
		}

		File suggestedFile = new File(suggestedDir, suggestedFileName);
		Component parent = frame.getParent();

		File selectedFile = AliUtilities.selectSaveFileViaChooser(suggestedFile,parent);

		// här borde det vara alignment getAlignmentAsFastaStream

		if(selectedFile != null){

			// Ask user if file exists
			if(selectedFile.exists()){
				String message = "File already exists - do you want to overwrite?";
				int retVal = JOptionPane.showConfirmDialog(DialogUtils.getDialogParent(), message, "Overwrite?", JOptionPane.OK_CANCEL_OPTION);
				if(retVal != JOptionPane.OK_OPTION){									
					return;
				}
			}
			try {

				alignment.saveAlignmentAsFile(selectedFile, fileFormat);
				alignment.setAlignmentFile(selectedFile);
				alignment.setAlignmentFormat(fileFormat);
				aliView.updateWindowTitle();
				Settings.putSaveAlignmentDirectory(selectedFile.getParent());
				hasUnsavedUndoableEdits = false;
				this.updateWindowTitle();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void saveAlignmentAsFile(){

		// Get dir for saving
		String suggestedDir = alignment.getAlignmentFile().getParent();

		// and filename
		String suggestedFileName = alignment.getFileName();

		// make sure there is a file name
		if(suggestedFileName == null || suggestedFileName.length() < 1){
			String message = "Not possible to save, try Save as....";
			JOptionPane.showMessageDialog(DialogUtils.getDialogParent(), message, "Sorry....", JOptionPane.INFORMATION_MESSAGE);
			return;
		}

		File suggestedFile = new File(suggestedDir, suggestedFileName);

		try {

			alignment.saveAlignmentAsFile(suggestedFile, alignment.getFileFormat());
			// many of this below should not be necessary 
			alignment.setAlignmentFile(suggestedFile);
			alignment.setAlignmentFormat(alignment.getFileFormat());
			aliView.updateWindowTitle();
			Settings.putSaveAlignmentDirectory(suggestedFile.getParent());
			hasUnsavedUndoableEdits = false;
			this.updateWindowTitle();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	protected void saveSelectionAsFastaFileViaChooser() {
		String suggestedDir = alignment.getAlignmentFile().getParent();

		String suggestedFileName = alignment.getAlignmentFile().getName();
		suggestedFileName = FileFormat.stripFileSuffixFromName(suggestedFileName);
		suggestedFileName += ".selection." + FileFormat.FASTA.getSuffix();

		File suggestedFile = new File(suggestedDir,  suggestedFileName);
		Component parentComponent = frame.getParent();

		File selectedFile = AliUtilities.selectSaveFileViaChooser(suggestedFile,parentComponent);

		if(selectedFile != null){
			int minLen = Integer.parseInt(minSelectionLength.getText());
			alignment.saveSelectionAsFastaFile(selectedFile, minLen);
			Settings.putSaveSelectionDirectory(selectedFile.getParent());
		}

	}


	private void openNewAlignmentFileViaChooser() {

		// As default get last used stored directory
		String suggestedDir = Settings.getLoadAlignmentDirectory();

		// if file is loaded already choose this dir instead
		if(alignment.getAlignmentFile() != null){
			suggestedDir = alignment.getAlignmentFile().getParent();
		}

		File suggestedFile = new File(suggestedDir);
		Component parent = frame.getParent();

		File selectedFile = AliUtilities.selectOpenFileViaChooser(suggestedFile,parent);

		if(selectedFile != null){	
			loadNewAlignmentFile(selectedFile);
			Settings.putLoadAlignmentDirectory(selectedFile.getParent());
			hasUnsavedUndoableEdits = false;
			this.updateWindowTitle();
		}
	}

	private void reloadCurrentFile() {
		File currentFile = alignment.getAlignmentFile();
		loadNewAlignmentFile(currentFile);
		hasUnsavedUndoableEdits = false;
		this.updateWindowTitle();

	}


	private void loadNewAlignmentFile(File selectedFile){
		alignment = AlignmentFactory.createNewAlignment(selectedFile);
		setupNewAlignment(alignment);
		alignmentList.repaint();
		alignmentPane.repaint();
		hasUnsavedUndoableEdits = false;
		this.updateWindowTitle();
	}
	
	/*
	private Alignment cloneCurrentAlignmentBySaveAndLoad(){
		StringWriter fastaWriter = new StringWriter();
		Alignment clone = null;
		try {
			alignment.storeAlignmetAsNexus(new BufferedWriter(fastaWriter));
			Alignment clone = AlignmentFactory.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/

	private void setupNewAlignment(Alignment alignment){
		// create new alignment Pane??
		alignmentPane.setAlignment(alignment);
		SequenceListModel model = alignment.createSequenceListModel();
		// Create new list
		//alignmentList = new AlignmentList(model)

		alignmentList.setModel(model);

		// todo maybe a bit hacky to reuse AlignmentList and alignment pane??
		ListSelectionListener[] listeners = alignmentList.getListSelectionListeners();
		for(ListSelectionListener listener: listeners){
			alignmentList.removeListSelectionListener(listener);
		}

		// new data listener for the listmodel
		SequenceListListener aliListener = new SequenceListListener(alignmentList, alignmentPane);
		model.addListDataListener(aliListener);
		alignmentList.addListSelectionListener(aliListener);

		alignmentPane.updateSize();

		aliView.updateWindowTitle();

	}

	protected void incCharSize() {
		alignmentPane.incCharSize();
		alignmentList.setCharSize(alignmentPane.getCharHeight());

	}

	protected void decCharSize() {
		alignmentPane.decCharSize();
		alignmentList.setCharSize(alignmentPane.getCharHeight());

	}

	private void restoreWindowGeometry(){
		// Restore window geometry
		Rectangle bounds = new Rectangle();
		bounds.x = prefs.getInt("window.x",DEFAULT_WIN_GEOMETRY.x);
		bounds.y = prefs.getInt("window.y",DEFAULT_WIN_GEOMETRY.y);
		bounds.width = prefs.getInt("window.width",DEFAULT_WIN_GEOMETRY.width);
		bounds.height = prefs.getInt("window.height",DEFAULT_WIN_GEOMETRY.height);
		frame.setBounds(bounds); // Do not use pack()!	
	}

	private void saveWindowGeometry(){
		// Restore window geometry
		Rectangle bounds = frame.getBounds();
		prefs.putInt("window.x",bounds.x);
		prefs.putInt("window.y",bounds.y);
		prefs.putInt("window.width",bounds.width);
		prefs.putInt("window.height",bounds.height);
		try {
			prefs.flush();
		} catch (BackingStoreException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected synchronized void addSequenceWithMuscle(File downloadedSequenceFile) {

		// warn if invalid characters
		String invalidChars = alignment.getInvalidCharacters();
		if(invalidChars.length() > 0){
			String message = "Muscle is sensiteive to invalid characters, the following are found: " + invalidChars;
			JOptionPane.showMessageDialog(DialogUtils.getDialogParent(), message, "Problem characters", JOptionPane.INFORMATION_MESSAGE);
			return;
		}

		try {
			// Save current alignment in tempdir
			File currentAlignmentTempFile = File.createTempFile("aliview-tmp-current-alignment", ".fasta");
			// TODO maybe file format changes when reloading a aligned file
			alignment.saveAlignmentAsFile(currentAlignmentTempFile, FileFormat.FASTA);

			// Create a tempFile for new alignment
			File newAlignmentTempFile = File.createTempFile("aliview-tmp-alignment", ".fasta");

			// Align in with muscle
			boolean wasProcessInterruptedByUser = Aligner.muscleProfileAlign(downloadedSequenceFile, currentAlignmentTempFile, newAlignmentTempFile, this.frame);

			if(! wasProcessInterruptedByUser){
				// Reload alignment
				// TO DO HANDLE bad loading of file better
				if(newAlignmentTempFile.length() > 0){

					aliView.pushUndoState();
					// TODO storing this could be done slightly more unified
					// store path to current working file
					File storedAlignmentFile = alignment.getAlignmentFile();
					Excludes storedExcludes = alignment.getExcludes();
					CodonPositions storedCodonPos = alignment.getCodonPositions();

					loadNewAlignmentFile(newAlignmentTempFile);
					// Restore
					alignment.setAlignmentFile(storedAlignmentFile);
					this.updateWindowTitle();
					alignment.setExcludes(storedExcludes);
					alignment.setCodonPositions(storedCodonPos);
				}
				else{
					String message = "Something did not work out when aligning";
					JOptionPane.showMessageDialog(DialogUtils.getDialogParent(), message, "Problem characters", JOptionPane.INFORMATION_MESSAGE);
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	protected synchronized void alignWithMuscle() {
		// warn if invalid characters
		String invalidChars = alignment.getInvalidCharacters();
		if(invalidChars.length() > 0){
			String message = "Muscle is sensiteive to invalid characters, the following are found and will be removed by muscle: " + invalidChars;
			int choise = JOptionPane.showConfirmDialog(DialogUtils.getDialogParent(), message, "Problem characters", JOptionPane.OK_CANCEL_OPTION);
			if(choise == JOptionPane.CANCEL_OPTION){
				return;
			}
		}
		try {
			logger.info("alignWithMuscle");
			// Save current alignment in tempdir
			File currentAlignmentTempFile = File.createTempFile("aliview-tmp-current-alignment", ".fasta");
			// TODO maybe file format changes when reloading a aligned file
			alignment.saveAlignmentAsFile(currentAlignmentTempFile, FileFormat.FASTA);

			// Create a tempFile for new alignment
			File newAlignmentTempFile = File.createTempFile("aliview-tmp-alignment", ".fasta");

			// Align in with muscle
			boolean wasProcessInterruptedByUser = Aligner.muscleAlign(currentAlignmentTempFile, newAlignmentTempFile, this.frame);

			if(! wasProcessInterruptedByUser){
				// Reload alignment
				// TO DO HANDLE bad loading of file better
				if(newAlignmentTempFile.length() > 0){
					// TODO storing this could be done slightly more unified
					// store path to current working file
					aliView.pushUndoState();
					File storedAlignmentFile = alignment.getAlignmentFile();
					Excludes storedExcludes = alignment.getExcludes();
					CodonPositions storedCodonPos = alignment.getCodonPositions();

					loadNewAlignmentFile(newAlignmentTempFile);
					// Restore
					alignment.setAlignmentFile(storedAlignmentFile);
					this.updateWindowTitle();
					alignment.setExcludes(storedExcludes);
					alignment.setCodonPositions(storedCodonPos);
				}else{
					String message = "Something did not work out when aligning";
					JOptionPane.showMessageDialog(DialogUtils.getDialogParent(), message, "Problem characters", JOptionPane.INFORMATION_MESSAGE);
				}
			}

			logger.info("FinishedalignWithMuscle");


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	protected synchronized void reAlignSelectionWithMuscle() {

		// warn if invalid characters
		String invalidChars = alignment.getInvalidCharacters();
		if(invalidChars.length() > 0){
			String message = "Muscle is sensiteive to invalid characters, the following are found and will be removed by muscle: " + invalidChars;
			int choise = JOptionPane.showConfirmDialog(DialogUtils.getDialogParent(), message, "Problem characters", JOptionPane.OK_CANCEL_OPTION);
			if(choise == JOptionPane.CANCEL_OPTION){
				return;
			}
		}

		try {
			logger.info("reAlignWithMuscle");
			// Save current selection in tempdir
			File currentSelectionTempFile = File.createTempFile("aliview-tmp-current-selection", ".fasta");
			alignment.saveSelectionAsFastaFile(currentSelectionTempFile, 0);

			// Create a tempFile for new alignment
			File newRealignedSelectionTempFile = File.createTempFile("aliview-tmp-realigned-selection", ".fasta");

			logger.info(newRealignedSelectionTempFile);

			// Align in with muscle
			boolean wasProcessInterruptedByUser = Aligner.muscleAlign(currentSelectionTempFile, newRealignedSelectionTempFile, this.frame);

			if(! wasProcessInterruptedByUser){

				// Reload alignment
				// TO DO HANDLE bad loading of file better
				if(newRealignedSelectionTempFile.length() > 0){
					aliView.pushUndoState();
					// load realigned into alignment
					Alignment realignment = AlignmentFactory.createNewAlignment(newRealignedSelectionTempFile);

					// loop through all selected sequences
					for(Sequence seq: alignment.sequences){
						int selPos[] = seq.getSelectedBasesPositions();
						// check if there is selected pos in this sequence
						if(selPos != null && selPos.length > 0){

							Sequence realignedSeq = realignment.getSequenceByName(seq.getName());

							byte[] realignedBases;
							// muscle removes empty seq if that is case create an empty bases
							if(realignedSeq != null){
								realignedBases = realignedSeq.getBases();
							}else{
								realignedBases = Sequence.createGapSequence(realignment.getMaximumSequenceLength());
							}

							seq.replaceBases(selPos[0],selPos[selPos.length -1],realignedBases);
							seq.selectBases(selPos[0],selPos[0] + realignedBases.length -1);

						}
					}
					alignment.updateSequencesMatrix();
					alignmentPane.repaint();

				}else{
					String message = "Something did not work out when aligning";
					JOptionPane.showMessageDialog(DialogUtils.getDialogParent(), message, "Problem characters", JOptionPane.INFORMATION_MESSAGE);
				}
			}

			logger.info("Finished reAlignWithMuscle");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// todo mouse listener on jlist - it is to slow to listen on selection change events (update on alignment pane is not instatiounous)




	private class AlignmentMouseListener implements MouseListener, MouseMotionListener, MouseWheelListener {
		private Point startPoint;
		private Point startPointScreen;
		private Point startPaneVisibleRectLocation;
		private Point dragPointStart;
		private boolean isDragging;


		/*
		// Chech if no ctrl modifier - then clear previous selection
		if(! e.isControlDown()){
			logger.info("modifiers" + e.getModifiers());
			alignmentPane.clearSelection();
			alignmentList.clearSelection();
		}

		try {
			alignmentPane.selectBaseAt(mousePos);
		} catch (InvalidAlignmentPositionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 */

		public void mousePressed(MouseEvent e) {

			logger.info("mouse pressed");

			// Save some startpoints
			startPoint = e.getPoint();
			startPointScreen = e.getLocationOnScreen();
			startPaneVisibleRectLocation = alignmentPane.getVisibleRect().getLocation();

			switch (alignmentPane.getInteractionMode()) {
			case AlignmentPane.INTERACTION_MODE_VIEW:


				break;

			case AlignmentPane.INTERACTION_MODE_SELECT:

				// if click is within an existing selection
				// we should think about drag possibility
				if(alignmentPane.isWithinExistingSelection(e.getPoint())){

					dragPointStart = e.getPoint();
					//pushUndoState();



					// currently just clear
					//alignmentList.clearSelection();
					//alignmentPane.clearSelection();
					//alignmentPane.clearTempSelection();


				}else{

					// clear list selection
					alignmentList.clearSelection();
					alignmentPane.requestFocus();

					if(! e.isControlDown()){
						alignmentPane.clearSelection();
					}


					alignmentPane.selectBaseAt(startPoint);
					int alignmentPos = alignmentPane.getAlignmentXat(startPoint);
					int ungapedPos = alignmentPane.getUngapedSequenceXPositionAt(startPoint);
					// add +1 because internally first position in sequence is 0
					lblSelectionInfo.setText("selected pos: " + (alignmentPos + 1) + ", pos " + (ungapedPos + 1) + " in ungaped sequence");

				}

				break;

			default:
				break;
			}

		}

		public void mouseReleased(MouseEvent e){

			if(startPoint != null){

				switch (alignmentPane.getInteractionMode()) {
				case AlignmentPane.INTERACTION_MODE_VIEW:

					break;

				case AlignmentPane.INTERACTION_MODE_SELECT:	
					// if startpoint is same as release-point select by point
					if(startPoint.equals(e.getPoint())){
						// clear selection
						alignment.clearSelection();
						alignmentPane.clearTempSelection();

						// if click is on ruler, all should get select
						if(e.getComponent() == alignmentPane.getRulerComponent()){
							alignmentPane.selectColumnAt(startPoint);
						}else{
							alignmentPane.selectBaseAt(startPoint);
						}

					}
					else if(isDragging){
						isDragging = false;
						alignment.clearSelectionOffset();
						dragPointStart = null;
						// else select by rectangle
					}else{
						logger.info("select Within");
						Rectangle selectRect = new Rectangle(e.getPoint());
						selectRect.add(startPoint);
						if(e.isControlDown()){
							//	alignmentPane.addSelectionWithin(selectRect);
						}
						else{

							int selectionSize = 0;
							if(e.getComponent() == alignmentPane.getRulerComponent()){
								selectionSize = alignmentPane.selectColumnsWithin(selectRect);
							}else{
								selectionSize = alignmentPane.selectWithin(selectRect);
							}
							lblSelectionInfo.setText("" + selectionSize + " selected");
						}
						alignmentPane.clearTempSelection();
					}


					break;

				default:
					break;
				}
				// Clear stuff when released
				startPoint = null;
				startPointScreen = null;
				isDragging = false;
				alignment.clearSelectionOffset();
				dragPointStart = null;
			}



		}

		public void mouseEntered(MouseEvent e) {

		}

		public void mouseExited(MouseEvent e) {
		}

		public void mouseClicked(MouseEvent e) {


			if(e.getButton() == e.BUTTON3){
				logger.info("right-click");

				//Sequence seq = alignmentPane.getSequenceAt(e.getPoint());

				try {
					alignmentPane.setDifferenceTraceSequence(e.getPoint());
				} catch (InvalidAlignmentPositionException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		}

		public void mouseDragged(MouseEvent e) {
			// Theese two lines makes sure pane is scrolling when user selects
			// and moves outside current visible rect
			Rectangle preferredVisisble = new Rectangle(e.getPoint());
			alignmentPane.scrollRectToVisible(preferredVisisble);

			int ungapedPos = alignmentPane.getUngapedSequenceXPositionAt(e.getPoint());
			// add one because of program internaly works with pos 0 as the first
			lblSelectionInfo.setText("" + (ungapedPos + 1) + " (ungaped position) ");

			if(startPoint != null){
				switch (alignmentPane.getInteractionMode()) {

				case AlignmentPane.INTERACTION_MODE_VIEW:
					int offsetX = startPointScreen.x - e.getLocationOnScreen().x;
					int offsetY = startPointScreen.y - e.getLocationOnScreen().y;
					Rectangle rect = alignmentPane.getVisibleRect();
					rect.setLocation(startPaneVisibleRectLocation.x + offsetX, startPaneVisibleRectLocation.y + offsetY);	
					alignmentPane.scrollRectToVisible(rect);

					break;

				case AlignmentPane.INTERACTION_MODE_SELECT:	

					// Dragging bases
					if(dragPointStart != null){

						if(isDragging != true){
							isDragging = true;
							pushUndoState();
						}

						int diff = e.getPoint().x - dragPointStart.x;
						double diffInSeqPosiitons = diff/alignmentPane.charWidth;
						int intDiffInseqPos = 0;
						// round to largest
						if(diffInSeqPosiitons > 0){
							intDiffInseqPos = (int)Math.ceil(diffInSeqPosiitons);
						}else{
							intDiffInseqPos = (int)Math.floor(diffInSeqPosiitons);
						}

						Rectangle selectRect = alignment.getSelectionAsMinRect();
						Point paneXY = alignmentPane.matrixCoordToPaneCoord(new Point(selectRect.x, selectRect.y));
						Rectangle selectInPaneCoord = new Rectangle(   paneXY.x, paneXY.y,
								(int) (selectRect.width * alignmentPane.charWidth),
								(int) (selectRect.height * alignmentPane.charHeight + alignmentPane.charHeight));

						selectInPaneCoord.grow(4 + 3 * Math.abs(diff),0);

						//logger.info("diffInSeqPosiitons" + diffInSeqPosiitons);

						// don't move if mouse not is within selection x,y
						/*
						if(e.getPoint().x + diff > selectInPaneCoord.getMinX() &&
								e.getPoint().x -diff < selectInPaneCoord.getMaxX()){
							alignment.moveSelection(intDiffInseqPos);
						}
						 */

						alignment.moveSelection(intDiffInseqPos);
						alignmentPane.paintImmediately(selectInPaneCoord);



					}
					// Selecting
					else{
						Rectangle selectRect = new Rectangle(e.getPoint());
						selectRect.add(startPoint);
						alignmentPane.setTempSelection(selectRect);
					}



					break;

				default:
					break;
				}

			}	
		}

		public void mouseMoved(MouseEvent e) {
			int ungapedPos = alignmentPane.getUngapedSequenceXPositionAt(e.getPoint());
			// add one because of program internaly works with pos 0 as the first
			lblSelectionInfo.setText("" + (ungapedPos + 1) + " (ungaped position) ");

		}

		public void mouseWheelMoved(MouseWheelEvent e) {
			// Zoom in out if ctrl is pressed
			if(e.getModifiersEx() ==  OSNativeUtils.getMouseWheelZoomModifierMask()){
				if(e.getWheelRotation() > 0){
					aliView.zoomOutAt(e.getPoint());
				}
				else if(e.getWheelRotation() < 0){		
					aliView.zoomInAt(e.getPoint());
				}
			}
			// Else scroll pane left or right
			else if(e.isShiftDown()){
				if(e.getWheelRotation() > 0){
					Rectangle preferedVisible = alignmentPane.getVisibleRect();
					preferedVisible.setLocation((int) (preferedVisible.x - 0.1 * preferedVisible.getWidth()), preferedVisible.y);
					alignmentPane.scrollRectToVisible(preferedVisible);
					alignmentPane.revalidate();
				}
				else if(e.getWheelRotation() < 0){	
					Rectangle preferedVisible = alignmentPane.getVisibleRect();
					preferedVisible.setLocation((int) (preferedVisible.x + 0.1 * preferedVisible.getWidth()), preferedVisible.y);
					alignmentPane.scrollRectToVisible(preferedVisible);
					alignmentPane.revalidate();

				}
				// Else scroll pane up or down				
			}else{
				if(e.getWheelRotation() > 0){
					Rectangle preferedVisible = alignmentPane.getVisibleRect();
					preferedVisible.setLocation(preferedVisible.x, (int) (preferedVisible.y + 0.1 * preferedVisible.getHeight()));
					alignmentPane.scrollRectToVisible(preferedVisible);
					alignmentPane.revalidate();
				}
				else if(e.getWheelRotation() < 0){	
					Rectangle preferedVisible = alignmentPane.getVisibleRect();
					preferedVisible.setLocation(preferedVisible.x, (int) (preferedVisible.y - 0.1 * preferedVisible.getHeight()));
					alignmentPane.scrollRectToVisible(preferedVisible);
					alignmentPane.revalidate();

				}
			}


		}

	}

	private class AlignmentRulerListener implements MouseListener, MouseMotionListener{
		private Point startPoint;	
		private Point startPointOnAlignmentPane;

		public void mousePressed(MouseEvent e) {

			// Save some startpoints
			startPoint = e.getPoint();
			startPointOnAlignmentPane = new Point(alignmentPane.getVisibleRect().x + e.getPoint().x,0);

			alignmentPane.clearTempSelection();
			alignmentPane.clearSelection();
			alignmentPane.selectColumnAt(startPointOnAlignmentPane);

		}

		public void mouseReleased(MouseEvent e){

			if(startPoint != null){

				Point endPointOnAlignmentPane = new Point(alignmentPane.getVisibleRect().x + e.getPoint().x,alignmentPane.getHeight());

				Rectangle selectRect = new Rectangle(startPointOnAlignmentPane);
				selectRect.add(endPointOnAlignmentPane);

				logger.info(selectRect);

				int selectionSize = 0;

				// do a single point or rectangle select
				if(startPointOnAlignmentPane.x == endPointOnAlignmentPane.x){
					alignmentPane.selectColumnAt(endPointOnAlignmentPane);
				}else{
					selectionSize = alignmentPane.selectColumnsWithin(selectRect);
				}

				lblSelectionInfo.setText("" + selectionSize + "valda");

				alignmentPane.clearTempSelection();

				// Clear startpoint
				startPoint = null;
				startPointOnAlignmentPane = null;
			}
		}

		public void mouseEntered(MouseEvent e) {

		}

		public void mouseExited(MouseEvent e) {
		}

		public void mouseClicked(MouseEvent e) {
		}

		public void mouseDragged(MouseEvent e) {
			// Theese two lines makes sure pane is scrolling when user selects
			// and moves outside current visible rect
			int alignmentYPos = alignmentPane.getVisibleRect().y;
			int alignmentXPos = alignmentPane.getVisibleRect().x + e.getPoint().x;
			Rectangle preferredVisisble = new Rectangle(new Point(alignmentXPos,alignmentYPos));
			alignmentPane.scrollRectToVisible(preferredVisisble);

			if(startPoint != null){

				Point endPointOnAlignmentPane = new Point(alignmentPane.getVisibleRect().x + e.getPoint().x,alignmentPane.getHeight());
				Rectangle selectRect = new Rectangle(startPointOnAlignmentPane);
				selectRect.add(endPointOnAlignmentPane);
				alignmentPane.setTempSelection(selectRect);
			}
		}

		public void mouseMoved(MouseEvent e) {
			// TODO Auto-generated method stub

		}	

	}


	public static void putErrorMessage(String message) {
		JOptionPane.showMessageDialog(aliView.frame, message, "Error", JOptionPane.INFORMATION_MESSAGE);

	}

	public void handleAbout(ApplicationEvent event) {
		// TODO Auto-generated method stub

	}

	public void handleOpenApplication(ApplicationEvent event) {
		// TODO Auto-generated method stub

	}

	public void handleOpenFile(ApplicationEvent event) {
		loadNewAlignmentFile(new File(event.getFilename()));	
	}

	public void handlePreferences(ApplicationEvent event) {
		// TODO Auto-generated method stub

	}

	public void handlePrintFile(ApplicationEvent event) {
		// TODO Auto-generated method stub

	}

	public void handleQuit(ApplicationEvent event) {
		// TODO Auto-generated method stub

	}

	public void handleReOpenApplication(ApplicationEvent event) {
		// TODO Auto-generated method stub

	}


	public static void flushAllLogs()
	{
		try
		{
			Set<FileAppender> flushedFileAppenders = new HashSet<FileAppender>();
			Enumeration currentLoggers = LogManager.getLoggerRepository().getCurrentLoggers();
			while(currentLoggers.hasMoreElements())
			{
				Object nextLogger = currentLoggers.nextElement();
				if(nextLogger instanceof Logger)
				{
					Logger currentLogger = (Logger) nextLogger;
					Enumeration allAppenders = currentLogger.getAllAppenders();
					while(allAppenders.hasMoreElements())
					{
						Object nextElement = allAppenders.nextElement();
						if(nextElement instanceof FileAppender)
						{
							FileAppender fileAppender = (FileAppender) nextElement;
							if(!flushedFileAppenders.contains(fileAppender) && !fileAppender.getImmediateFlush())
							{
								flushedFileAppenders.add(fileAppender);
								//log.info("Appender "+fileAppender.getName()+" is not doing immediateFlush ");
								fileAppender.setImmediateFlush(true);
								currentLogger.info("FLUSH");
								fileAppender.setImmediateFlush(false);
							}
							else
							{
								//log.info("fileAppender"+fileAppender.getName()+" is doing immediateFlush");
							}
						}
					}
				}
			}
		}
		catch(RuntimeException e)
		{
			logger.error("Failed flushing logs",e);
		}
	}

	
}

/*
 * http://www.ncbi.nlm.nih.gov/tools/primer-blast/index.cgi?INPUT_SEQUENCE=GAAGATAACTTGTAGATCGCTTCCTtagtaaattagcctggtctgtattaacggatgatgaaattttggacaggtttgtaaaaatttggaatactttttctttgtatcacagtgcttcaataaatGAAGATAACTTKTRGATCKCTTCCTATGGATTGCGTAGATTGAGATATATATCACGACTT&
PRIMER5_END=40&PRIMER3_START=126&PRIMER_PRODUCT_MIN=100&PRIMER_PRODUCT_MAX=1000&PRIMER_NUM_RETURN=10&
PRIMER_MIN_TM=52.0&PRIMER_OPT_TM=52&PRIMER_MAX_TM=55&PRIMER_MAX_DIFF_TM=3&PRIMER_ON_SPLICE_SITE=0&SPLICE_SITE_OVERLAP_5END=7&SPLICE_SITE_OVERLAP_3END=4&SPAN_INTRON=off&MIN_INTRON_SIZE=1000&MAX_INTRON_SIZE=1000000&SEARCH_SPECIFIC_PRIMER=off&EXCLUDE_ENV=off&EXCLUDE_XM=off&ORGANISM=Homo%20sapiens&PRIMER_SPECIFICITY_DATABASE=refseq_rna&TOTAL_PRIMER_SPECIFICITY_MISMATCH=1&PRIMER_3END_SPECIFICITY_MISMATCH=1&MISMATCH_REGION_LENGTH=5&TOTAL_MISMATCH_IGNORE=7&PRODUCT_SIZE_DEVIATION=4000&ALLOW_TRANSCRIPT_VARIANTS=off&HITSIZE=50000&EVALUE=30000&WORD_SIZE=7&MAX_CANDIDATE_PRIMER=1000&PRIMER_MIN_SIZE=15&PRIMER_OPT_SIZE=20&PRIMER_MAX_SIZE=25&PRIMER_MIN_GC=20.0&PRIMER_MAX_GC=80.0&GC_CLAMP=0&POLYX=5&SELF_ANY=8.00&SELF_END=3.00&PRIMER_MISPRIMING_LIBRARY=AUTO&NO_SNP=off&LOW_COMPLEXITY_FILTER=on&MONO_CATIONS=50.0&DIVA_CATIONS=0.0&CON_ANEAL_OLIGO=50.0&CON_DNTPS=0.0&SALT_FORMULAR=1&TM_METHOD=1&PRIMER_INTERNAL_OLIGO_MIN_SIZE=18&PRIMER_INTERNAL_OLIGO_OPT_SIZE=20&PRIMER_INTERNAL_OLIGO_MAX_SIZE=27&PRIMER_INTERNAL_OLIGO_MIN_TM=57.0&PRIMER_INTERNAL_OLIGO_OPT_TM=60.0&PRIMER_INTERNAL_OLIGO_MAX_TM=63.0&PRIMER_INTERNAL_OLIGO_MAX_GC=80.0&PRIMER_INTERNAL_OLIGO_OPT_GC_PERCENT=50&PRIMER_INTERNAL_OLIGO_MIN_GC=20.0&PICK_HYB_PROBE=off&NEWWIN=off&NEWWIN=off&SHOW_SVIEWER=false

 */
