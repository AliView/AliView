package aliview.sequences;

import java.io.UnsupportedEncodingException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;



public class PhylipSequence extends InMemorySequence{
	private static final Logger logger = Logger.getLogger(PhylipSequence.class);
	private static final String TEXT_FILE_BYTE_ENCODING = "ASCII";
	private String name;
	
	public PhylipSequence(String name, byte[] bases) {
		super();
		this.name = name;
		this.setBases(bases, null);
	}
	
	public PhylipSequence(String name, String basesAsString) {
		super();
		this.name = name;
		try {
			this.setBases(basesAsString.getBytes(TEXT_FILE_BYTE_ENCODING), null);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getName(){
		return this.name;
	}
	
	
	
	public String getSimpleName(){
		return getName();
	}

	public int compareTo(Sequence anotherSeq) {
		return this.getSimpleName().compareTo(anotherSeq.getSimpleName());
	}
}
