package aliview;

import java.io.File;

public class NucleotideAlignment extends Alignment {


	public NucleotideAlignment(File alignmentFile, FileFormat fileFormat, MemoryArrayMatrix matrix, Excludes excludes,
			CodonPositions codonPositions) {
		super(alignmentFile, fileFormat, matrix,excludes,codonPositions);
	}
	
	public NucleotideAlignment(MemoryArrayMatrix matrix) {
		super(matrix);
	}

}
